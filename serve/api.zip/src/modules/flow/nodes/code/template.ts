import { BaseCode } from './base';
// @ts-ignore
import axios from 'axios';
// @ts-ignore
import * as _ from 'lodash';

/**
 * 代码执行
 */
export class Cool extends BaseCode {
  /**
   * 主函数
   */
  async main(params: any) {
    // console.log('Cool main', params);
  }
}
