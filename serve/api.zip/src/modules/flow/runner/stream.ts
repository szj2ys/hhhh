import { Readable } from 'stream';

/**
 * 自定义流
 */
export class FlowStream extends Readable {
  _read(size) {}
}
