import{u as re,P as ft,j as qe,k as lt,l as jt,a as Et,n as $t,o as Ge}from"./index-C5WS2hJt.js";import"./store@2.0.12-i6xqVJod.js";import{P as ct,c as Pt,u as gt,_ as Ot,d as Vt,e as Nt,f as Lt,h as Ft}from"./@vue-flow_core@1.44.0_vue@3.5.16_typescript@5.5.4_-D8JXzrQS.js";import{_ as qt}from"./@vue-flow_background@1.3.2_@vue-flow_core@1.44.0_vue@3.5.16_typescript@5.5.4___vue@3.5.16_typescript@5.5.4_-BrQq__mJ.js";import{d as Bt}from"./pinia@2.3.1_typescript@5.5.4_vue@3.5.16_typescript@5.5.4_-BZ2tmr1d.js";import{w as we,v as $e,a as Ut}from"./@vue_runtime-dom@3.5.16-DriBzn4z.js";import{d as I,v as Z,P as S,y as W,o as d,H as T,a as b,i as r,c as w,z as O,F as K,L as ne,W as fe,e as ge,w as Ie,J as se,T as Ht,n as Ze,l as zt,f as Fe,U as Pe,x as Wt,I as Yt,a2 as Gt}from"./@vue_runtime-core@3.5.16-Cn8z-kNe.js";import{q as Se,p as ce,O as q}from"./@vue_shared@3.5.16-UwmvJIHj.js";import{y as E,v as ae,u as pe,a as Oe,l as Kt,x as Xt}from"./@vue_reactivity@3.5.16-Dqy0TPbS.js";import{_ as Y}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{M as ht,S as et}from"./model-CxEZ8A3x.js";import{s as vt,X as Jt,n as Xe,h as Qt,Y as Zt,T as en}from"./@element-plus_icons-vue@2.3.1_vue@3.5.16_typescript@5.5.4_-CeLFb4Nw.js";import{A as Q,y as _t,I as tt,J as tn,F as Je,B as Ve,d as bt,v as Be,e as Ne,K as nn,L as an,x as on,z as sn}from"./lodash-es@4.17.21-BYk7DlcU.js";import{a as ue,b as Ue}from"./element-plus@2.9.11_vue@3.5.16_typescript@5.5.4_-BTKo5Rtv.js";import{l as rn}from"./monaco-editor@0.49.0-BsaCIC0H.js";import{u as ln,c as cn,d as nt,b as dt}from"./comm-Ba3vmJ1R.js";import{C as dn}from"./index-l1IOnGdE.js";import{u as un}from"./vue-i18n@11.1.5_vue@3.5.16_typescript@5.5.4_-Bqjl69Su.js";import{b as yn}from"./@vueuse_core@12.8.2_typescript@5.5.4-7kYVjNRB.js";import{E as pn}from"./elkjs@0.9.3-B3I9NHB_.js";/* empty css                                                                                                                  */import{_ as mn}from"./@vue-flow_minimap@1.5.3_@vue-flow_core@1.44.0_vue@3.5.16_typescript@5.5.4___vue@3.5.16_typescript@5.5.4_-CSWKGDCC.js";/* empty css                                                                                                                      */import{d as Qe}from"./dayjs@1.11.13-DUxgsv0d.js";import{C as fn}from"./config-d1gIbpxo.js";import{o as gn}from"./vue-router@4.5.1_vue@3.5.16_typescript@5.5.4_-ODt3CAxp.js";import"./mitt@3.0.1-C1z4c41a.js";import"./@codemirror_language-data@6.5.1-Blx1hvTn.js";import"./@codemirror_language@6.11.1-BYrSuhr8.js";import"./@lezer_common@1.2.3-CP7NCNqd.js";import"./@codemirror_state@6.5.2-DQ6R6BiX.js";import"./@marijn_find-cluster-break@1.0.2-DXwl3gUT.js";import"./@codemirror_view@6.37.1-Bd3_Yh4F.js";import"./style-mod@4.1.2-Bc2inJdb.js";import"./w3c-keyname@2.2.8-Vcq4gwWv.js";import"./@lezer_highlight@1.2.1-DwVMghhY.js";import"./vue-echarts@7.0.3_@vue_runtime-core@3.5.16_echarts@5.6.0_vue@3.5.16_typescript@5.5.4_-Dhz4IGE5.js";import"./echarts@5.6.0-DvAKqd2B.js";import"./tslib@2.3.0-BDyQ-Jie.js";import"./zrender@5.6.1-DcQm8NwP.js";import"./axios@1.9.0-D--XfsWq.js";import"./nprogress@0.2.0-dOd6e7EG.js";import"./chardet@2.1.0-CTPPlwpv.js";import"./@vueuse_shared@12.8.2_typescript@5.5.4-CuUdMqkw.js";import"./@vueuse_shared@9.13.0_vue@3.5.16_typescript@5.5.4_-4q0MSQPl.js";import"./@vueuse_core@9.13.0_vue@3.5.16_typescript@5.5.4_-DmiypGF2.js";import"./@sxzz_popperjs-es@2.11.7-D_chPuIy.js";import"./@ctrl_tinycolor@3.6.1-r5W6hzzQ.js";import"./async-validator@4.2.5-CDKkdPIV.js";import"./memoize-one@6.0.0-BdPwpGay.js";import"./normalize-wheel-es@1.2.0-BQoi3Ox2.js";import"./@floating-ui_dom@1.7.1-Ba-2EiSn.js";import"./@floating-ui_core@1.7.1-C83JrwzW.js";import"./@floating-ui_utils@0.2.9-CBkBHzV8.js";import"./@intlify_core-base@11.1.5-rFPZQXdu.js";import"./@intlify_shared@11.1.5-CY44FrR8.js";import"./@intlify_message-compiler@11.1.5-CZ-uatfp.js";import"./web-worker@1.5.0-DC3-P8nB.js";import"./group-CxGNcSJX.js";const hn=I({name:"tools-handle"}),vn=I({...hn,name:"tools-handle",props:{nodeId:String,id:String,position:Object,type:{type:String,default:"source"}},setup(n){const l=n,e=de(),a=Z(()=>l.type=="target"?ct.Left:ct.Right),o=Z(()=>!!e.edges.find(u=>u[l.type]==l.nodeId?u[`${l.type}Handle`]==l.id:!1));function y({targetHandle:u,sourceHandle:A,source:m,target:v}){return e.parentAllNodes(m).find(t=>t.id==v)||v==m?!1:u=="target"&&A!="target"}return(u,A)=>{const m=S("cl-svg"),v=S("el-icon");return d(),W(v,{class:ce(["tools-handle",[`is-${n.type}`,{"is-link":o.value}]]),style:Se([n.position]),onClick:A[0]||(A[0]=we(()=>{},["stop"]))},{default:T(()=>[A[1]||(A[1]=b("span",{class:"rod"},null,-1)),r(m,{name:"flow-arrow-right",class:"icon"}),r(E(Pt),{id:n.id,type:n.type,position:a.value,"is-valid-connection":y},null,8,["id","type","position"])]),_:1,__:[1]},8,["class","style"])}}}),Le=Y(vn,[["__scopeId","data-v-e704370a"]]),_n={class:"node-classify"},bn={key:0,class:"model"},xn={class:"content"},wn=I({name:"undefined"}),kn=I({...wn,name:"node-classify",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){const l=n,e=Z(()=>{var a,o;return(((o=(a=l.node.data)==null?void 0:a.options)==null?void 0:o.types)||[]).map((y,u)=>({content:y,value:`source-${u}`}))});return(a,o)=>{var y,u;return d(),w("div",_n,[n.focus?O("",!0):(d(),w("div",bn,[r(ht,{data:(u=(y=n.node.data)==null?void 0:y.options)==null?void 0:u.model},null,8,["data"])])),(d(!0),w(K,null,ne(e.value,(A,m)=>(d(),w("div",{class:"item",key:m},[b("span",xn,q(A.content||"未填写内容"),1),r(Le,{type:"source","node-id":n.node.id,id:A.value,position:{right:"-24px"}},null,8,["node-id","id"])]))),128))])}}}),An=Y(kn,[["__scopeId","data-v-397c6c5f"]]),Sn={class:"form-classify"},Rn={class:"list"},Tn=I({name:"undefined"}),In=I({...Tn,name:"node-classify-form-classify",props:{modelValue:{type:Array,default:()=>[]}},setup(n){const l=n,e=de(),a=fe(l,"modelValue");function o(){a.value.push("")}function y(u){a.value.splice(u,1);const A=e.edges.find(m=>{var v;return m.source==((v=e.node)==null?void 0:v.id)&&m.sourceHandle==`source-${u}`});A&&e.removeEdges(A)}return ge(()=>{Ie(a,u=>{var A;((A=e.node)==null?void 0:A.type)=="classify"&&(e.node.handle.next=u.map((m,v)=>({label:`分类 ${v+1}`,value:`source-${v}`})))},{immediate:!0,deep:!0})}),(u,A)=>{const m=S("cl-svg"),v=S("el-input");return d(),w("div",Sn,[r(m,{name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:A[0]||(A[0]=i=>o())}),b("div",Rn,[(d(!0),w(K,null,ne(E(a),(i,t)=>(d(),w("div",{class:"cl-flow__textarea-item",key:t},[r(m,{name:"delete",class:"cl-flow__btn-icon",onClick:g=>y(t)},null,8,["onClick"]),r(v,{type:"textarea",modelValue:E(a)[t],"onUpdate:modelValue":g=>E(a)[t]=g,placeholder:"输入你的主题内容",autosize:{minRows:2,maxRows:4},resize:"none"},null,8,["modelValue","onUpdate:modelValue"])]))),128))])])}}}),Cn=Y(In,[["__scopeId","data-v-2b295440"]]),Dn={class:"w-full"},Mn={key:0,class:"cl-flow__inner-item"},jn={key:1,class:"text"},En={key:2,class:"placeholder"},$n={class:"tools-var"},Pn={class:"search"},On={class:"label"},Vn=["onClick"],Nn={class:"value"},Ln={class:"type"},Fn={key:0,class:"empty"},qn=I({name:"undefined"}),Bn=I({...qn,name:"tools-var",props:{modelValue:{type:String,default:""},nodeId:{type:String,default:""},value:{type:String,default:""},onlySelect:Boolean,useInputParams:Boolean,inputable:Boolean,showPicker:{type:Boolean,default:!0},showSearch:{type:Boolean,default:!0},autofocus:{type:Boolean,default:!0}},emits:["update:modelValue","update:nodeId","update:nodeType","update:value","update:type","select"],setup(n,{expose:l,emit:e}){const a=n,o=e,{refs:y,setRefs:u}=re(),A=de(),m=fe(a,"modelValue"),v=fe(a,"nodeId"),i=fe(a,"value"),t=ae(""),g=ae(!1),f={onSelect:()=>{}},h=Z(()=>{var L;const F=A.parentAllNodes(((L=A.node)==null?void 0:L.id)||"").map(N=>{var H,te;let B=[];return N.type=="start"?B=((H=N.data)==null?void 0:H.inputParams)||[]:B=((te=N.data)==null?void 0:te.outputParams)||[],{id:N.id,type:N.type,label:N.label,params:B}});if(a.useInputParams&&A.node){const{id:N,type:B,label:H,data:te}=A.node;F.splice(0,F.length,{id:N,type:B,label:H,params:((te==null?void 0:te.inputParams)||[]).filter(he=>he.nodeId)})}return F.filter(N=>{var B;return!Q(N.params)&&(t.value?(B=N.label)==null?void 0:B.includes(t.value):!0)})}),p=Z(()=>{const F=h.value.find(L=>L.id==a.nodeId&&L.params.find(N=>N.field==m.value));return i.value||(F?`${F==null?void 0:F.label} / ${m.value}`:"")});function s(F,L){_();const N={...F,nodeType:L.type,nodeId:L.id,nodeLabel:L.label,value:""};a.onlySelect?f.onSelect(N):(m.value=N.field,o("update:nodeType",N.nodeType),o("update:nodeId",N.nodeId),o("update:type",N.type),o("update:value",N.value)),o("select",N)}function x(){m.value="",i.value="",o("update:nodeType",""),o("update:nodeId",""),o("update:type",""),o("update:value","")}function c(F={}){if(F.rect){const{top:L,left:N}=F.rect||{};y.btn.style.transform=`translate(${N}px, ${L}px)`}F.onSelect&&(f.onSelect=F.onSelect),g.value||y.btn.click()}function _(){y.popover.hide()}const C=ae("");function $(F){y.list.focus(),F&&z(F)}const D=pe({visible:!1,value:"",open(){D.value=i.value,D.visible=!0},close(){D.visible=!1},save(){if(!D.value)return ue.warning("请输入内容");i.value=D.value,D.close()},onChange(){m.value="",o("update:nodeType",""),o("update:nodeId",""),o("update:type","")}});function z(F){const L=h.value.map(te=>te.params.map(he=>({...he,node:te}))).flat();let N=0;const B=L.findIndex(te=>C.value==`${te.node.id}_${te.field}`);switch(F.key){case"ArrowUp":N=B-1;break;case"ArrowDown":N=B+1;break;case"Enter":s(L[B],L[B].node);break}const H=L[N];H&&(C.value=`${H.node.id}_${H.field}`)}function X(){a.autofocus&&$(),g.value=!0}function ee(){g.value=!1,C.value=""}function oe(){return new Promise(F=>{const L=Ie(h,N=>{Q(N)||(F(N),L())},{immediate:!0})})}return l({list:h,getList:oe,open:c,close:_,focus:$}),(F,L)=>{const N=S("cl-svg"),B=S("el-tooltip"),H=S("el-input"),te=S("el-scrollbar"),he=S("el-button"),Ce=S("cl-dialog"),Re=S("el-popover");return d(),w("div",Dn,[(d(),W(Ht,{to:"body",disabled:n.showPicker},[r(Re,{ref:E(u)("popover"),trigger:"click",width:"220px",placement:"bottom-start","popper-class":"cl-flow__popper","popper-style":{padding:"0"},offset:5,onShow:X,onHide:ee},{reference:T(()=>[n.showPicker?(d(),w("div",Mn,[n.inputable?(d(),W(B,{key:0,content:"自定义输入"},{default:T(()=>[r(N,{name:"flow-t",class:"cl-flow__btn-icon is-bg",style:{margin:"0 5px 0 -5px"},onClick:we(D.open,["stop"])},null,8,["onClick"])]),_:1})):O("",!0),p.value?(d(),w("span",jn,q(p.value),1)):(d(),w("span",En,q(E(i)?"输入值":"选择变量"),1)),p.value?(d(),W(N,{key:3,name:"flow-close",class:"cl-flow__btn-icon close",onClick:we(x,["stop"])})):O("",!0)])):(d(),w("div",{key:1,class:"tools-var__btn",ref:E(u)("btn")},null,512))]),default:T(()=>[b("div",$n,[b("div",Pn,[r(H,{modelValue:t.value,"onUpdate:modelValue":L[0]||(L[0]=le=>t.value=le),placeholder:"搜索变量","prefix-icon":E(vt)},null,8,["modelValue","prefix-icon"])]),r(te,{"max-height":"300px"},{default:T(()=>[b("div",{class:"list",ref:E(u)("list"),tabindex:0,onKeydown:we(z,["stop","prevent"])},[(d(!0),w(K,null,ne(h.value,(le,ve)=>(d(),w("div",{class:"group",key:ve},[b("p",On,q(le.label),1),(d(!0),w(K,null,ne(le.params,ye=>(d(),w("div",{class:ce(["item",{active:`${le.id}_${ye.field}`==`${E(v)}_${E(m)}`,focus:C.value==`${le.id}_${ye.field}`}]),key:ye.field,onClick:P=>s(ye,le)},[r(N,{class:"icon",name:"flow-var"}),b("span",Nn,q(ye.field),1),b("span",Ln,q(ye.type),1)],10,Vn))),128))]))),128))],544),E(Q)(h.value)?(d(),w("div",Fn,"未找到匹配项")):O("",!0)]),_:1})]),r(Ce,{modelValue:D.visible,"onUpdate:modelValue":L[2]||(L[2]=le=>D.visible=le),title:"自定义输入"},{footer:T(()=>[r(he,{onClick:D.close},{default:T(()=>L[3]||(L[3]=[se("取消")])),_:1,__:[3]},8,["onClick"]),r(he,{type:"success",onClick:D.save},{default:T(()=>L[4]||(L[4]=[se("保存")])),_:1,__:[4]},8,["onClick"])]),default:T(()=>[r(H,{type:"textarea",modelValue:D.value,"onUpdate:modelValue":L[1]||(L[1]=le=>D.value=le),rows:20,placeholder:"请输入",onChange:D.onChange},null,8,["modelValue","onChange"])]),_:1},8,["modelValue"])]),_:1},512)],8,["disabled"]))])}}}),at=Y(Bn,[["__scopeId","data-v-423b5ca8"]]),Un={class:"form-input-params"},Hn={class:"d"},zn={class:"d"},Wn=I({name:"undefined"}),Yn=I({...Wn,name:"node-base-form-input-params",props:{modelValue:{type:Array,default:()=>[]},field:{type:String,default:"arg"},editField:{type:Boolean,default:!0},disabled:Boolean,placeholder:String,varInputable:Boolean},setup(n){const l=n,e=fe(l,"modelValue"),a=Z(()=>{const A=[];return e.value.forEach((m,v)=>{const i=e.value.findIndex(t=>t.field==m.field);i>=0&&v!=i&&A.push(m.field)}),A});let o=1;function y(){e.value.push({field:`${l.field}${++o}`})}function u(A){e.value.splice(A,1)}return(A,m)=>{const v=S("cl-svg"),i=S("el-input"),t=S("el-icon"),g=S("el-text");return d(),w("div",Un,[n.disabled?O("",!0):(d(),W(v,{key:0,name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:m[0]||(m[0]=f=>y())})),(d(!0),w(K,null,ne(E(e),(f,h)=>(d(),w("div",{class:ce(["item",{"is-error":a.value.includes(f.field)}]),key:h},[b("div",Hn,[r(i,{modelValue:f.field,"onUpdate:modelValue":p=>f.field=p,placeholder:"变量名",class:"name",clearable:"",disabled:!n.editField},null,8,["modelValue","onUpdate:modelValue","disabled"])]),b("div",zn,[r(at,{modelValue:f.name,"onUpdate:modelValue":p=>f.name=p,"node-id":f.nodeId,"onUpdate:nodeId":p=>f.nodeId=p,type:f.type,"onUpdate:type":p=>f.type=p,value:f.value,"onUpdate:value":p=>f.value=p,inputable:n.varInputable},null,8,["modelValue","onUpdate:modelValue","node-id","onUpdate:nodeId","type","onUpdate:type","value","onUpdate:value","inputable"])]),n.disabled?O("",!0):(d(),W(v,{key:0,name:"delete",class:"cl-flow__btn-icon",onClick:p=>u(h)},null,8,["onClick"]))],2))),128)),E(Q)(E(e))&&n.placeholder?(d(),W(g,{key:1,type:"info",size:"small"},{default:T(()=>[r(t,null,{default:T(()=>[r(E(Jt))]),_:1}),se(" "+q(n.placeholder),1)]),_:1})):O("",!0)])}}}),ke=Y(Yn,[["__scopeId","data-v-9dc7872f"]]),Gn={class:"form-text"},Kn=I({name:"undefined"}),Xn=I({...Kn,name:"node-base-form-text",props:{text:{type:[String,Array],default:""}},setup(n){const l=n,e=Z(()=>_t(l.text)?l.text:[l.text]);return(a,o)=>{const y=S("el-text");return d(),w("div",Gn,[(d(!0),w(K,null,ne(e.value,(u,A)=>(d(),W(y,{tag:"p",size:"small",type:"info",key:A},{default:T(()=>[se(q(u),1)]),_:2},1024))),128))])}}}),He=Y(Xn,[["__scopeId","data-v-3967cbda"]]),Jn=()=>({group:"AI",label:"分类器",description:"根据内容调用 LLM 进行智能分类",color:"#409eff",component:An,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{editField:!1,disabled:!0}}},{label:"模型",prop:"options.model",component:{vm:et}},{label:"分类",prop:"options.types",component:{vm:Cn}},{label:"输出变量",component:{vm:He,props:{text:["content<string> 内容","index<number> 分类索引"]}}}]},data:{inputParams:[{field:"content",type:"string"}],outputParams:[{field:"index",type:"number"}],options:{model:{options:[],params:{model:""}},types:[""]}},handle:{source:!1,next:[]},validator(n){var y;const{model:l,types:e}=n.options,a=(y=n.inputParams)==null?void 0:y.find(u=>!u.nodeId);if(a)return`请绑定变量：${a.field}`;const o=e==null?void 0:e.findIndex(u=>!u);if(o>=0)return`请填写分类${o+1}的内容`;if(!l.params.model)return"请选择模型"}}),Qn=Object.freeze(Object.defineProperty({__proto__:null,default:Jn},Symbol.toStringTag,{value:"Module"})),Zn={class:"node-code"},ea=I({name:"undefined"}),ta=I({...ea,name:"node-code",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>(d(),w("div",Zn))}}),na={class:"form-input-params"},aa={class:"d"},oa={class:"d"},sa=I({name:"undefined"}),ra=I({...sa,name:"node-base-form-output-params",props:{modelValue:{type:Array,default:()=>[]},typeInput:Boolean,disabledFields:[Array],editField:{type:Boolean,default:!0},editType:{type:Boolean,default:!0},op:{type:Boolean,default:!0}},setup(n){const l=n,e=fe(l,"modelValue"),a=pe({type:["string","number","array","object","boolean","date"]});let o=0;function y(){o||(o=e.value.length),e.value.push({field:`res${++o}`,type:l.typeInput?"":"string"})}function u(v){e.value.splice(v,1)}function A(v,i){var g;if(!l.editType)return!0;let t=(g=l.disabledFields)==null?void 0:g.includes(v.field);return t||i=="field"&&(t=!l.editField),t}const m=pe({visible:!1,value:"",data:null,open(v){m.data=v,m.value=v.type,m.visible=!0},close(){m.visible=!1},save(){if(!m.value)return ue.warning("请输入内容");m.data&&(m.data.type=m.value),m.close()}});return(v,i)=>{const t=S("cl-svg"),g=S("el-input"),f=S("el-option"),h=S("el-select"),p=S("el-button"),s=S("cl-dialog");return d(),w("div",na,[n.op?(d(),W(t,{key:0,name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:i[0]||(i[0]=x=>y())})):O("",!0),(d(!0),w(K,null,ne(E(e),(x,c)=>(d(),w("div",{class:"item",key:c},[b("div",aa,[r(g,{modelValue:x.field,"onUpdate:modelValue":_=>x.field=_,placeholder:"变量名",class:"name",disabled:A(x,"field")},null,8,["modelValue","onUpdate:modelValue","disabled"])]),b("div",oa,[n.typeInput?(d(),W(g,{key:0,modelValue:x.type,"onUpdate:modelValue":_=>x.type=_,placeholder:"请输入描述"},{suffix:T(()=>[r(t,{name:"flow-fullscreen",class:"cl-flow__btn-icon",onClick:_=>m.open(x)},null,8,["onClick"])]),_:2},1032,["modelValue","onUpdate:modelValue"])):(d(),W(h,{key:1,modelValue:x.type,"onUpdate:modelValue":_=>x.type=_,placeholder:"类型",disabled:A(x,"type")},{default:T(()=>[(d(!0),w(K,null,ne(a.type,_=>(d(),W(f,{key:_,label:_,value:_},null,8,["label","value"]))),128))]),_:2},1032,["modelValue","onUpdate:modelValue","disabled"]))]),n.op?(d(),W(t,{key:0,name:"delete",class:"cl-flow__btn-icon",onClick:_=>u(c)},null,8,["onClick"])):O("",!0)]))),128)),r(s,{modelValue:m.visible,"onUpdate:modelValue":i[2]||(i[2]=x=>m.visible=x),title:"自定义输入"},{footer:T(()=>[r(p,{onClick:m.close},{default:T(()=>i[3]||(i[3]=[se("取消")])),_:1,__:[3]},8,["onClick"]),r(p,{type:"success",onClick:m.save},{default:T(()=>i[4]||(i[4]=[se("保存")])),_:1,__:[4]},8,["onClick"])]),default:T(()=>[r(g,{type:"textarea",modelValue:m.value,"onUpdate:modelValue":i[1]||(i[1]=x=>m.value=x),rows:20,placeholder:"请输入"},null,8,["modelValue"])]),_:1},8,["modelValue"])])}}}),ze=Y(ra,[["__scopeId","data-v-913117c9"]]);function ut({path:n,content:l}){const e=rn.typescript.typescriptDefaults,a=`file:///node_modules/${n}`,o=e.getExtraLibs(),y=tt(o).map(A=>({filePath:A,content:o[A].content})),u=y.find(A=>A.filePath.includes(n));try{u?(u.content=l,e.setExtraLibs(y)):e.addExtraLib(l,a)}catch{}}const ia=`
declare module "axios" {
	// TypeScript Version: 4.7
	export type AxiosHeaderValue = AxiosHeaders | string | string[] | number | boolean | null;

	interface RawAxiosHeaders {
		[key: string]: AxiosHeaderValue;
	}

	type MethodsHeaders = Partial<
		{
			[Key in Method as Lowercase<Key>]: AxiosHeaders;
		} & { common: AxiosHeaders }
	>;

	type AxiosHeaderMatcher =
		| string
		| RegExp
		| ((this: AxiosHeaders, value: string, name: string) => boolean);

	type AxiosHeaderParser = (this: AxiosHeaders, value: AxiosHeaderValue, header: string) => any;

	export class AxiosHeaders {
		constructor(headers?: RawAxiosHeaders | AxiosHeaders | string);

		[key: string]: any;

		set(
			headerName?: string,
			value?: AxiosHeaderValue,
			rewrite?: boolean | AxiosHeaderMatcher
		): AxiosHeaders;
		set(headers?: RawAxiosHeaders | AxiosHeaders | string, rewrite?: boolean): AxiosHeaders;

		get(headerName: string, parser: RegExp): RegExpExecArray | null;
		get(headerName: string, matcher?: true | AxiosHeaderParser): AxiosHeaderValue;

		has(header: string, matcher?: AxiosHeaderMatcher): boolean;

		delete(header: string | string[], matcher?: AxiosHeaderMatcher): boolean;

		clear(matcher?: AxiosHeaderMatcher): boolean;

		normalize(format: boolean): AxiosHeaders;

		concat(
			...targets: Array<AxiosHeaders | RawAxiosHeaders | string | undefined | null>
		): AxiosHeaders;

		toJSON(asStrings?: boolean): RawAxiosHeaders;

		static from(thing?: AxiosHeaders | RawAxiosHeaders | string): AxiosHeaders;

		static accessor(header: string | string[]): AxiosHeaders;

		static concat(
			...targets: Array<AxiosHeaders | RawAxiosHeaders | string | undefined | null>
		): AxiosHeaders;

		setContentType(value: ContentType, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
		getContentType(parser?: RegExp): RegExpExecArray | null;
		getContentType(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasContentType(matcher?: AxiosHeaderMatcher): boolean;

		setContentLength(
			value: AxiosHeaderValue,
			rewrite?: boolean | AxiosHeaderMatcher
		): AxiosHeaders;
		getContentLength(parser?: RegExp): RegExpExecArray | null;
		getContentLength(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasContentLength(matcher?: AxiosHeaderMatcher): boolean;

		setAccept(value: AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
		getAccept(parser?: RegExp): RegExpExecArray | null;
		getAccept(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasAccept(matcher?: AxiosHeaderMatcher): boolean;

		setUserAgent(value: AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
		getUserAgent(parser?: RegExp): RegExpExecArray | null;
		getUserAgent(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasUserAgent(matcher?: AxiosHeaderMatcher): boolean;

		setContentEncoding(
			value: AxiosHeaderValue,
			rewrite?: boolean | AxiosHeaderMatcher
		): AxiosHeaders;
		getContentEncoding(parser?: RegExp): RegExpExecArray | null;
		getContentEncoding(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasContentEncoding(matcher?: AxiosHeaderMatcher): boolean;

		setAuthorization(
			value: AxiosHeaderValue,
			rewrite?: boolean | AxiosHeaderMatcher
		): AxiosHeaders;
		getAuthorization(parser?: RegExp): RegExpExecArray | null;
		getAuthorization(matcher?: AxiosHeaderMatcher): AxiosHeaderValue;
		hasAuthorization(matcher?: AxiosHeaderMatcher): boolean;

		[Symbol.iterator](): IterableIterator<[string, AxiosHeaderValue]>;
	}

	type CommonRequestHeadersList =
		| "Accept"
		| "Content-Length"
		| "User-Agent"
		| "Content-Encoding"
		| "Authorization";

	type ContentType =
		| AxiosHeaderValue
		| "text/html"
		| "text/plain"
		| "multipart/form-data"
		| "application/json"
		| "application/x-www-form-urlencoded"
		| "application/octet-stream";

	export type RawAxiosRequestHeaders = Partial<
		RawAxiosHeaders & {
			[Key in CommonRequestHeadersList]: AxiosHeaderValue;
		} & {
			"Content-Type": ContentType;
		}
	>;

	export type AxiosRequestHeaders = RawAxiosRequestHeaders & AxiosHeaders;

	type CommonResponseHeadersList =
		| "Server"
		| "Content-Type"
		| "Content-Length"
		| "Cache-Control"
		| "Content-Encoding";

	type RawCommonResponseHeaders = {
		[Key in CommonResponseHeadersList]: AxiosHeaderValue;
	} & {
		"set-cookie": string[];
	};

	export type RawAxiosResponseHeaders = Partial<RawAxiosHeaders & RawCommonResponseHeaders>;

	export type AxiosResponseHeaders = RawAxiosResponseHeaders & AxiosHeaders;

	export interface AxiosRequestTransformer {
		(this: InternalAxiosRequestConfig, data: any, headers: AxiosRequestHeaders): any;
	}

	export interface AxiosResponseTransformer {
		(
			this: InternalAxiosRequestConfig,
			data: any,
			headers: AxiosResponseHeaders,
			status?: number
		): any;
	}

	export interface AxiosAdapter {
		(config: InternalAxiosRequestConfig): AxiosPromise;
	}

	export interface AxiosBasicCredentials {
		username: string;
		password: string;
	}

	export interface AxiosProxyConfig {
		host: string;
		port: number;
		auth?: AxiosBasicCredentials;
		protocol?: string;
	}

	export enum HttpStatusCode {
		Continue = 100,
		SwitchingProtocols = 101,
		Processing = 102,
		EarlyHints = 103,
		Ok = 200,
		Created = 201,
		Accepted = 202,
		NonAuthoritativeInformation = 203,
		NoContent = 204,
		ResetContent = 205,
		PartialContent = 206,
		MultiStatus = 207,
		AlreadyReported = 208,
		ImUsed = 226,
		MultipleChoices = 300,
		MovedPermanently = 301,
		Found = 302,
		SeeOther = 303,
		NotModified = 304,
		UseProxy = 305,
		Unused = 306,
		TemporaryRedirect = 307,
		PermanentRedirect = 308,
		BadRequest = 400,
		Unauthorized = 401,
		PaymentRequired = 402,
		Forbidden = 403,
		NotFound = 404,
		MethodNotAllowed = 405,
		NotAcceptable = 406,
		ProxyAuthenticationRequired = 407,
		RequestTimeout = 408,
		Conflict = 409,
		Gone = 410,
		LengthRequired = 411,
		PreconditionFailed = 412,
		PayloadTooLarge = 413,
		UriTooLong = 414,
		UnsupportedMediaType = 415,
		RangeNotSatisfiable = 416,
		ExpectationFailed = 417,
		ImATeapot = 418,
		MisdirectedRequest = 421,
		UnprocessableEntity = 422,
		Locked = 423,
		FailedDependency = 424,
		TooEarly = 425,
		UpgradeRequired = 426,
		PreconditionRequired = 428,
		TooManyRequests = 429,
		RequestHeaderFieldsTooLarge = 431,
		UnavailableForLegalReasons = 451,
		InternalServerError = 500,
		NotImplemented = 501,
		BadGateway = 502,
		ServiceUnavailable = 503,
		GatewayTimeout = 504,
		HttpVersionNotSupported = 505,
		VariantAlsoNegotiates = 506,
		InsufficientStorage = 507,
		LoopDetected = 508,
		NotExtended = 510,
		NetworkAuthenticationRequired = 511
	}

	export type Method =
		| "get"
		| "GET"
		| "delete"
		| "DELETE"
		| "head"
		| "HEAD"
		| "options"
		| "OPTIONS"
		| "post"
		| "POST"
		| "put"
		| "PUT"
		| "patch"
		| "PATCH"
		| "purge"
		| "PURGE"
		| "link"
		| "LINK"
		| "unlink"
		| "UNLINK";

	export type ResponseType =
		| "arraybuffer"
		| "blob"
		| "document"
		| "json"
		| "text"
		| "stream"
		| "formdata";

	export type responseEncoding =
		| "ascii"
		| "ASCII"
		| "ansi"
		| "ANSI"
		| "binary"
		| "BINARY"
		| "base64"
		| "BASE64"
		| "base64url"
		| "BASE64URL"
		| "hex"
		| "HEX"
		| "latin1"
		| "LATIN1"
		| "ucs-2"
		| "UCS-2"
		| "ucs2"
		| "UCS2"
		| "utf-8"
		| "UTF-8"
		| "utf8"
		| "UTF8"
		| "utf16le"
		| "UTF16LE";

	export interface TransitionalOptions {
		silentJSONParsing?: boolean;
		forcedJSONParsing?: boolean;
		clarifyTimeoutError?: boolean;
	}

	export interface GenericAbortSignal {
		readonly aborted: boolean;
		onabort?: ((...args: any) => any) | null;
		addEventListener?: (...args: any) => any;
		removeEventListener?: (...args: any) => any;
	}

	export interface FormDataVisitorHelpers {
		defaultVisitor: SerializerVisitor;
		convertValue: (value: any) => any;
		isVisitable: (value: any) => boolean;
	}

	export interface SerializerVisitor {
		(
			this: GenericFormData,
			value: any,
			key: string | number,
			path: null | Array<string | number>,
			helpers: FormDataVisitorHelpers
		): boolean;
	}

	export interface SerializerOptions {
		visitor?: SerializerVisitor;
		dots?: boolean;
		metaTokens?: boolean;
		indexes?: boolean | null;
	}

	// tslint:disable-next-line
	export interface FormSerializerOptions extends SerializerOptions {}

	export interface ParamEncoder {
		(value: any, defaultEncoder: (value: any) => any): any;
	}

	export interface CustomParamsSerializer {
		(params: Record<string, any>, options?: ParamsSerializerOptions): string;
	}

	export interface ParamsSerializerOptions extends SerializerOptions {
		encode?: ParamEncoder;
		serialize?: CustomParamsSerializer;
	}

	type MaxUploadRate = number;

	type MaxDownloadRate = number;

	type BrowserProgressEvent = any;

	export interface AxiosProgressEvent {
		loaded: number;
		total?: number;
		progress?: number;
		bytes: number;
		rate?: number;
		estimated?: number;
		upload?: boolean;
		download?: boolean;
		event?: BrowserProgressEvent;
		lengthComputable: boolean;
	}

	type Milliseconds = number;

	type AxiosAdapterName = "fetch" | "xhr" | "http" | string;

	type AxiosAdapterConfig = AxiosAdapter | AxiosAdapterName;

	export type AddressFamily = 4 | 6 | undefined;

	export interface LookupAddressEntry {
		address: string;
		family?: AddressFamily;
	}

	export type LookupAddress = string | LookupAddressEntry;

	export interface AxiosRequestConfig<D = any> {
		url?: string;
		method?: Method | string;
		baseURL?: string;
		transformRequest?: AxiosRequestTransformer | AxiosRequestTransformer[];
		transformResponse?: AxiosResponseTransformer | AxiosResponseTransformer[];
		headers?: (RawAxiosRequestHeaders & MethodsHeaders) | AxiosHeaders;
		params?: any;
		paramsSerializer?: ParamsSerializerOptions | CustomParamsSerializer;
		data?: D;
		timeout?: Milliseconds;
		timeoutErrorMessage?: string;
		withCredentials?: boolean;
		adapter?: AxiosAdapterConfig | AxiosAdapterConfig[];
		auth?: AxiosBasicCredentials;
		responseType?: ResponseType;
		responseEncoding?: responseEncoding | string;
		xsrfCookieName?: string;
		xsrfHeaderName?: string;
		onUploadProgress?: (progressEvent: AxiosProgressEvent) => void;
		onDownloadProgress?: (progressEvent: AxiosProgressEvent) => void;
		maxContentLength?: number;
		validateStatus?: ((status: number) => boolean) | null;
		maxBodyLength?: number;
		maxRedirects?: number;
		maxRate?: number | [MaxUploadRate, MaxDownloadRate];
		beforeRedirect?: (
			options: Record<string, any>,
			responseDetails: { headers: Record<string, string>; statusCode: HttpStatusCode }
		) => void;
		socketPath?: string | null;
		transport?: any;
		httpAgent?: any;
		httpsAgent?: any;
		proxy?: AxiosProxyConfig | false;
		cancelToken?: CancelToken;
		decompress?: boolean;
		transitional?: TransitionalOptions;
		signal?: GenericAbortSignal;
		insecureHTTPParser?: boolean;
		env?: {
			FormData?: new (...args: any[]) => object;
		};
		formSerializer?: FormSerializerOptions;
		family?: AddressFamily;
		lookup?:
			| ((
					hostname: string,
					options: object,
					cb: (
						err: Error | null,
						address: LookupAddress | LookupAddress[],
						family?: AddressFamily
					) => void
			  ) => void)
			| ((
					hostname: string,
					options: object
			  ) => Promise<
					| [address: LookupAddressEntry | LookupAddressEntry[], family?: AddressFamily]
					| LookupAddress
			  >);
		withXSRFToken?: boolean | ((config: InternalAxiosRequestConfig) => boolean | undefined);
		fetchOptions?: Record<string, any>;
	}

	// Alias
	export type RawAxiosRequestConfig<D = any> = AxiosRequestConfig<D>;

	export interface InternalAxiosRequestConfig<D = any> extends AxiosRequestConfig<D> {
		headers: AxiosRequestHeaders;
	}

	export interface HeadersDefaults {
		common: RawAxiosRequestHeaders;
		delete: RawAxiosRequestHeaders;
		get: RawAxiosRequestHeaders;
		head: RawAxiosRequestHeaders;
		post: RawAxiosRequestHeaders;
		put: RawAxiosRequestHeaders;
		patch: RawAxiosRequestHeaders;
		options?: RawAxiosRequestHeaders;
		purge?: RawAxiosRequestHeaders;
		link?: RawAxiosRequestHeaders;
		unlink?: RawAxiosRequestHeaders;
	}

	export interface AxiosDefaults<D = any> extends Omit<AxiosRequestConfig<D>, "headers"> {
		headers: HeadersDefaults;
	}

	export interface CreateAxiosDefaults<D = any> extends Omit<AxiosRequestConfig<D>, "headers"> {
		headers?: RawAxiosRequestHeaders | AxiosHeaders | Partial<HeadersDefaults>;
	}

	export interface AxiosResponse<T = any, D = any> {
		data: T;
		status: number;
		statusText: string;
		headers: RawAxiosResponseHeaders | AxiosResponseHeaders;
		config: InternalAxiosRequestConfig<D>;
		request?: any;
	}

	export class AxiosError<T = unknown, D = any> extends Error {
		constructor(
			message?: string,
			code?: string,
			config?: InternalAxiosRequestConfig<D>,
			request?: any,
			response?: AxiosResponse<T, D>
		);

		config?: InternalAxiosRequestConfig<D>;
		code?: string;
		request?: any;
		response?: AxiosResponse<T, D>;
		isAxiosError: boolean;
		status?: number;
		toJSON: () => object;
		cause?: Error;
		static from<T = unknown, D = any>(
			error: Error | unknown,
			code?: string,
			config?: InternalAxiosRequestConfig<D>,
			request?: any,
			response?: AxiosResponse<T, D>,
			customProps?: object
		): AxiosError<T, D>;
		static readonly ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
		static readonly ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
		static readonly ERR_BAD_OPTION = "ERR_BAD_OPTION";
		static readonly ERR_NETWORK = "ERR_NETWORK";
		static readonly ERR_DEPRECATED = "ERR_DEPRECATED";
		static readonly ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
		static readonly ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
		static readonly ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
		static readonly ERR_INVALID_URL = "ERR_INVALID_URL";
		static readonly ERR_CANCELED = "ERR_CANCELED";
		static readonly ECONNABORTED = "ECONNABORTED";
		static readonly ETIMEDOUT = "ETIMEDOUT";
	}

	export class CanceledError<T> extends AxiosError<T> {}

	export type AxiosPromise<T = any> = Promise<AxiosResponse<T>>;

	export interface CancelStatic {
		new (message?: string): Cancel;
	}

	export interface Cancel {
		message: string | undefined;
	}

	export interface Canceler {
		(message?: string, config?: AxiosRequestConfig, request?: any): void;
	}

	export interface CancelTokenStatic {
		new (executor: (cancel: Canceler) => void): CancelToken;
		source(): CancelTokenSource;
	}

	export interface CancelToken {
		promise: Promise<Cancel>;
		reason?: Cancel;
		throwIfRequested(): void;
	}

	export interface CancelTokenSource {
		token: CancelToken;
		cancel: Canceler;
	}

	export interface AxiosInterceptorOptions {
		synchronous?: boolean;
		runWhen?: (config: InternalAxiosRequestConfig) => boolean;
	}

	export interface AxiosInterceptorManager<V> {
		use(
			onFulfilled?: ((value: V) => V | Promise<V>) | null,
			onRejected?: ((error: any) => any) | null,
			options?: AxiosInterceptorOptions
		): number;
		eject(id: number): void;
		clear(): void;
	}

	export class Axios {
		constructor(config?: AxiosRequestConfig);
		defaults: AxiosDefaults;
		interceptors: {
			request: AxiosInterceptorManager<InternalAxiosRequestConfig>;
			response: AxiosInterceptorManager<AxiosResponse>;
		};
		getUri(config?: AxiosRequestConfig): string;
		request<T = any, R = AxiosResponse<T>, D = any>(config: AxiosRequestConfig<D>): Promise<R>;
		get<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		delete<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		head<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		options<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		post<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		put<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		patch<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		postForm<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		putForm<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
		patchForm<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			data?: D,
			config?: AxiosRequestConfig<D>
		): Promise<R>;
	}

	export interface AxiosInstance extends Axios {
		<T = any, R = AxiosResponse<T>, D = any>(config: AxiosRequestConfig<D>): Promise<R>;
		<T = any, R = AxiosResponse<T>, D = any>(
			url: string,
			config?: AxiosRequestConfig<D>
		): Promise<R>;

		defaults: Omit<AxiosDefaults, "headers"> & {
			headers: HeadersDefaults & {
				[key: string]: AxiosHeaderValue;
			};
		};
	}

	export interface GenericFormData {
		append(name: string, value: any, options?: any): any;
	}

	export interface GenericHTMLFormElement {
		name: string;
		method: string;
		submit(): void;
	}

	export function getAdapter(
		adapters: AxiosAdapterConfig | AxiosAdapterConfig[] | undefined
	): AxiosAdapter;

	export function toFormData(
		sourceObj: object,
		targetFormData?: GenericFormData,
		options?: FormSerializerOptions
	): GenericFormData;

	export function formToJSON(form: GenericFormData | GenericHTMLFormElement): object;

	export function isAxiosError<T = any, D = any>(payload: any): payload is AxiosError<T, D>;

	export function spread<T, R>(callback: (...args: T[]) => R): (array: T[]) => R;

	export function isCancel(value: any): value is Cancel;

	export function all<T>(values: Array<T | Promise<T>>): Promise<T[]>;

	export interface AxiosStatic extends AxiosInstance {
		create(config?: CreateAxiosDefaults): AxiosInstance;
		Cancel: CancelStatic;
		CancelToken: CancelTokenStatic;
		Axios: typeof Axios;
		AxiosError: typeof AxiosError;
		HttpStatusCode: typeof HttpStatusCode;
		readonly VERSION: string;
		isCancel: typeof isCancel;
		all: typeof all;
		spread: typeof spread;
		isAxiosError: typeof isAxiosError;
		toFormData: typeof toFormData;
		formToJSON: typeof formToJSON;
		getAdapter: typeof getAdapter;
		CanceledError: typeof CanceledError;
		AxiosHeaders: typeof AxiosHeaders;
	}

	const axios: AxiosStatic;

	export default axios;
}
`,la=`
/**
 * Repository
 */
interface Repository {
	/**
	 * any target that is managed by this repository.
	 * If this repository manages any from schema,
	 * then it returns a name of that schema instead.
	 */
	readonly target: any;
	/**
	 * any Manager used by this repository.
	 */
	readonly manager: any;
	/**
	 * Query runner provider used for this repository.
	 */
	readonly queryRunner?: any;
	/**
	 * any metadata of the any current repository manages.
	 */
	get metadata(): any;
	/**
	 * Creates a new query builder that can be used to build a SQL query.
	 */
	createQueryBuilder(alias?: string, queryRunner?: any): any;
	/**
	 * Checks if any has an id.
	 * If any composite compose ids, it will check them all.
	 */
	hasId(any: any): boolean;
	/**
	 * Gets any mixed id.
	 */
	getId(any: any): any;
	/**
	 * Creates a new any instance.
	 */
	create(): any;
	/**
	 * Creates new entities and copies all any properties from given objects into their new entities.
	 * Note that it copies only properties that are present in any schema.
	 */
	create(anyLikeArray: any): any[];
	/**
	 * Creates a new any instance and copies all any properties from this object into a new any.
	 * Note that it copies only properties that are present in any schema.
	 */
	create(anyLike: any): any;
	/**
	 * Merges multiple entities (or any-like objects) into a given any.
	 */
	merge(mergeIntoany: any, ...anyLikes: any): any;
	/**
	 * Creates a new any from the given plain javascript object. If any already exist in the database, then
	 * it loads it (and everything related to it), replaces all values with the new ones from the given object
	 * and returns this new any. This new any is actually a loaded from the db any with all properties
	 * replaced from the new object.
	 *
	 * Note that given any-like object must have an any id / primary key to find any by.
	 * Returns undefined if any with given id was not found.
	 */
	preload(anyLike: any): Promise<any | undefined>;
	/**
	 * Saves all given entities in the database.
	 * If entities do not exist in the database then inserts, otherwise updates.
	 */
	save(
		entities: any[],
		options: any & {
			reload: false;
		}
	): Promise<any[]>;
	/**
	 * Saves all given entities in the database.
	 * If entities do not exist in the database then inserts, otherwise updates.
	 */
	save(entities: any[], options?: any): Promise<any[]>;
	/**
	 * Saves a given any in the database.
	 * If any does not exist in the database then inserts, otherwise updates.
	 */
	save(
		any: any,
		options: any & {
			reload: false;
		}
	): Promise<any>;
	/**
	 * Saves a given any in the database.
	 * If any does not exist in the database then inserts, otherwise updates.
	 */
	save(any: any, options?: any): any;
	/**
	 * Removes a given entities from the database.
	 */
	remove(entities: any[], options?: any): Promise<any[]>;
	/**
	 * Removes a given any from the database.
	 */
	remove(any: any, options?: any): Promise<any>;
	/**
	 * Records the delete date of all given entities.
	 */
	softRemove(
		entities: any[],
		options: any & {
			reload: false;
		}
	): Promise<any[]>;
	/**
	 * Records the delete date of all given entities.
	 */
	softRemove(entities: any[], options?: any): Promise<any[]>;
	/**
	 * Records the delete date of a given any.
	 */
	softRemove(
		any: any,
		options: any & {
			reload: false;
		}
	): Promise<any>;
	/**
	 * Records the delete date of a given any.
	 */
	softRemove(any: any, options?: any): Promise<any>;
	/**
	 * Recovers all given entities in the database.
	 */
	recover(
		entities: any[],
		options: any & {
			reload: false;
		}
	): Promise<any[]>;
	/**
	 * Recovers all given entities in the database.
	 */
	recover(entities: any[], options?: any): Promise<any[]>;
	/**
	 * Recovers a given any in the database.
	 */
	recover(
		any: any,
		options: any & {
			reload: false;
		}
	): Promise<any>;
	/**
	 * Recovers a given any in the database.
	 */
	recover(any: any, options?: any): Promise<any>;
	/**
	 * Inserts a given any into the database.
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient INSERT query.
	 * Does not check if any exist in the database, so query will fail if duplicate any is being inserted.
	 */
	insert(any: any | any[]): Promise<any>;
	/**
	 * Updates any partially. any can be found by a given conditions.
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient UPDATE query.
	 * Does not check if any exist in the database.
	 */
	update(criteria: any, partialany: any): Promise<any>;
	/**
	 * Inserts a given any into the database, unless a unique constraint conflicts then updates the any
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient INSERT ... ON CONFLICT DO UPDATE/ON DUPLICATE KEY UPDATE query.
	 */
	upsert(anyOrEntities: any | any[], conflictPathsOrOptions: string[] | any): Promise<any>;
	/**
	 * Deletes entities by a given criteria.
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient DELETE query.
	 * Does not check if any exist in the database.
	 */
	delete(criteria: any): Promise<any>;
	/**
	 * Records the delete date of entities by a given criteria.
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient SOFT-DELETE query.
	 * Does not check if any exist in the database.
	 */
	softDelete(criteria: any): Promise<any>;
	/**
	 * Restores entities by a given criteria.
	 * Unlike save method executes a primitive operation without cascades, relations and other operations included.
	 * Executes fast and efficient SOFT-DELETE query.
	 * Does not check if any exist in the database.
	 */
	restore(criteria: any): Promise<any>;
	/**
	 * Checks whether any any exists that matches the given options.
	 *
	 * @deprecated use \`exists\` method instead, for example:
	 *
	 * .exists()
	 */
	exist(options?: any): Promise<boolean>;
	/**
	 * Checks whether any any exists that matches the given options.
	 */
	exists(options?: any): Promise<boolean>;
	/**
	 * Checks whether any any exists that matches the given conditions.
	 */
	existsBy(where: any | any[]): Promise<boolean>;
	/**
	 * Counts entities that match given options.
	 * Useful for pagination.
	 */
	count(options?: any): Promise<number>;
	/**
	 * Counts entities that match given conditions.
	 * Useful for pagination.
	 */
	countBy(where: any | any[]): Promise<number>;
	/**
	 * Return the SUM of a column
	 */
	sum(columnName: any, where?: any | any[]): Promise<number | null>;
	/**
	 * Return the AVG of a column
	 */
	average(columnName: any, where?: any | any[]): Promise<number | null>;
	/**
	 * Return the MIN of a column
	 */
	minimum(columnName: any, where?: any | any[]): Promise<number | null>;
	/**
	 * Return the MAX of a column
	 */
	maximum(columnName: any, where?: any | any[]): Promise<number | null>;
	/**
	 * Finds entities that match given find options.
	 */
	find(options?: any): Promise<any[]>;
	/**
	 * Finds entities that match given find options.
	 */
	findBy(where: any | any[]): Promise<any[]>;
	/**
	 * Finds entities that match given find options.
	 * Also counts all entities that match given conditions,
	 * but ignores pagination settings (from and take options).
	 */
	findAndCount(options?: any): Promise<[any[], number]>;
	/**
	 * Finds entities that match given WHERE conditions.
	 * Also counts all entities that match given conditions,
	 * but ignores pagination settings (from and take options).
	 */
	findAndCountBy(where: any | any[]): Promise<[any[], number]>;
	/**
	 * Finds entities with ids.
	 * Optionally find options or conditions can be applied.
	 *
	 * @deprecated use \`findBy\` method instead in conjunction with \`In\` operator, for example:
	 *
	 * .findBy({
	 *     id: In([1, 2, 3])
	 * })
	 */
	findByIds(ids: any[]): Promise<any[]>;
	/**
	 * Finds first any by a given find options.
	 * If any was not found in the database - returns null.
	 */
	findOne(options: any): Promise<any | null>;
	/**
	 * Finds first any that matches given where condition.
	 * If any was not found in the database - returns null.
	 */
	findOneBy(where: any | any[]): Promise<any | null>;
	/**
	 * Finds first any that matches given id.
	 * If any was not found in the database - returns null.
	 *
	 * @deprecated use \`findOneBy\` method instead in conjunction with \`In\` operator, for example:
	 *
	 * .findOneBy({
	 *     id: 1 // where "id" is your primary column name
	 * })
	 */
	findOneById(id: number | string | Date | any): Promise<any | null>;
	/**
	 * Finds first any by a given find options.
	 * If any was not found in the database - rejects with error.
	 */
	findOneOrFail(options: any): Promise<any>;
	/**
	 * Finds first any that matches given where condition.
	 * If any was not found in the database - rejects with error.
	 */
	findOneByOrFail(where: any | any[]): Promise<any>;
	/**
	 * Executes a raw SQL query and returns a raw database results.
	 * Raw query execution is supported only by relational databases (MongoDB is not supported).
	 */
	query(query: string, parameters?: any[]): Promise<any>;
	/**
	 * Clears all the data from the given table/collection (truncates/drops it).
	 *
	 * Note: this method uses TRUNCATE and may not work as you expect in transactions on some platforms.
	 * @see https://stackoverflow.com/a/5972738/925151
	 */
	clear(): Promise<void>;
	/**
	 * Increments some column by provided value of the entities matched given conditions.
	 */
	increment(conditions: any, propertyPath: string, value: number | string): Promise<any>;
	/**
	 * Decrements some column by provided value of the entities matched given conditions.
	 */
	decrement(conditions: any, propertyPath: string, value: number | string): Promise<any>;
	/**
	 * Extends repository with provided functions.
	 */
	extend<CustomRepository>(
		customs: CustomRepository & ThisType<this & CustomRepository>
	): this & CustomRepository;

	[key: string]: any;
}

/**
 * App
 */
interface App {
	/**
	 * 获得基础目录
	 */
	getBaseDir(): string;
	/**
	 * 获得应用目录
	 */
	getAppDir(): string;
	/**
	 * 获得环境
	 */
	getEnv(): string;
	/**
	 * 获得框架
	 */
	getFramework(): any;
	/**
	 * 获得当前进程类型
	 */
	getProcessType(): any;
	/**
	 * 获得全局容器
	 */
	getApplicationContext(): any;
	/**
	 * 获得配置
	 * @param key 配置key
	 */
	getConfig(key?: string): any;
	/**
	 * 获得日志
	 * @param name
	 */
	getLogger(name?: string): any;
	/**
	 * 获得核心日志
	 */
	getCoreLogger(): any;
	/**
	 * 创建日志
	 * @param name
	 * @param options
	 */
	createLogger(name: string, options: any): any;
	/**
	 * 获得当前应用名称
	 */
	getProjectName(): string;
	/**
	 * 创建一个带有RequestContainer的上下文
	 * @param args 参数
	 */
	createAnonymousContext(...args: any[]): any;
	/**
	 * 创建一个带有RequestContainer的上下文
	 * @param BaseContextLoggerClass 上下文日志类
	 */
	setContextLoggerClass(BaseContextLoggerClass: any): void;
	/**
	 * 新增配置
	 * @param obj 配置对象
	 */
	addConfigObject(obj: any): any;
	/**
	 * 设置属性
	 * @param key 属性名
	 * @param value 属性值
	 */
	setAttr(key: string, value: any): any;
	/**
	 * 获得属性
	 * @param key
	 */
	getAttr<T>(key: string): T;
	/**
	 * 使用中间件
	 * @param Middleware
	 */
	useMiddleware<R, N>(Middleware): void;
	/**
	 * 获得中间件
	 */
	getMiddleware<R, N>(): any;
	/**
	 * 使用过滤器
	 * @param Filter 过滤器
	 */
	useFilter<R, N>(Filter): void;
	/**
	 * 新增全局守卫
	 * @param guard
	 */
	useGuard(guard): void;
	/**
	 * 获得命名空间
	 */
	getNamespace(): string;

	[key: string]: any;
}

/**
 * OrmManager
 */
interface OrmManager {
	/**
	 * 获得数据源
	 * @param dataSourceName
	 */
	getDataSource(dataSourceName: string): any;
	/**
	 * 检查数据源是否存在
	 * @param dataSourceName
	 */
	hasDataSource(dataSourceName: string): boolean;
	/**
	 * 获得所有数据源名称
	 */
	getDataSourceNames(): string[];
	/**
	 * 获得所有数据源
	 */
	getAllDataSources(): Map<string, any>;
	/**
	 * 检查数据源是否连接
	 * @param dataSourceName
	 */
	isConnected(dataSourceName: string): Promise<boolean>;
	/**
	 * 创建数据源实例
	 * @param config
	 * @param clientName
	 * @param options
	 */
	createInstance(
		config: any,
		clientName: any,
		options?: {
			validateConnection?: boolean;
			cacheInstance?: boolean | undefined;
		}
	): Promise<any>;
	/**
	 * 获得model或者repository的数据源名称
	 * @param modelOrRepository
	 */
	getDataSourceNameByModel(modelOrRepository: any): string | undefined;
	/**
	 * 获得名称
	 */
	getName(): string;
	/**
	 * 停止
	 */
	stop(): Promise<void>;
	/**
	 * 获得默认数据源名称
	 */
	getDefaultDataSourceName(): string;
	/**
	 * 获得数据源优先级
	 * @param name
	 */
	getDataSourcePriority(name: string): string;
	/**
	 * 是否高优先级
	 * @param name
	 */
	isHighPriority(name: string): boolean;
	/**
	 * 是否中等优先级
	 * @param
	 */
	isMediumPriority(name: string): boolean;
	/**
	 * 是否低优先级
	 * @param name
	 */
	isLowPriority(name: string): boolean;

	[key: string]: any;
}

/**
 * PluginService
 */
interface PluginService {
	/**
	 * 获得插件配置
	 * @param key 插件key
	 */
	getConfig(key: string): Promise<any>;
	/**
	 * 调用插件
	 * @param key 插件key
	 * @param method 方法
	 * @param params 参数
	 * @returns
	 */
	invoke(key: string, method: string, ...params: any[]): Promise<any>;
	/**
	 * 获得插件实例
	 * @param key 插件key
	 * @returns
	 */
	getInstance(key: string): Promise<any>;

	[key: string]: any;
}

/**
 * MidwayCache
 */
interface MidwayCache {
	/**
	 * 设置缓存
	 * @param key
	 * @param value
	 * @param ttl
	 * @returns
	 */
	set: (key: string, value: unknown, ttl?: number) => Promise<void>;
	/**
	 * 获得缓存
	 * @param key
	 * @returns
	 */
	get: <T>(key: string) => Promise<T | undefined>;
	/**
	 * 删除缓存
	 * @param key
	 * @returns
	 */
	del: (key: string) => Promise<void>;
	/**
	 * 重置缓存
	 * @returns
	 */
	reset: () => Promise<void>;

	[key: string]: any;
}

/**
 * 代码执行基类
 */

declare class Base {
	/**
	 * 数据源管理器
	 */
	typeORMDataSourceManager: OrmManager;

	/**
	 * 应用
	 */
	app: App;
	/**
	 * 插件服务
	 */
	pluginService: PluginService;

	/**
	 * 缓存
	 */
	cache: MidwayCache;

	/**
     * 上下文
     */
    context: any;

	/**
     * 上下文
     */
    node: any;

	/**
	 * 主函数
	 */
	main(params: any): Promise<any>;

	/**
	 * 执行sql
	 * @param sql sql语句
	 * @param params 参数
	 * @param dataSource 数据源
	 */
	execSql(sql: string, params, dataSource): Promise<any>;

	/**
	 * 获得typeorm的Repository
	 * @param anyName
	 * @returns
	 */
	getRepository(anyName: string): Promise<Repository>;

	/**
	 * 调用service
	 * @param service 服务
	 * @param method 方法
	 * @param args 参数
	 * @returns
	 */
	invokeService(service: string, method: string, ...args): Promise<any>;

	/**
	 * 调用插件
	 * @param key 插件的key
	 * @param method 插件的方法
	 * @param args 参数
	 * @returns
	 */
	invokePlugin(key: string, method: string, ...args): Promise<any>;
}
`,ca=`
declare module "dayjs" {
	function dayjs(date?: dayjs.ConfigType): dayjs.Dayjs;

	function dayjs(
		date?: dayjs.ConfigType,
		format?: dayjs.OptionType,
		strict?: boolean
	): dayjs.Dayjs;

	function dayjs(
		date?: dayjs.ConfigType,
		format?: dayjs.OptionType,
		locale?: string,
		strict?: boolean
	): dayjs.Dayjs;

	namespace dayjs {
		interface ConfigTypeMap {
			default: string | number | Date | Dayjs | null | undefined;
		}

		export type ConfigType = ConfigTypeMap[keyof ConfigTypeMap];

		export interface FormatObject {
			locale?: string;
			format?: string;
			utc?: boolean;
		}

		export type OptionType = FormatObject | string | string[];

		export type UnitTypeShort = "d" | "D" | "M" | "y" | "h" | "m" | "s" | "ms";

		export type UnitTypeLong =
			| "millisecond"
			| "second"
			| "minute"
			| "hour"
			| "day"
			| "month"
			| "year"
			| "date";

		export type UnitTypeLongPlural =
			| "milliseconds"
			| "seconds"
			| "minutes"
			| "hours"
			| "days"
			| "months"
			| "years"
			| "dates";

		export type UnitType = UnitTypeLong | UnitTypeLongPlural | UnitTypeShort;

		export type OpUnitType = UnitType | "week" | "weeks" | "w";
		export type QUnitType = UnitType | "quarter" | "quarters" | "Q";
		export type ManipulateType = Exclude<OpUnitType, "date" | "dates">;
		class Dayjs {
			constructor(config?: ConfigType);
			/**
			 * All Day.js objects are immutable. Still, \`dayjs#clone\` can create a clone of the current object if you need one.
			 * \`\`\`
			 * dayjs().clone()// => Dayjs
			 * dayjs(dayjs('2019-01-25')) // passing a Dayjs object to a constructor will also clone it
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/parse/dayjs-clone
			 */
			clone(): Dayjs;
			/**
			 * This returns a \`boolean\` indicating whether the Day.js object contains a valid date or not.
			 * \`\`\`
			 * dayjs().isValid()// => boolean
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/parse/is-valid
			 */
			isValid(): boolean;
			/**
			 * Get the year.
			 * \`\`\`
			 * dayjs().year()// => 2020
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/year
			 */
			year(): number;
			/**
			 * Set the year.
			 * \`\`\`
			 * dayjs().year(2000)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/year
			 */
			year(value: number): Dayjs;
			/**
			 * Get the month.
			 *
			 * Months are zero indexed, so January is month 0.
			 * \`\`\`
			 * dayjs().month()// => 0-11
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/month
			 */
			month(): number;
			/**
			 * Set the month.
			 *
			 * Months are zero indexed, so January is month 0.
			 *
			 * Accepts numbers from 0 to 11. If the range is exceeded, it will bubble up to the next year.
			 * \`\`\`
			 * dayjs().month(0)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/month
			 */
			month(value: number): Dayjs;
			/**
			 * Get the date of the month.
			 * \`\`\`
			 * dayjs().date()// => 1-31
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/date
			 */
			date(): number;
			/**
			 * Set the date of the month.
			 *
			 * Accepts numbers from 1 to 31. If the range is exceeded, it will bubble up to the next months.
			 * \`\`\`
			 * dayjs().date(1)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/date
			 */
			date(value: number): Dayjs;
			/**
			 * Get the day of the week.
			 *
			 * Returns numbers from 0 (Sunday) to 6 (Saturday).
			 * \`\`\`
			 * dayjs().day()// 0-6
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/day
			 */
			day(): 0 | 1 | 2 | 3 | 4 | 5 | 6;
			/**
			 * Set the day of the week.
			 *
			 * Accepts numbers from 0 (Sunday) to 6 (Saturday). If the range is exceeded, it will bubble up to next weeks.
			 * \`\`\`
			 * dayjs().day(0)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/day
			 */
			day(value: number): Dayjs;
			/**
			 * Get the hour.
			 * \`\`\`
			 * dayjs().hour()// => 0-23
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/hour
			 */
			hour(): number;
			/**
			 * Set the hour.
			 *
			 * Accepts numbers from 0 to 23. If the range is exceeded, it will bubble up to the next day.
			 * \`\`\`
			 * dayjs().hour(12)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/hour
			 */
			hour(value: number): Dayjs;
			/**
			 * Get the minutes.
			 * \`\`\`
			 * dayjs().minute()// => 0-59
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/minute
			 */
			minute(): number;
			/**
			 * Set the minutes.
			 *
			 * Accepts numbers from 0 to 59. If the range is exceeded, it will bubble up to the next hour.
			 * \`\`\`
			 * dayjs().minute(59)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/minute
			 */
			minute(value: number): Dayjs;
			/**
			 * Get the seconds.
			 * \`\`\`
			 * dayjs().second()// => 0-59
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/second
			 */
			second(): number;
			/**
			 * Set the seconds.
			 *
			 * Accepts numbers from 0 to 59. If the range is exceeded, it will bubble up to the next minutes.
			 * \`\`\`
			 * dayjs().second(1)// Dayjs
			 * \`\`\`
			 */
			second(value: number): Dayjs;
			/**
			 * Get the milliseconds.
			 * \`\`\`
			 * dayjs().millisecond()// => 0-999
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/millisecond
			 */
			millisecond(): number;
			/**
			 * Set the milliseconds.
			 *
			 * Accepts numbers from 0 to 999. If the range is exceeded, it will bubble up to the next seconds.
			 * \`\`\`
			 * dayjs().millisecond(1)// => Dayjs
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/millisecond
			 */
			millisecond(value: number): Dayjs;
			/**
			 * Generic setter, accepting unit as first argument, and value as second, returns a new instance with the applied changes.
			 *
			 * In general:
			 * \`\`\`
			 * dayjs().set(unit, value) === dayjs()[unit](value)
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 * \`\`\`
			 * dayjs().set('date', 1)
			 * dayjs().set('month', 3) // April
			 * dayjs().set('second', 30)
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/set
			 */
			set(unit: UnitType, value: number): Dayjs;
			/**
			 * String getter, returns the corresponding information getting from Day.js object.
			 *
			 * In general:
			 * \`\`\`
			 * dayjs().get(unit) === dayjs()[unit]()
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 * \`\`\`
			 * dayjs().get('year')
			 * dayjs().get('month') // start 0
			 * dayjs().get('date')
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/get-set/get
			 */
			get(unit: UnitType): number;
			/**
			 * Returns a cloned Day.js object with a specified amount of time added.
			 * \`\`\`
			 * dayjs().add(7, 'day')// => Dayjs
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/manipulate/add
			 */
			add(value: number, unit?: ManipulateType): Dayjs;
			/**
			 * Returns a cloned Day.js object with a specified amount of time subtracted.
			 * \`\`\`
			 * dayjs().subtract(7, 'year')// => Dayjs
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/manipulate/subtract
			 */
			subtract(value: number, unit?: ManipulateType): Dayjs;
			/**
			 * Returns a cloned Day.js object and set it to the start of a unit of time.
			 * \`\`\`
			 * dayjs().startOf('year')// => Dayjs
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/manipulate/start-of
			 */
			startOf(unit: OpUnitType): Dayjs;
			/**
			 * Returns a cloned Day.js object and set it to the end of a unit of time.
			 * \`\`\`
			 * dayjs().endOf('month')// => Dayjs
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/manipulate/end-of
			 */
			endOf(unit: OpUnitType): Dayjs;
			/**
			 * Get the formatted date according to the string of tokens passed in.
			 *
			 * To escape characters, wrap them in square brackets (e.g. [MM]).
			 * \`\`\`
			 * dayjs().format()// => current date in ISO8601, without fraction seconds e.g. '2020-04-02T08:02:17-05:00'
			 * dayjs('2019-01-25').format('[YYYYescape] YYYY-MM-DDTHH:mm:ssZ[Z]')// 'YYYYescape 2019-01-25T00:00:00-02:00Z'
			 * dayjs('2019-01-25').format('DD/MM/YYYY') // '25/01/2019'
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/display/format
			 */
			format(template?: string): string;
			/**
			 * This indicates the difference between two date-time in the specified unit.
			 *
			 * To get the difference in milliseconds, use \`dayjs#diff\`
			 * \`\`\`
			 * const date1 = dayjs('2019-01-25')
			 * const date2 = dayjs('2018-06-05')
			 * date1.diff(date2) // 20214000000 default milliseconds
			 * date1.diff() // milliseconds to current time
			 * \`\`\`
			 *
			 * To get the difference in another unit of measurement, pass that measurement as the second argument.
			 * \`\`\`
			 * const date1 = dayjs('2019-01-25')
			 * date1.diff('2018-06-05', 'month') // 7
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/display/difference
			 */
			diff(date?: ConfigType, unit?: QUnitType | OpUnitType, float?: boolean): number;
			/**
			 * This returns the number of **milliseconds** since the Unix Epoch of the Day.js object.
			 * \`\`\`
			 * dayjs('2019-01-25').valueOf() // 1548381600000
			 * +dayjs(1548381600000) // 1548381600000
			 * \`\`\`
			 * To get a Unix timestamp (the number of seconds since the epoch) from a Day.js object, you should use Unix Timestamp \`dayjs#unix()\`.
			 *
			 * Docs: https://day.js.org/docs/en/display/unix-timestamp-milliseconds
			 */
			valueOf(): number;
			/**
			 * This returns the Unix timestamp (the number of **seconds** since the Unix Epoch) of the Day.js object.
			 * \`\`\`
			 * dayjs('2019-01-25').unix() // 1548381600
			 * \`\`\`
			 * This value is floored to the nearest second, and does not include a milliseconds component.
			 *
			 * Docs: https://day.js.org/docs/en/display/unix-timestamp
			 */
			unix(): number;
			/**
			 * Get the number of days in the current month.
			 * \`\`\`
			 * dayjs('2019-01-25').daysInMonth() // 31
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/display/days-in-month
			 */
			daysInMonth(): number;
			/**
			 * To get a copy of the native \`Date\` object parsed from the Day.js object use \`dayjs#toDate\`.
			 * \`\`\`
			 * dayjs('2019-01-25').toDate()// => Date
			 * \`\`\`
			 */
			toDate(): Date;
			/**
			 * To serialize as an ISO 8601 string.
			 * \`\`\`
			 * dayjs('2019-01-25').toJSON() // '2019-01-25T02:00:00.000Z'
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/display/as-json
			 */
			toJSON(): string;
			/**
			 * To format as an ISO 8601 string.
			 * \`\`\`
			 * dayjs('2019-01-25').toISOString() // '2019-01-25T02:00:00.000Z'
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/display/as-iso-string
			 */
			toISOString(): string;
			/**
			 * Returns a string representation of the date.
			 * \`\`\`
			 * dayjs('2019-01-25').toString() // 'Fri, 25 Jan 2019 02:00:00 GMT'
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/display/as-string
			 */
			toString(): string;
			/**
			 * Get the UTC offset in minutes.
			 * \`\`\`
			 * dayjs().utcOffset()
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/manipulate/utc-offset
			 */
			utcOffset(): number;
			/**
			 * This indicates whether the Day.js object is before the other supplied date-time.
			 * \`\`\`
			 * dayjs().isBefore(dayjs('2011-01-01')) // default milliseconds
			 * \`\`\`
			 * If you want to limit the granularity to a unit other than milliseconds, pass it as the second parameter.
			 * \`\`\`
			 * dayjs().isBefore('2011-01-01', 'year')// => boolean
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/query/is-before
			 */
			isBefore(date?: ConfigType, unit?: OpUnitType): boolean;
			/**
			 * This indicates whether the Day.js object is the same as the other supplied date-time.
			 * \`\`\`
			 * dayjs().isSame(dayjs('2011-01-01')) // default milliseconds
			 * \`\`\`
			 * If you want to limit the granularity to a unit other than milliseconds, pass it as the second parameter.
			 * \`\`\`
			 * dayjs().isSame('2011-01-01', 'year')// => boolean
			 * \`\`\`
			 * Docs: https://day.js.org/docs/en/query/is-same
			 */
			isSame(date?: ConfigType, unit?: OpUnitType): boolean;
			/**
			 * This indicates whether the Day.js object is after the other supplied date-time.
			 * \`\`\`
			 * dayjs().isAfter(dayjs('2011-01-01')) // default milliseconds
			 * \`\`\`
			 * If you want to limit the granularity to a unit other than milliseconds, pass it as the second parameter.
			 * \`\`\`
			 * dayjs().isAfter('2011-01-01', 'year')// => boolean
			 * \`\`\`
			 * Units are case insensitive, and support plural and short forms.
			 *
			 * Docs: https://day.js.org/docs/en/query/is-after
			 */
			isAfter(date?: ConfigType, unit?: OpUnitType): boolean;

			locale(): string;

			locale(preset: string | ILocale, object?: Partial<ILocale>): Dayjs;
		}

		export type PluginFunc<T = unknown> = (option: T, c: typeof Dayjs, d: typeof dayjs) => void;

		export function extend<T = unknown>(plugin: PluginFunc<T>, option?: T): Dayjs;

		export function locale(
			preset?: string | ILocale,
			object?: Partial<ILocale>,
			isLocal?: boolean
		): string;

		export function isDayjs(d: any): d is Dayjs;

		export function unix(t: number): Dayjs;

		const Ls: { [key: string]: ILocale };
	}

	export default dayjs;
}
`,da=`
declare module "lodash" {
	class lodash {
		constructor(value: any);

		add(...args: any[]): any;

		after(...args: any[]): any;

		ary(...args: any[]): any;

		assign(...args: any[]): any;

		assignIn(...args: any[]): any;

		assignInWith(...args: any[]): any;

		assignWith(...args: any[]): any;

		at(...args: any[]): any;

		attempt(...args: any[]): any;

		before(...args: any[]): any;

		bind(...args: any[]): any;

		bindAll(...args: any[]): any;

		bindKey(...args: any[]): any;

		camelCase(...args: any[]): any;

		capitalize(...args: any[]): any;

		castArray(...args: any[]): any;

		ceil(...args: any[]): any;

		chain(): any;

		chunk(...args: any[]): any;

		clamp(...args: any[]): any;

		clone(...args: any[]): any;

		cloneDeep(...args: any[]): any;

		cloneDeepWith(...args: any[]): any;

		cloneWith(...args: any[]): any;

		commit(): any;

		compact(...args: any[]): any;

		concat(...args: any[]): any;

		cond(...args: any[]): any;

		conforms(...args: any[]): any;

		conformsTo(...args: any[]): any;

		constant(...args: any[]): any;

		countBy(...args: any[]): any;

		create(...args: any[]): any;

		curry(...args: any[]): any;

		curryRight(...args: any[]): any;

		debounce(...args: any[]): any;

		deburr(...args: any[]): any;

		defaultTo(...args: any[]): any;

		defaults(...args: any[]): any;

		defaultsDeep(...args: any[]): any;

		defer(...args: any[]): any;

		delay(...args: any[]): any;

		difference(...args: any[]): any;

		differenceBy(...args: any[]): any;

		differenceWith(...args: any[]): any;

		divide(...args: any[]): any;

		drop(...args: any[]): any;

		dropRight(...args: any[]): any;

		dropRightWhile(...args: any[]): any;

		dropWhile(...args: any[]): any;

		each(...args: any[]): any;

		eachRight(...args: any[]): any;

		endsWith(...args: any[]): any;

		entries(...args: any[]): any;

		entriesIn(...args: any[]): any;

		eq(...args: any[]): any;

		escape(...args: any[]): any;

		escapeRegExp(...args: any[]): any;

		every(...args: any[]): any;

		extend(...args: any[]): any;

		extendWith(...args: any[]): any;

		fill(...args: any[]): any;

		filter(...args: any[]): any;

		find(...args: any[]): any;

		findIndex(...args: any[]): any;

		findKey(...args: any[]): any;

		findLast(...args: any[]): any;

		findLastIndex(...args: any[]): any;

		findLastKey(...args: any[]): any;

		first(...args: any[]): any;

		flatMap(...args: any[]): any;

		flatMapDeep(...args: any[]): any;

		flatMapDepth(...args: any[]): any;

		flatten(...args: any[]): any;

		flattenDeep(...args: any[]): any;

		flattenDepth(...args: any[]): any;

		flip(...args: any[]): any;

		floor(...args: any[]): any;

		flow(...args: any[]): any;

		flowRight(...args: any[]): any;

		forEach(...args: any[]): any;

		forEachRight(...args: any[]): any;

		forIn(...args: any[]): any;

		forInRight(...args: any[]): any;

		forOwn(...args: any[]): any;

		forOwnRight(...args: any[]): any;

		fromPairs(...args: any[]): any;

		functions(...args: any[]): any;

		functionsIn(...args: any[]): any;

		get(...args: any[]): any;

		groupBy(...args: any[]): any;

		gt(...args: any[]): any;

		gte(...args: any[]): any;

		has(...args: any[]): any;

		hasIn(...args: any[]): any;

		head(...args: any[]): any;

		identity(...args: any[]): any;

		inRange(...args: any[]): any;

		includes(...args: any[]): any;

		indexOf(...args: any[]): any;

		initial(...args: any[]): any;

		intersection(...args: any[]): any;

		intersectionBy(...args: any[]): any;

		intersectionWith(...args: any[]): any;

		invert(...args: any[]): any;

		invertBy(...args: any[]): any;

		invoke(...args: any[]): any;

		invokeMap(...args: any[]): any;

		isArguments(...args: any[]): any;

		isArray(...args: any[]): any;

		isArrayBuffer(...args: any[]): any;

		isArrayLike(...args: any[]): any;

		isArrayLikeObject(...args: any[]): any;

		isBoolean(...args: any[]): any;

		isBuffer(...args: any[]): any;

		isDate(...args: any[]): any;

		isElement(...args: any[]): any;

		isEmpty(...args: any[]): any;

		isEqual(...args: any[]): any;

		isEqualWith(...args: any[]): any;

		isError(...args: any[]): any;

		isFinite(...args: any[]): any;

		isFunction(...args: any[]): any;

		isInteger(...args: any[]): any;

		isLength(...args: any[]): any;

		isMap(...args: any[]): any;

		isMatch(...args: any[]): any;

		isMatchWith(...args: any[]): any;

		isNaN(...args: any[]): any;

		isNative(...args: any[]): any;

		isNil(...args: any[]): any;

		isNull(...args: any[]): any;

		isNumber(...args: any[]): any;

		isObject(...args: any[]): any;

		isObjectLike(...args: any[]): any;

		isPlainObject(...args: any[]): any;

		isRegExp(...args: any[]): any;

		isSafeInteger(...args: any[]): any;

		isSet(...args: any[]): any;

		isString(...args: any[]): any;

		isSymbol(...args: any[]): any;

		isTypedArray(...args: any[]): any;

		isUndefined(...args: any[]): any;

		isWeakMap(...args: any[]): any;

		isWeakSet(...args: any[]): any;

		iteratee(...args: any[]): any;

		join(...args: any[]): any;

		kebabCase(...args: any[]): any;

		keyBy(...args: any[]): any;

		keys(...args: any[]): any;

		keysIn(...args: any[]): any;

		last(...args: any[]): any;

		lastIndexOf(...args: any[]): any;

		lowerCase(...args: any[]): any;

		lowerFirst(...args: any[]): any;

		lt(...args: any[]): any;

		lte(...args: any[]): any;

		map(...args: any[]): any;

		mapKeys(...args: any[]): any;

		mapValues(...args: any[]): any;

		matches(...args: any[]): any;

		matchesProperty(...args: any[]): any;

		max(...args: any[]): any;

		maxBy(...args: any[]): any;

		mean(...args: any[]): any;

		meanBy(...args: any[]): any;

		memoize(...args: any[]): any;

		merge(...args: any[]): any;

		mergeWith(...args: any[]): any;

		method(...args: any[]): any;

		methodOf(...args: any[]): any;

		min(...args: any[]): any;

		minBy(...args: any[]): any;

		mixin(...args: any[]): any;

		multiply(...args: any[]): any;

		negate(...args: any[]): any;

		next(): any;

		noConflict(...args: any[]): any;

		noop(...args: any[]): any;

		now(...args: any[]): any;

		nth(...args: any[]): any;

		nthArg(...args: any[]): any;

		omit(...args: any[]): any;

		omitBy(...args: any[]): any;

		once(...args: any[]): any;

		orderBy(...args: any[]): any;

		over(...args: any[]): any;

		overArgs(...args: any[]): any;

		overEvery(...args: any[]): any;

		overSome(...args: any[]): any;

		pad(...args: any[]): any;

		padEnd(...args: any[]): any;

		padStart(...args: any[]): any;

		parseInt(...args: any[]): any;

		partial(...args: any[]): any;

		partialRight(...args: any[]): any;

		partition(...args: any[]): any;

		pick(...args: any[]): any;

		pickBy(...args: any[]): any;

		plant(value: any): any;

		pop(...args: any[]): any;

		property(...args: any[]): any;

		propertyOf(...args: any[]): any;

		pull(...args: any[]): any;

		pullAll(...args: any[]): any;

		pullAllBy(...args: any[]): any;

		pullAllWith(...args: any[]): any;

		pullAt(...args: any[]): any;

		push(...args: any[]): any;

		random(...args: any[]): any;

		range(...args: any[]): any;

		rangeRight(...args: any[]): any;

		rearg(...args: any[]): any;

		reduce(...args: any[]): any;

		reduceRight(...args: any[]): any;

		reject(...args: any[]): any;

		remove(...args: any[]): any;

		repeat(...args: any[]): any;

		replace(...args: any[]): any;

		rest(...args: any[]): any;

		result(...args: any[]): any;

		reverse(): any;

		round(...args: any[]): any;

		runInContext(...args: any[]): any;

		sample(...args: any[]): any;

		sampleSize(...args: any[]): any;

		set(...args: any[]): any;

		setWith(...args: any[]): any;

		shift(...args: any[]): any;

		shuffle(...args: any[]): any;

		size(...args: any[]): any;

		slice(...args: any[]): any;

		snakeCase(...args: any[]): any;

		some(...args: any[]): any;

		sort(...args: any[]): any;

		sortBy(...args: any[]): any;

		sortedIndex(...args: any[]): any;

		sortedIndexBy(...args: any[]): any;

		sortedIndexOf(...args: any[]): any;

		sortedLastIndex(...args: any[]): any;

		sortedLastIndexBy(...args: any[]): any;

		sortedLastIndexOf(...args: any[]): any;

		sortedUniq(...args: any[]): any;

		sortedUniqBy(...args: any[]): any;

		splice(...args: any[]): any;

		split(...args: any[]): any;

		spread(...args: any[]): any;

		startCase(...args: any[]): any;

		startsWith(...args: any[]): any;

		stubArray(...args: any[]): any;

		stubFalse(...args: any[]): any;

		stubObject(...args: any[]): any;

		stubString(...args: any[]): any;

		stubTrue(...args: any[]): any;

		subtract(...args: any[]): any;

		sum(...args: any[]): any;

		sumBy(...args: any[]): any;

		tail(...args: any[]): any;

		take(...args: any[]): any;

		takeRight(...args: any[]): any;

		takeRightWhile(...args: any[]): any;

		takeWhile(...args: any[]): any;

		tap(...args: any[]): any;

		template(...args: any[]): any;

		throttle(...args: any[]): any;

		thru(...args: any[]): any;

		times(...args: any[]): any;

		toArray(...args: any[]): any;

		toFinite(...args: any[]): any;

		toInteger(...args: any[]): any;

		toJSON(): any;

		toLength(...args: any[]): any;

		toLower(...args: any[]): any;

		toNumber(...args: any[]): any;

		toPairs(...args: any[]): any;

		toPairsIn(...args: any[]): any;

		toPath(...args: any[]): any;

		toPlainObject(...args: any[]): any;

		toSafeInteger(...args: any[]): any;

		toString(...args: any[]): any;

		toUpper(...args: any[]): any;

		transform(...args: any[]): any;

		trim(...args: any[]): any;

		trimEnd(...args: any[]): any;

		trimStart(...args: any[]): any;

		truncate(...args: any[]): any;

		unary(...args: any[]): any;

		unescape(...args: any[]): any;

		union(...args: any[]): any;

		unionBy(...args: any[]): any;

		unionWith(...args: any[]): any;

		uniq(...args: any[]): any;

		uniqBy(...args: any[]): any;

		uniqWith(...args: any[]): any;

		uniqueId(...args: any[]): any;

		unset(...args: any[]): any;

		unshift(...args: any[]): any;

		unzip(...args: any[]): any;

		unzipWith(...args: any[]): any;

		update(...args: any[]): any;

		updateWith(...args: any[]): any;

		upperCase(...args: any[]): any;

		upperFirst(...args: any[]): any;

		value(): any;

		valueOf(): any;

		values(...args: any[]): any;

		valuesIn(...args: any[]): any;

		without(...args: any[]): any;

		words(...args: any[]): any;

		wrap(...args: any[]): any;

		xor(...args: any[]): any;

		xorBy(...args: any[]): any;

		xorWith(...args: any[]): any;

		zip(...args: any[]): any;

		zipObject(...args: any[]): any;

		zipObjectDeep(...args: any[]): any;

		zipWith(...args: any[]): any;

		static VERSION: string;

		static add(value: any, other: any): any;

		static after(n: any, func: any, ...args: any[]): any;

		static ary(func: any, n: any, guard: any): any;

		static assign(...args: any[]): any;

		static assignIn(...args: any[]): any;

		static assignInWith(...args: any[]): any;

		static assignWith(...args: any[]): any;

		static at(...args: any[]): any;

		static attempt(...args: any[]): any;

		static before(n: any, func: any, ...args: any[]): any;

		static bind(...args: any[]): any;

		static bindAll(...args: any[]): any;

		static bindKey(...args: any[]): any;

		static camelCase(string: any): any;

		static capitalize(string: any): any;

		static castArray(...args: any[]): any;

		static ceil(number: any, precision: any): any;

		static chain(value: any): any;

		static chunk(array: any, size: any, guard: any): any;

		static clamp(number: any, lower: any, upper: any): any;

		static clone(value: any): any;

		static cloneDeep(value: any): any;

		static cloneDeepWith(value: any, customizer: any): any;

		static cloneWith(value: any, customizer: any): any;

		static compact(array: any): any;

		static concat(...args: any[]): any;

		static cond(pairs: any): any;

		static conforms(source: any): any;

		static conformsTo(object: any, source: any): any;

		static constant(value: any): any;

		static countBy(collection: any, iteratee: any): any;

		static create(prototype: any, properties: any): any;

		static curry(func: any, arity: any, guard: any): any;

		static curryRight(func: any, arity: any, guard: any): any;

		static debounce(func: any, wait: any, options: any, ...args: any[]): any;

		static deburr(string: any): any;

		static defaultTo(value: any, defaultValue: any): any;

		static defaults(...args: any[]): any;

		static defaultsDeep(...args: any[]): any;

		static defer(...args: any[]): any;

		static delay(...args: any[]): any;

		static difference(...args: any[]): any;

		static differenceBy(...args: any[]): any;

		static differenceWith(...args: any[]): any;

		static divide(value: any, other: any): any;

		static drop(array: any, n: any, guard: any): any;

		static dropRight(array: any, n: any, guard: any): any;

		static dropRightWhile(array: any, predicate: any): any;

		static dropWhile(array: any, predicate: any): any;

		static each(collection: any, iteratee: any): any;

		static eachRight(collection: any, iteratee: any): any;

		static endsWith(string: any, target: any, position: any): any;

		static entries(object: any): any;

		static entriesIn(object: any): any;

		static eq(value: any, other: any): any;

		static escape(string: any): any;

		static escapeRegExp(string: any): any;

		static every(collection: any, predicate: any, guard: any): any;

		static extend(...args: any[]): any;

		static extendWith(...args: any[]): any;

		static fill(array: any, value: any, start: any, end: any): any;

		static filter(collection: any, predicate: any): any;

		static find(collection: any, predicate: any, fromIndex: any): any;

		static findIndex(array: any, predicate: any, fromIndex: any): any;

		static findKey(object: any, predicate: any): any;

		static findLast(collection: any, predicate: any, fromIndex: any): any;

		static findLastIndex(array: any, predicate: any, fromIndex: any): any;

		static findLastKey(object: any, predicate: any): any;

		static first(array: any): any;

		static flatMap(collection: any, iteratee: any): any;

		static flatMapDeep(collection: any, iteratee: any): any;

		static flatMapDepth(collection: any, iteratee: any, depth: any): any;

		static flatten(array: any): any;

		static flattenDeep(array: any): any;

		static flattenDepth(array: any, depth: any): any;

		static flip(func: any): any;

		static floor(number: any, precision: any): any;

		static flow(...args: any[]): any;

		static flowRight(...args: any[]): any;

		static forEach(collection: any, iteratee: any): any;

		static forEachRight(collection: any, iteratee: any): any;

		static forIn(object: any, iteratee: any): any;

		static forInRight(object: any, iteratee: any): any;

		static forOwn(object: any, iteratee: any): any;

		static forOwnRight(object: any, iteratee: any): any;

		static fromPairs(pairs: any): any;

		static functions(object: any): any;

		static functionsIn(object: any): any;

		static get(object: any, path: any, defaultValue: any): any;

		static groupBy(collection: any, iteratee: any): any;

		static gt(value: any, other: any): any;

		static gte(value: any, other: any): any;

		static has(object: any, path: any): any;

		static hasIn(object: any, path: any): any;

		static head(array: any): any;

		static identity(value: any): any;

		static inRange(number: any, start: any, end: any): any;

		static includes(collection: any, value: any, fromIndex: any, guard: any): any;

		static indexOf(array: any, value: any, fromIndex: any): any;

		static initial(array: any): any;

		static intersection(...args: any[]): any;

		static intersectionBy(...args: any[]): any;

		static intersectionWith(...args: any[]): any;

		static invert(object: any, iteratee: any): any;

		static invertBy(object: any, iteratee: any): any;

		static invoke(...args: any[]): any;

		static invokeMap(...args: any[]): any;

		static isArguments(value: any): any;

		static isArray(p0: any): any;

		static isArrayBuffer(value: any): any;

		static isArrayLike(value: any): any;

		static isArrayLikeObject(value: any): any;

		static isBoolean(value: any): any;

		static isBuffer(b: any): any;

		static isDate(value: any): any;

		static isElement(value: any): any;

		static isEmpty(value: any): any;

		static isEqual(value: any, other: any): any;

		static isEqualWith(value: any, other: any, customizer: any): any;

		static isError(value: any): any;

		static isFinite(value: any): any;

		static isFunction(value: any): any;

		static isInteger(value: any): any;

		static isLength(value: any): any;

		static isMap(value: any): any;

		static isMatch(object: any, source: any): any;

		static isMatchWith(object: any, source: any, customizer: any): any;

		static isNaN(value: any): any;

		static isNative(value: any): any;

		static isNil(value: any): any;

		static isNull(value: any): any;

		static isNumber(value: any): any;

		static isObject(value: any): any;

		static isObjectLike(value: any): any;

		static isPlainObject(value: any): any;

		static isRegExp(value: any): any;

		static isSafeInteger(value: any): any;

		static isSet(value: any): any;

		static isString(value: any): any;

		static isSymbol(value: any): any;

		static isTypedArray(value: any): any;

		static isUndefined(value: any): any;

		static isWeakMap(value: any): any;

		static isWeakSet(value: any): any;

		static iteratee(func: any): any;

		static join(array: any, separator: any): any;

		static kebabCase(string: any): any;

		static keyBy(collection: any, iteratee: any): any;

		static keys(object: any): any;

		static keysIn(object: any): any;

		static last(array: any): any;

		static lastIndexOf(array: any, value: any, fromIndex: any): any;

		static lowerCase(string: any): any;

		static lowerFirst(string: any): any;

		static lt(value: any, other: any): any;

		static lte(value: any, other: any): any;

		static map(collection: any, iteratee: any): any;

		static mapKeys(object: any, iteratee: any): any;

		static mapValues(object: any, iteratee: any): any;

		static matches(source: any): any;

		static matchesProperty(path: any, srcValue: any): any;

		static max(array: any): any;

		static maxBy(array: any, iteratee: any): any;

		static mean(array: any): any;

		static meanBy(array: any, iteratee: any): any;

		static memoize(func: any, resolver: any, ...args: any[]): any;

		static merge(...args: any[]): any;

		static mergeWith(...args: any[]): any;

		static method(...args: any[]): any;

		static methodOf(...args: any[]): any;

		static min(array: any): any;

		static minBy(array: any, iteratee: any): any;

		static mixin(object: any, source: any, options: any, ...args: any[]): any;

		static multiply(value: any, other: any): any;

		static negate(predicate: any, ...args: any[]): any;

		static noConflict(): any;

		static noop(): void;

		static now(): any;

		static nth(array: any, n: any): any;

		static nthArg(n: any): any;

		static omit(...args: any[]): any;

		static omitBy(object: any, predicate: any): any;

		static once(func: any): any;

		static orderBy(collection: any, iteratees: any, orders: any, guard: any): any;

		static over(...args: any[]): any;

		static overArgs(...args: any[]): any;

		static overEvery(...args: any[]): any;

		static overSome(...args: any[]): any;

		static pad(string: any, length: any, chars: any): any;

		static padEnd(string: any, length: any, chars: any): any;

		static padStart(string: any, length: any, chars: any): any;

		static parseInt(string: any, radix: any, guard: any): any;

		static partial(...args: any[]): any;

		static partialRight(...args: any[]): any;

		static partition(collection: any, iteratee: any): any;

		static pick(...args: any[]): any;

		static pickBy(object: any, predicate: any): any;

		static property(path: any): any;

		static propertyOf(object: any): any;

		static pull(...args: any[]): any;

		static pullAll(array: any, values: any): any;

		static pullAllBy(array: any, values: any, iteratee: any): any;

		static pullAllWith(array: any, values: any, comparator: any): any;

		static pullAt(...args: any[]): any;

		static random(lower: any, upper: any, floating: any): any;

		static range(start: any, end: any, step: any): any;

		static rangeRight(start: any, end: any, step: any): any;

		static rearg(...args: any[]): any;

		static reduce(collection: any, iteratee: any, accumulator: any, ...args: any[]): any;

		static reduceRight(collection: any, iteratee: any, accumulator: any, ...args: any[]): any;

		static reject(collection: any, predicate: any): any;

		static remove(array: any, predicate: any): any;

		static repeat(string: any, n: any, guard: any): any;

		static replace(...args: any[]): any;

		static rest(func: any, start: any): any;

		static result(object: any, path: any, defaultValue: any): any;

		static reverse(array: any): any;

		static round(number: any, precision: any): any;

		static runInContext(context: any, ...args: any[]): any;

		static sample(collection: any): any;

		static sampleSize(collection: any, n: any, guard: any): any;

		static set(object: any, path: any, value: any): any;

		static setWith(object: any, path: any, value: any, customizer: any): any;

		static shuffle(collection: any): any;

		static size(collection: any): any;

		static slice(array: any, start: any, end: any): any;

		static snakeCase(string: any): any;

		static some(collection: any, predicate: any, guard: any): any;

		static sortBy(...args: any[]): any;

		static sortedIndex(array: any, value: any): any;

		static sortedIndexBy(array: any, value: any, iteratee: any): any;

		static sortedIndexOf(array: any, value: any): any;

		static sortedLastIndex(array: any, value: any): any;

		static sortedLastIndexBy(array: any, value: any, iteratee: any): any;

		static sortedLastIndexOf(array: any, value: any): any;

		static sortedUniq(array: any): any;

		static sortedUniqBy(array: any, iteratee: any): any;

		static split(string: any, separator: any, limit: any): any;

		static spread(func: any, start: any): any;

		static startCase(string: any): any;

		static startsWith(string: any, target: any, position: any): any;

		static stubArray(): any;

		static stubFalse(): any;

		static stubObject(): any;

		static stubString(): any;

		static stubTrue(): any;

		static subtract(value: any, other: any): any;

		static sum(array: any): any;

		static sumBy(array: any, iteratee: any): any;

		static tail(array: any): any;

		static take(array: any, n: any, guard: any): any;

		static takeRight(array: any, n: any, guard: any): any;

		static takeRightWhile(array: any, predicate: any): any;

		static takeWhile(array: any, predicate: any): any;

		static tap(value: any, interceptor: any): any;

		static template(string: any, options: any, guard: any): any;

		static templateSettings: {
			escape: RegExp;
			evaluate: RegExp;
			imports: {};
			interpolate: RegExp;
			variable: string;
		};

		static throttle(func: any, wait: any, options: any): any;

		static thru(value: any, interceptor: any): any;

		static times(n: any, iteratee: any): any;

		static toArray(value: any): any;

		static toFinite(value: any): any;

		static toInteger(value: any): any;

		static toLength(value: any): any;

		static toLower(value: any): any;

		static toNumber(value: any): any;

		static toPairs(object: any): any;

		static toPairsIn(object: any): any;

		static toPath(value: any): any;

		static toPlainObject(value: any): any;

		static toSafeInteger(value: any): any;

		static toString(value: any): any;

		static toUpper(value: any): any;

		static transform(object: any, iteratee: any, accumulator: any): any;

		static trim(string: any, chars: any, guard: any): any;

		static trimEnd(string: any, chars: any, guard: any): any;

		static trimStart(string: any, chars: any, guard: any): any;

		static truncate(string: any, options: any): any;

		static unary(func: any): any;

		static unescape(string: any): any;

		static union(...args: any[]): any;

		static unionBy(...args: any[]): any;

		static unionWith(...args: any[]): any;

		static uniq(array: any): any;

		static uniqBy(array: any, iteratee: any): any;

		static uniqWith(array: any, comparator: any): any;

		static uniqueId(prefix: any): any;

		static unset(object: any, path: any): any;

		static unzip(array: any): any;

		static unzipWith(array: any, iteratee: any): any;

		static update(object: any, path: any, updater: any): any;

		static updateWith(object: any, path: any, updater: any, customizer: any): any;

		static upperCase(string: any): any;

		static upperFirst(string: any): any;

		static values(object: any): any;

		static valuesIn(object: any): any;

		static without(...args: any[]): any;

		static words(string: any, pattern: any, guard: any): any;

		static wrap(value: any, wrapper: any): any;

		static xor(...args: any[]): any;

		static xorBy(...args: any[]): any;

		static xorWith(...args: any[]): any;

		static zip(...args: any[]): any;

		static zipObject(props: any, values: any): any;

		static zipObjectDeep(props: any, values: any): any;

		static zipWith(...args: any[]): any;
	}

	export = lodash;
}
`,ua=`
declare module "moment" {
	/**
	 * @param strict Strict parsing disables the deprecated fallback to the native Date constructor when
	 * parsing a string.
	 */
	function moment(inp?: Moment.MomentInput, strict?: boolean): Moment.Moment;
	/**
	 * @param strict Strict parsing requires that the format and input match exactly, including delimiters.
	 * Strict parsing is frequently the best parsing option. For more information about choosing strict vs
	 * forgiving parsing, see the [parsing guide](https://momentjs.com/guides/#/parsing/).
	 */
	function moment(
		inp?: Moment.MomentInput,
		format?: Moment.MomentFormatSpecification,
		strict?: boolean
	): Moment.Moment;
	/**
	 * @param strict Strict parsing requires that the format and input match exactly, including delimiters.
	 * Strict parsing is frequently the best parsing option. For more information about choosing strict vs
	 * forgiving parsing, see the [parsing guide](https://momentjs.com/guides/#/parsing/).
	 */
	function moment(
		inp?: Moment.MomentInput,
		format?: Moment.MomentFormatSpecification,
		language?: string,
		strict?: boolean
	): Moment.Moment;

	namespace Moment {
		type RelativeTimeKey =
			| "s"
			| "ss"
			| "m"
			| "mm"
			| "h"
			| "hh"
			| "d"
			| "dd"
			| "w"
			| "ww"
			| "M"
			| "MM"
			| "y"
			| "yy";
		type CalendarKey =
			| "sameDay"
			| "nextDay"
			| "lastDay"
			| "nextWeek"
			| "lastWeek"
			| "sameElse"
			| string;
		type LongDateFormatKey =
			| "LTS"
			| "LT"
			| "L"
			| "LL"
			| "LLL"
			| "LLLL"
			| "lts"
			| "lt"
			| "l"
			| "ll"
			| "lll"
			| "llll";

		interface Locale {
			calendar(key?: CalendarKey, m?: Moment, now?: Moment): string;

			longDateFormat(key: LongDateFormatKey): string;
			invalidDate(): string;
			ordinal(n: number): string;

			preparse(inp: string): string;
			postformat(inp: string): string;
			relativeTime(
				n: number,
				withoutSuffix: boolean,
				key: RelativeTimeKey,
				isFuture: boolean
			): string;
			pastFuture(diff: number, absRelTime: string): string;
			set(config: Object): void;

			months(): string[];
			months(m: Moment, format?: string): string;
			monthsShort(): string[];
			monthsShort(m: Moment, format?: string): string;
			monthsParse(monthName: string, format: string, strict: boolean): number;
			monthsRegex(strict: boolean): RegExp;
			monthsShortRegex(strict: boolean): RegExp;

			week(m: Moment): number;
			firstDayOfYear(): number;
			firstDayOfWeek(): number;

			weekdays(): string[];
			weekdays(m: Moment, format?: string): string;
			weekdaysMin(): string[];
			weekdaysMin(m: Moment): string;
			weekdaysShort(): string[];
			weekdaysShort(m: Moment): string;
			weekdaysParse(weekdayName: string, format: string, strict: boolean): number;
			weekdaysRegex(strict: boolean): RegExp;
			weekdaysShortRegex(strict: boolean): RegExp;
			weekdaysMinRegex(strict: boolean): RegExp;

			isPM(input: string): boolean;
			meridiem(hour: number, minute: number, isLower: boolean): string;
		}

		interface StandaloneFormatSpec {
			format: string[];
			standalone: string[];
			isFormat?: RegExp;
		}

		interface WeekSpec {
			dow: number;
			doy?: number;
		}

		type CalendarSpecVal = string | ((m?: MomentInput, now?: Moment) => string);
		interface CalendarSpec {
			sameDay?: CalendarSpecVal;
			nextDay?: CalendarSpecVal;
			lastDay?: CalendarSpecVal;
			nextWeek?: CalendarSpecVal;
			lastWeek?: CalendarSpecVal;
			sameElse?: CalendarSpecVal;

			// any additional properties might be used with moment.calendarFormat
			[x: string]: CalendarSpecVal | void; // undefined
		}

		type RelativeTimeSpecVal =
			| string
			| ((
					n: number,
					withoutSuffix: boolean,
					key: RelativeTimeKey,
					isFuture: boolean
			  ) => string);
		type RelativeTimeFuturePastVal = string | ((relTime: string) => string);

		interface RelativeTimeSpec {
			future?: RelativeTimeFuturePastVal;
			past?: RelativeTimeFuturePastVal;
			s?: RelativeTimeSpecVal;
			ss?: RelativeTimeSpecVal;
			m?: RelativeTimeSpecVal;
			mm?: RelativeTimeSpecVal;
			h?: RelativeTimeSpecVal;
			hh?: RelativeTimeSpecVal;
			d?: RelativeTimeSpecVal;
			dd?: RelativeTimeSpecVal;
			w?: RelativeTimeSpecVal;
			ww?: RelativeTimeSpecVal;
			M?: RelativeTimeSpecVal;
			MM?: RelativeTimeSpecVal;
			y?: RelativeTimeSpecVal;
			yy?: RelativeTimeSpecVal;
		}

		interface LongDateFormatSpec {
			LTS: string;
			LT: string;
			L: string;
			LL: string;
			LLL: string;
			LLLL: string;

			// lets forget for a sec that any upper/lower permutation will also work
			lts?: string;
			lt?: string;
			l?: string;
			ll?: string;
			lll?: string;
			llll?: string;
		}

		type MonthWeekdayFn = (momentToFormat: Moment, format?: string) => string;
		type WeekdaySimpleFn = (momentToFormat: Moment) => string;
		interface EraSpec {
			since: string | number;
			until: string | number;
			offset: number;
			name: string;
			narrow: string;
			abbr: string;
		}

		interface LocaleSpecification {
			months?: string[] | StandaloneFormatSpec | MonthWeekdayFn;
			monthsShort?: string[] | StandaloneFormatSpec | MonthWeekdayFn;

			weekdays?: string[] | StandaloneFormatSpec | MonthWeekdayFn;
			weekdaysShort?: string[] | StandaloneFormatSpec | WeekdaySimpleFn;
			weekdaysMin?: string[] | StandaloneFormatSpec | WeekdaySimpleFn;

			meridiemParse?: RegExp;
			meridiem?: (hour: number, minute: number, isLower: boolean) => string;

			isPM?: (input: string) => boolean;

			longDateFormat?: LongDateFormatSpec;
			calendar?: CalendarSpec;
			relativeTime?: RelativeTimeSpec;
			invalidDate?: string;
			ordinal?: (n: number) => string;
			ordinalParse?: RegExp;

			week?: WeekSpec;
			eras?: EraSpec[];

			// Allow anything: in general any property that is passed as locale spec is
			// put in the locale object so it can be used by locale functions
			[x: string]: any;
		}

		interface MomentObjectOutput {
			years: number;
			/* One digit */
			months: number;
			/* Day of the month */
			date: number;
			hours: number;
			minutes: number;
			seconds: number;
			milliseconds: number;
		}

		interface argThresholdOpts {
			ss?: number;
			s?: number;
			m?: number;
			h?: number;
			d?: number;
			w?: number | void;
			M?: number;
		}

		interface Duration {
			clone(): Duration;

			humanize(argWithSuffix?: boolean, argThresholds?: argThresholdOpts): string;

			humanize(argThresholds?: argThresholdOpts): string;

			abs(): Duration;

			as(units: unitOfTime.Base): number;
			get(units: unitOfTime.Base): number;

			milliseconds(): number;
			asMilliseconds(): number;

			seconds(): number;
			asSeconds(): number;

			minutes(): number;
			asMinutes(): number;

			hours(): number;
			asHours(): number;

			days(): number;
			asDays(): number;

			weeks(): number;
			asWeeks(): number;

			months(): number;
			asMonths(): number;

			years(): number;
			asYears(): number;

			add(inp?: DurationInputArg1, unit?: DurationInputArg2): Duration;
			subtract(inp?: DurationInputArg1, unit?: DurationInputArg2): Duration;

			locale(): string;
			locale(locale: LocaleSpecifier): Duration;
			localeData(): Locale;

			toISOString(): string;
			toJSON(): string;

			isValid(): boolean;

			/**
			 * @deprecated since version 2.8.0
			 */
			lang(locale: LocaleSpecifier): Moment;
			/**
			 * @deprecated since version 2.8.0
			 */
			lang(): Locale;
			/**
			 * @deprecated
			 */
			toIsoString(): string;
		}

		interface MomentRelativeTime {
			future: any;
			past: any;
			s: any;
			ss: any;
			m: any;
			mm: any;
			h: any;
			hh: any;
			d: any;
			dd: any;
			M: any;
			MM: any;
			y: any;
			yy: any;
		}

		interface MomentLongDateFormat {
			L: string;
			LL: string;
			LLL: string;
			LLLL: string;
			LT: string;
			LTS: string;

			l?: string;
			ll?: string;
			lll?: string;
			llll?: string;
			lt?: string;
			lts?: string;
		}

		interface MomentParsingFlags {
			empty: boolean;
			unusedTokens: string[];
			unusedInput: string[];
			overflow: number;
			charsLeftOver: number;
			nullInput: boolean;
			invalidMonth: string | void; // null
			invalidFormat: boolean;
			userInvalidated: boolean;
			iso: boolean;
			parsedDateParts: any[];
			meridiem: string | void; // null
		}

		interface MomentParsingFlagsOpt {
			empty?: boolean;
			unusedTokens?: string[];
			unusedInput?: string[];
			overflow?: number;
			charsLeftOver?: number;
			nullInput?: boolean;
			invalidMonth?: string;
			invalidFormat?: boolean;
			userInvalidated?: boolean;
			iso?: boolean;
			parsedDateParts?: any[];
			meridiem?: string;
		}

		interface MomentBuiltinFormat {
			__momentBuiltinFormatBrand: any;
		}

		type MomentFormatSpecification =
			| string
			| MomentBuiltinFormat
			| (string | MomentBuiltinFormat)[];

		export namespace unitOfTime {
			type Base =
				| "year"
				| "years"
				| "y"
				| "month"
				| "months"
				| "M"
				| "week"
				| "weeks"
				| "w"
				| "day"
				| "days"
				| "d"
				| "hour"
				| "hours"
				| "h"
				| "minute"
				| "minutes"
				| "m"
				| "second"
				| "seconds"
				| "s"
				| "millisecond"
				| "milliseconds"
				| "ms";

			type _quarter = "quarter" | "quarters" | "Q";
			type _isoWeek = "isoWeek" | "isoWeeks" | "W";
			type _date = "date" | "dates" | "D";
			type DurationConstructor = Base | _quarter | _isoWeek;

			export type DurationAs = Base;

			export type StartOf = Base | _quarter | _isoWeek | _date | void; // null

			export type Diff = Base | _quarter;

			export type MomentConstructor = Base | _date;

			export type All =
				| Base
				| _quarter
				| _isoWeek
				| _date
				| "weekYear"
				| "weekYears"
				| "gg"
				| "isoWeekYear"
				| "isoWeekYears"
				| "GG"
				| "dayOfYear"
				| "dayOfYears"
				| "DDD"
				| "weekday"
				| "weekdays"
				| "e"
				| "isoWeekday"
				| "isoWeekdays"
				| "E";
		}

		type numberlike = number | string;
		interface MomentInputObject {
			years?: numberlike;
			year?: numberlike;
			y?: numberlike;

			months?: numberlike;
			month?: numberlike;
			M?: numberlike;

			days?: numberlike;
			day?: numberlike;
			d?: numberlike;

			dates?: numberlike;
			date?: numberlike;
			D?: numberlike;

			hours?: numberlike;
			hour?: numberlike;
			h?: numberlike;

			minutes?: numberlike;
			minute?: numberlike;
			m?: numberlike;

			seconds?: numberlike;
			second?: numberlike;
			s?: numberlike;

			milliseconds?: numberlike;
			millisecond?: numberlike;
			ms?: numberlike;
		}

		interface DurationInputObject extends MomentInputObject {
			quarters?: numberlike;
			quarter?: numberlike;
			Q?: numberlike;

			weeks?: numberlike;
			week?: numberlike;
			w?: numberlike;
		}

		interface MomentSetObject extends MomentInputObject {
			weekYears?: numberlike;
			weekYear?: numberlike;
			gg?: numberlike;

			isoWeekYears?: numberlike;
			isoWeekYear?: numberlike;
			GG?: numberlike;

			quarters?: numberlike;
			quarter?: numberlike;
			Q?: numberlike;

			weeks?: numberlike;
			week?: numberlike;
			w?: numberlike;

			isoWeeks?: numberlike;
			isoWeek?: numberlike;
			W?: numberlike;

			dayOfYears?: numberlike;
			dayOfYear?: numberlike;
			DDD?: numberlike;

			weekdays?: numberlike;
			weekday?: numberlike;
			e?: numberlike;

			isoWeekdays?: numberlike;
			isoWeekday?: numberlike;
			E?: numberlike;
		}

		interface FromTo {
			from: MomentInput;
			to: MomentInput;
		}

		type MomentInput =
			| Moment
			| Date
			| string
			| number
			| (number | string)[]
			| MomentInputObject
			| void; // null | undefined
		type DurationInputArg1 = Duration | number | string | FromTo | DurationInputObject | void; // null | undefined
		type DurationInputArg2 = unitOfTime.DurationConstructor;
		type LocaleSpecifier = string | Moment | Duration | string[] | boolean;

		interface MomentCreationData {
			input: MomentInput;
			format?: MomentFormatSpecification;
			locale: Locale;
			isUTC: boolean;
			strict?: boolean;
		}

		interface Moment extends Object {
			format(format?: string): string;

			startOf(unitOfTime: unitOfTime.StartOf): Moment;
			endOf(unitOfTime: unitOfTime.StartOf): Moment;

			add(amount?: DurationInputArg1, unit?: DurationInputArg2): Moment;
			/**
			 * @deprecated reverse syntax
			 */
			add(unit: unitOfTime.DurationConstructor, amount: number | string): Moment;

			subtract(amount?: DurationInputArg1, unit?: DurationInputArg2): Moment;
			/**
			 * @deprecated reverse syntax
			 */
			subtract(unit: unitOfTime.DurationConstructor, amount: number | string): Moment;

			calendar(): string;
			calendar(formats: CalendarSpec): string;
			calendar(time: MomentInput, formats?: CalendarSpec): string;

			clone(): Moment;

			/**
			 * @return Unix timestamp in milliseconds
			 */
			valueOf(): number;

			// current date/time in local mode
			local(keepLocalTime?: boolean): Moment;
			isLocal(): boolean;

			// current date/time in UTC mode
			utc(keepLocalTime?: boolean): Moment;
			isUTC(): boolean;
			/**
			 * @deprecated use isUTC
			 */
			isUtc(): boolean;

			parseZone(): Moment;
			isValid(): boolean;
			invalidAt(): number;

			hasAlignedHourOffset(other?: MomentInput): boolean;

			creationData(): MomentCreationData;
			parsingFlags(): MomentParsingFlags;

			year(y: number): Moment;
			year(): number;
			/**
			 * @deprecated use year(y)
			 */
			years(y: number): Moment;
			/**
			 * @deprecated use year()
			 */
			years(): number;
			quarter(): number;
			quarter(q: number): Moment;
			quarters(): number;
			quarters(q: number): Moment;
			month(M: number | string): Moment;
			month(): number;
			/**
			 * @deprecated use month(M)
			 */
			months(M: number | string): Moment;
			/**
			 * @deprecated use month()
			 */
			months(): number;
			day(d: number | string): Moment;
			day(): number;
			days(d: number | string): Moment;
			days(): number;
			date(d: number): Moment;
			date(): number;
			/**
			 * @deprecated use date(d)
			 */
			dates(d: number): Moment;
			/**
			 * @deprecated use date()
			 */
			dates(): number;
			hour(h: number): Moment;
			hour(): number;
			hours(h: number): Moment;
			hours(): number;
			minute(m: number): Moment;
			minute(): number;
			minutes(m: number): Moment;
			minutes(): number;
			second(s: number): Moment;
			second(): number;
			seconds(s: number): Moment;
			seconds(): number;
			millisecond(ms: number): Moment;
			millisecond(): number;
			milliseconds(ms: number): Moment;
			milliseconds(): number;
			weekday(): number;
			weekday(d: number): Moment;
			isoWeekday(): number;
			isoWeekday(d: number | string): Moment;
			weekYear(): number;
			weekYear(d: number): Moment;
			isoWeekYear(): number;
			isoWeekYear(d: number): Moment;
			week(): number;
			week(d: number): Moment;
			weeks(): number;
			weeks(d: number): Moment;
			isoWeek(): number;
			isoWeek(d: number): Moment;
			isoWeeks(): number;
			isoWeeks(d: number): Moment;
			weeksInYear(): number;
			weeksInWeekYear(): number;
			isoWeeksInYear(): number;
			isoWeeksInISOWeekYear(): number;
			dayOfYear(): number;
			dayOfYear(d: number): Moment;

			from(inp: MomentInput, suffix?: boolean): string;
			to(inp: MomentInput, suffix?: boolean): string;
			fromNow(withoutSuffix?: boolean): string;
			toNow(withoutPrefix?: boolean): string;

			diff(b: MomentInput, unitOfTime?: unitOfTime.Diff, precise?: boolean): number;

			toArray(): number[];
			toDate(): Date;
			toISOString(keepOffset?: boolean): string;
			inspect(): string;
			toJSON(): string;
			unix(): number;

			isLeapYear(): boolean;
			/**
			 * @deprecated in favor of utcOffset
			 */
			zone(): number;
			zone(b: number | string): Moment;
			utcOffset(): number;
			utcOffset(b: number | string, keepLocalTime?: boolean): Moment;
			isUtcOffset(): boolean;
			daysInMonth(): number;
			isDST(): boolean;

			zoneAbbr(): string;
			zoneName(): string;

			isBefore(inp?: MomentInput, granularity?: unitOfTime.StartOf): boolean;
			isAfter(inp?: MomentInput, granularity?: unitOfTime.StartOf): boolean;
			isSame(inp?: MomentInput, granularity?: unitOfTime.StartOf): boolean;
			isSameOrAfter(inp?: MomentInput, granularity?: unitOfTime.StartOf): boolean;
			isSameOrBefore(inp?: MomentInput, granularity?: unitOfTime.StartOf): boolean;
			isBetween(
				a: MomentInput,
				b: MomentInput,
				granularity?: unitOfTime.StartOf,
				inclusivity?: "()" | "[)" | "(]" | "[]"
			): boolean;

			/**
			 * @deprecated as of 2.8.0, use locale
			 */
			lang(language: LocaleSpecifier): Moment;
			/**
			 * @deprecated as of 2.8.0, use locale
			 */
			lang(): Locale;

			locale(): string;
			locale(locale: LocaleSpecifier): Moment;

			localeData(): Locale;

			/**
			 * @deprecated no reliable implementation
			 */
			isDSTShifted(): boolean;

			// NOTE(constructor): Same as moment constructor
			/**
			 * @deprecated as of 2.7.0, use moment.min/max
			 */
			max(inp?: MomentInput, format?: MomentFormatSpecification, strict?: boolean): Moment;
			/**
			 * @deprecated as of 2.7.0, use moment.min/max
			 */
			max(
				inp?: MomentInput,
				format?: MomentFormatSpecification,
				language?: string,
				strict?: boolean
			): Moment;

			// NOTE(constructor): Same as moment constructor
			/**
			 * @deprecated as of 2.7.0, use moment.min/max
			 */
			min(inp?: MomentInput, format?: MomentFormatSpecification, strict?: boolean): Moment;
			/**
			 * @deprecated as of 2.7.0, use moment.min/max
			 */
			min(
				inp?: MomentInput,
				format?: MomentFormatSpecification,
				language?: string,
				strict?: boolean
			): Moment;

			get(unit: unitOfTime.All): number;
			set(unit: unitOfTime.All, value: number): Moment;
			set(objectLiteral: MomentSetObject): Moment;

			toObject(): MomentObjectOutput;
		}

		export let version: string;
		export let fn: Moment;

		// NOTE(constructor): Same as moment constructor
		/**
		 * @param strict Strict parsing disables the deprecated fallback to the native Date constructor when
		 * parsing a string.
		 */
		export function utc(inp?: MomentInput, strict?: boolean): Moment;
		/**
		 * @param strict Strict parsing requires that the format and input match exactly, including delimiters.
		 * Strict parsing is frequently the best parsing option. For more information about choosing strict vs
		 * forgiving parsing, see the [parsing guide](https://momentjs.com/guides/#/parsing/).
		 */
		export function utc(
			inp?: MomentInput,
			format?: MomentFormatSpecification,
			strict?: boolean
		): Moment;
		/**
		 * @param strict Strict parsing requires that the format and input match exactly, including delimiters.
		 * Strict parsing is frequently the best parsing option. For more information about choosing strict vs
		 * forgiving parsing, see the [parsing guide](https://momentjs.com/guides/#/parsing/).
		 */
		export function utc(
			inp?: MomentInput,
			format?: MomentFormatSpecification,
			language?: string,
			strict?: boolean
		): Moment;

		export function unix(timestamp: number): Moment;

		export function invalid(flags?: MomentParsingFlagsOpt): Moment;
		export function isMoment(m: any): m is Moment;
		export function isDate(m: any): m is Date;
		export function isDuration(d: any): d is Duration;

		/**
		 * @deprecated in 2.8.0
		 */
		export function lang(language?: string): string;
		/**
		 * @deprecated in 2.8.0
		 */
		export function lang(language?: string, definition?: Locale): string;

		export function locale(language?: string): string;
		export function locale(language?: string[]): string;
		export function locale(language?: string, definition?: LocaleSpecification | void): string; // null | undefined

		export function localeData(key?: string | string[]): Locale;

		export function duration(inp?: DurationInputArg1, unit?: DurationInputArg2): Duration;

		// NOTE(constructor): Same as moment constructor
		export function parseZone(
			inp?: MomentInput,
			format?: MomentFormatSpecification,
			strict?: boolean
		): Moment;
		export function parseZone(
			inp?: MomentInput,
			format?: MomentFormatSpecification,
			language?: string,
			strict?: boolean
		): Moment;

		export function months(): string[];
		export function months(index: number): string;
		export function months(format: string): string[];
		export function months(format: string, index: number): string;
		export function monthsShort(): string[];
		export function monthsShort(index: number): string;
		export function monthsShort(format: string): string[];
		export function monthsShort(format: string, index: number): string;

		export function weekdays(): string[];
		export function weekdays(index: number): string;
		export function weekdays(format: string): string[];
		export function weekdays(format: string, index: number): string;
		export function weekdays(localeSorted: boolean): string[];
		export function weekdays(localeSorted: boolean, index: number): string;
		export function weekdays(localeSorted: boolean, format: string): string[];
		export function weekdays(localeSorted: boolean, format: string, index: number): string;
		export function weekdaysShort(): string[];
		export function weekdaysShort(index: number): string;
		export function weekdaysShort(format: string): string[];
		export function weekdaysShort(format: string, index: number): string;
		export function weekdaysShort(localeSorted: boolean): string[];
		export function weekdaysShort(localeSorted: boolean, index: number): string;
		export function weekdaysShort(localeSorted: boolean, format: string): string[];
		export function weekdaysShort(localeSorted: boolean, format: string, index: number): string;
		export function weekdaysMin(): string[];
		export function weekdaysMin(index: number): string;
		export function weekdaysMin(format: string): string[];
		export function weekdaysMin(format: string, index: number): string;
		export function weekdaysMin(localeSorted: boolean): string[];
		export function weekdaysMin(localeSorted: boolean, index: number): string;
		export function weekdaysMin(localeSorted: boolean, format: string): string[];
		export function weekdaysMin(localeSorted: boolean, format: string, index: number): string;

		export function min(moments: Moment[]): Moment;
		export function min(...moments: Moment[]): Moment;
		export function max(moments: Moment[]): Moment;
		export function max(...moments: Moment[]): Moment;

		/**
		 * Returns unix time in milliseconds. Overwrite for profit.
		 */
		export function now(): number;

		export function defineLocale(
			language: string,
			localeSpec: LocaleSpecification | void
		): Locale; // null
		export function updateLocale(
			language: string,
			localeSpec: LocaleSpecification | void
		): Locale; // null

		export function locales(): string[];

		export function normalizeUnits(unit: unitOfTime.All): string;
		export function relativeTimeThreshold(threshold: string): number | boolean;
		export function relativeTimeThreshold(threshold: string, limit: number): boolean;
		export function relativeTimeRounding(fn: (num: number) => number): boolean;
		export function relativeTimeRounding(): (num: number) => number;
		export function calendarFormat(m: Moment, now: Moment): string;

		export function parseTwoDigitYear(input: string): number;

		/**
		 * Constant used to enable explicit ISO_8601 format parsing.
		 */
		export let ISO_8601: MomentBuiltinFormat;
		export let RFC_2822: MomentBuiltinFormat;

		export let defaultFormat: string;
		export let defaultFormatUtc: string;
		export let suppressDeprecationWarnings: boolean;
		export let deprecationHandler: ((name: string | void, msg: string) => void) | void;

		export let HTML5_FMT: {
			DATETIME_LOCAL: string;
			DATETIME_LOCAL_SECONDS: string;
			DATETIME_LOCAL_MS: string;
			DATE: string;
			TIME: string;
			TIME_SECONDS: string;
			TIME_MS: string;
			WEEK: string;
			MONTH: string;
		};
	}

	export = moment;
}

`,ya={axios:ia,cool:la,dayjs:ca,lodash:da,moment:ua},pa={class:"editor"},ma={class:"opbar"},fa=I({name:"node-code-editor"}),ga=I({...fa,props:{modelValue:String},setup(n){const l=n,{setRefs:e,mitt:a}=re(),o=de(),y=fe(l,"modelValue");function u(){a.emit("flow.runOpen",o.node)}function A(){Ie(()=>{var i;return(i=o.node)==null?void 0:i.data},i=>{var f,h;const t=(f=i==null?void 0:i.inputParams)==null?void 0:f.map(p=>`${p.field}: ${p.type||"string"};`).join(""),g=(h=i==null?void 0:i.outputParams)==null?void 0:h.map(p=>`${p.field}: ${p.type||"string"};`).join("");ut({path:"flow.d.ts",content:`
			declare interface Params { ${t} }
			declare interface Result { ${g} }`})},{immediate:!0,deep:!0})}function m(){["axios","dayjs","lodash","moment","cool"].forEach(i=>{ut({path:`${i}.d.ts`,content:ya[i]})})}const v=pe({visible:!1,open(){v.visible=!0}});return ge(()=>{A(),m()}),(i,t)=>{const g=S("cl-svg"),f=S("el-tooltip"),h=S("cl-editor-monaco"),p=S("cl-dialog");return d(),w("div",pa,[b("div",ma,[r(f,{content:"全屏"},{default:T(()=>[r(g,{name:"flow-fullscreen",class:"cl-flow__btn-icon",onClick:v.open},null,8,["onClick"])]),_:1}),r(f,{content:"调试"},{default:T(()=>[r(g,{name:"flow-debug",class:"cl-flow__btn-icon",onClick:u})]),_:1})]),r(h,{ref:E(e)("monaco"),modelValue:E(y),"onUpdate:modelValue":t[0]||(t[0]=s=>Oe(y)?y.value=s:null),language:"typescript",height:300},null,8,["modelValue"]),r(p,{modelValue:v.visible,"onUpdate:modelValue":t[2]||(t[2]=s=>v.visible=s),title:"代码编辑","keep-alive":"",fullscreen:"",scrollbar:!1,height:"500px",padding:"5px"},{default:T(()=>[r(h,{ref:E(e)("monaco"),modelValue:E(y),"onUpdate:modelValue":t[1]||(t[1]=s=>Oe(y)?y.value=s:null),language:"typescript",height:"100%"},null,8,["modelValue"])]),_:1},8,["modelValue"])])}}}),xt=Y(ga,[["__scopeId","data-v-000cffea"]]),ha=()=>({group:"行为",label:"执行代码",description:"执行一段自定义代码，可以调用框架的插件、数据库、service等",color:"#67c23a",component:ta,form:{width:"500px",items:[{label:"输入变量",prop:"inputParams",component:{vm:ke}},{label:"代码编辑",prop:"options.code",component:{vm:xt}},{label:"输出变量",prop:"outputParams",component:{vm:ze}}]},data:{inputParams:[{field:"arg1"}],outputParams:[{field:"result",type:"string"}],options:{code:`import axios from 'axios';
import * as _ from 'lodash';
import * as moment from 'moment';

/**
 * 代码执行
 */
export class Cool extends Base {
	/**
	 * 主函数
	 */
	async main(params: Params): Promise<Result> {
		console.log('Cool main', params);
		return {
			result: ""
		};
	}
}`}},validator(n){var e;const l=(e=n.inputParams)==null?void 0:e.find(a=>!a.nodeId);if(l)return`请绑定变量：${l.field}`}}),va=Object.freeze(Object.defineProperty({__proto__:null,default:ha},Symbol.toStringTag,{value:"Module"})),_a={class:"node-end"},ba=I({name:"undefined"}),xa=I({...ba,name:"node-end",setup(n){return(l,e)=>(d(),w("div",_a))}}),wa=()=>({group:"逻辑",label:"结束",description:"结束节点",color:"#f56c6c",component:xa,form:{items:[{label:"输出变量",prop:"outputParams",component:{vm:ke,props:{field:"res"}}}]},data:{outputParams:[{field:"res"}]},handle:{source:!1},validator(n){var e;const l=(e=n.outputParams)==null?void 0:e.find(a=>!a.nodeId);if(l)return`请绑定变量到${l.field}`}}),ka=Object.freeze(Object.defineProperty({__proto__:null,default:wa},Symbol.toStringTag,{value:"Module"})),Aa={key:0,class:"form-info"},Sa=I({name:"node-flow-form-info"}),Ra=I({...Sa,props:{flowId:Number},setup(n){const l=n,{service:e}=re(),a=ae();async function o(){a.value=await e.flow.info.info({id:l.flowId})}return ge(()=>{Ie(()=>l.flowId,y=>{y&&o()},{immediate:!0})}),(y,u)=>{const A=S("el-tag"),m=S("el-text");return a.value?(d(),w("div",Aa,[r(A,{"disable-transitions":"",type:"success",effect:"dark",size:"small"},{default:T(()=>{var v;return[se(q((v=a.value)==null?void 0:v.label),1)]}),_:1}),r(m,{truncated:!0,size:"small"},{default:T(()=>{var v;return[se(q((v=a.value)==null?void 0:v.name),1)]}),_:1})])):O("",!0)}}}),wt=Y(Ra,[["__scopeId","data-v-11f39ade"]]),Ta={key:0,class:"node-flow"},Ia=I({name:"undefined"}),Ca=I({...Ia,name:"node-flow",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>{var a,o;return(a=n.node.data)!=null&&a.options.flowId&&!n.focus?(d(),w("div",Ta,[r(wt,{"flow-id":(o=n.node.data)==null?void 0:o.options.flowId},null,8,["flow-id"])])):O("",!0)}}}),Da=Y(Ca,[["__scopeId","data-v-5407f6ba"]]),Ma={class:"form-select"},ja={key:0,class:"empty"},Ea=I({name:"node-flow-form-select"}),$a=I({...Ea,props:{modelValue:Number},emits:["update:modelValue"],setup(n,{emit:l}){const e=n,a=l,{service:o,route:y,mitt:u}=re(),A=de(),m=ae(),v=ae(!1),i=ln({service:o.flow.info}),t=cn({columns:[{type:"op",width:100,fixed:"left",buttons:[{label:"选择",type:"primary",props:{size:"small"},onClick({scope:x}){h(x.row)}}]},{label:"名称",prop:"name",minWidth:140},{label:"标签",prop:"label",minWidth:140},{label:"版本",prop:"version",minWidth:100},{label:"描述",prop:"description",showOverflowTooltip:!0,minWidth:200},{label:"发布时间",prop:"releaseTime",minWidth:170,sortable:"desc",formatter(x){return x.releaseTime||"未发布"}}]});async function g(x){var c;return(c=i.value)==null?void 0:c.refresh(x)}function f(x){m.value=x.id}function h(x){var $,D,z;const{nodes:c}=x.data||x.draft,_=c.find(X=>X.type=="start"),C=c.find(X=>X.type=="end");($=A.node)!=null&&$.data&&_&&C&&u.emit("flow.updateForm",{inputParams:(D=_.data)==null?void 0:D.inputParams,outputParams:(z=C.data)==null?void 0:z.outputParams}),m.value=x.id,a("update:modelValue",m.value),s()}function p(){v.value=!0,Ze(async()=>{var x;await g({status:1,isRelease:!0,flowId:y.query.id}),m.value=e.modelValue,m.value&&((x=t.value)==null||x.setCurrentRow(t.value.data.find(c=>c.id==m.value)))})}function s(){v.value=!1}return(x,c)=>{const _=S("cl-table"),C=S("cl-row"),$=S("cl-flex1"),D=S("cl-pagination"),z=S("cl-crud"),X=S("cl-dialog");return d(),w("div",Ma,[n.modelValue?(d(),W(wt,{key:1,"flow-id":n.modelValue,onClick:c[1]||(c[1]=ee=>p())},null,8,["flow-id"])):(d(),w("div",ja,[c[3]||(c[3]=b("span",null,"未选择流程，",-1)),b("span",{onClick:c[0]||(c[0]=ee=>p())},"点击选择")])),r(X,{modelValue:v.value,"onUpdate:modelValue":c[2]||(c[2]=ee=>v.value=ee),title:"选择流程",width:"1000px",controls:["close"]},{default:T(()=>[r(z,{ref_key:"Crud",ref:i,padding:"0"},{default:T(()=>[r(C,null,{default:T(()=>[r(_,{ref_key:"Table",ref:t,"auto-height":!1,onRowDblclick:h,onRowClick:f},null,512)]),_:1}),r(C,null,{default:T(()=>[r($),r(D)]),_:1})]),_:1},512)]),_:1},8,["modelValue"])])}}}),Pa=Y($a,[["__scopeId","data-v-36788763"]]),Oa=()=>({group:"扩展",label:"流程",description:"执行其他流程",color:"#fd9d2f",component:Da,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{disabled:!0,editField:!1,placeholder:"请先选择流程"}}},{label:"选择流程",prop:"options.flowId",component:{vm:Pa}},{label:"输出变量",prop:"outputParams",component:{vm:ze,props:{editField:!1,editType:!1,op:!1}}}]},data:{options:{},inputParams:[],outputParams:[]},validator(n){if(!n.options.flowId)return"请选择流程"}}),Va=Object.freeze(Object.defineProperty({__proto__:null,default:Oa},Symbol.toStringTag,{value:"Module"})),Na={class:"node-json"},La=I({name:"undefined"}),Fa=I({...La,name:"node-json",setup(n){return(l,e)=>(d(),w("div",Na))}}),qa=()=>({group:"行为",label:"JSON解析",description:"将文本内容中的JSON字符串转换为对象",color:"#67c23a",component:Fa,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{field:"text"}}},{label:"输出变量",component:{vm:He,props:{text:["json<object> 输出内容"]}}}]},data:{inputParams:[{field:"text",type:"string"}],outputParams:[{field:"json",type:"object"}]}}),Ba=Object.freeze(Object.defineProperty({__proto__:null,default:qa},Symbol.toStringTag,{value:"Module"})),Ua={class:"node-judge"},Ha={class:"item"},za={class:"item"},Wa=I({name:"undefined"}),Ya=I({...Wa,name:"node-judge",props:{node:{type:Object,default:()=>({})}},setup(n){return(l,e)=>(d(),w("div",Ua,[b("div",Ha,[e[0]||(e[0]=b("span",null," 满足 ",-1)),r(Le,{type:"source","node-id":n.node.id,id:"source-if",position:{right:"-24px"}},null,8,["node-id"])]),b("div",za,[e[1]||(e[1]=b("span",null," 不满足 ",-1)),r(Le,{type:"source","node-id":n.node.id,id:"source-else",position:{right:"-24px"}},null,8,["node-id"])])]))}}),Ga=Y(Ya,[["__scopeId","data-v-24d9d2e0"]]),Ka={class:"form-if"},Xa={class:"operator"},Ja=I({name:"node-judge-form-if"}),Qa=I({...Ja,props:{modelValue:{type:Object,default:()=>({})}},setup(n){const l=n,e=nt(),a=fe(l,"modelValue"),o=[{label:"包含",value:"include"},{label:"不包含",value:"exclude"},{label:"开始是",value:"startWith"},{label:"结束是",value:"endWith"},{label:"等于",value:"equal"},{label:"不等于",value:"notEqual"},{label:"大于",value:"greaterThan"},{label:"大于等于",value:"greaterThanOrEqual"},{label:"小于",value:"lessThan"},{label:"小于等于",value:"lessThanOrEqual"},{label:"为空",value:"isNull"},{label:"不为空",value:"isNotNull"}],y=[{label:"OR",value:"OR"},{label:"AND",value:"AND"}];function u(m){a.value.splice(m,1)}function A(){a.value.push({field:"",condition:"",value:"",operator:"OR"})}return ge(()=>{a.value.forEach(m=>{m.operator||(m.operator="OR")}),Ie(a,m=>{e.value.form.inputParams=tn(m.map(v=>({...v,condition:void 0,operator:void 0,value:void 0})),"field")},{immediate:!0,deep:!0})}),(m,v)=>{const i=S("cl-svg"),t=S("el-option"),g=S("el-select"),f=S("el-input"),h=S("el-button"),p=S("el-button-group");return d(),w("div",Ka,[r(i,{name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:v[0]||(v[0]=s=>A())}),(d(!0),w(K,null,ne(E(a),(s,x)=>(d(),w("div",{class:"item",key:x},[r(at,{modelValue:s.field,"onUpdate:modelValue":c=>s.field=c,nodeId:s.nodeId,"onUpdate:nodeId":c=>s.nodeId=c,nodeType:s.nodeType,"onUpdate:nodeType":c=>s.nodeType=c},null,8,["modelValue","onUpdate:modelValue","nodeId","onUpdate:nodeId","nodeType","onUpdate:nodeType"]),r(g,{modelValue:s.condition,"onUpdate:modelValue":c=>s.condition=c,placeholder:"操作符",style:{width:"100px"},"popper-class":"cl-flow__popper"},{default:T(()=>[(d(),w(K,null,ne(o,c=>r(t,{key:c.value,label:c.label,value:c.value},null,8,["label","value"])),64))]),_:2},1032,["modelValue","onUpdate:modelValue"]),r(f,{modelValue:s.value,"onUpdate:modelValue":c=>s.value=c,placeholder:"输入值",style:{width:"100px"}},null,8,["modelValue","onUpdate:modelValue"]),r(i,{class:"cl-flow__btn-icon",name:"delete",onClick:c=>u(x)},null,8,["onClick"]),b("div",Xa,[r(p,{size:"small"},{default:T(()=>[(d(),w(K,null,ne(y,c=>r(h,{key:c.value,type:s.operator==c.value?"primary":"",onClick:_=>s.operator=c.value},{default:T(()=>[se(q(c.label),1)]),_:2},1032,["type","onClick"])),64))]),_:2},1024)])]))),128))])}}}),Za=Y(Qa,[["__scopeId","data-v-eb98b2e3"]]),eo=()=>({group:"逻辑",label:"条件判断",description:"条件判断节点",color:"#f56c6c",component:Ga,form:{items:[{label:"满足",prop:"options.IF",component:{vm:Za}},{label:"不满足",component:()=>zt(Kt(S("el-text")),{type:"info",size:"small"},()=>"用于定义当条件不满足时应执行的逻辑。")}]},data:{inputParams:[],options:{IF:[{}],ELSE:[]},outputParams:[{type:"boolean",field:"result"}]},handle:{source:!1,next:[{label:"满足",value:"source-if"},{label:"不满足",value:"source-else"}]},validator(n){var e;if((e=n.options.IF)==null?void 0:e.find(a=>!a.nodeId||!a.condition||!a.value))return"条件判断格式异常"}}),to=Object.freeze(Object.defineProperty({__proto__:null,default:eo},Symbol.toStringTag,{value:"Module"})),no={class:"list"},ao={class:"name"},oo=I({name:"node-know-form-list"}),so=I({...oo,props:{modelValue:{type:Array,default:()=>[]},deletable:Boolean},setup(n){const l=n,{service:e}=re(),a=fe(l,"modelValue"),o=ae([]),y=Z(()=>a.value.map(A=>o.value.find(m=>m.id===A)).filter(Boolean));function u(){e.flow.config.config({node:"know"}).then(A=>{o.value=A.knows||[]})}return ge(()=>{u()}),(A,m)=>{const v=S("cl-svg");return d(),w("div",no,[(d(!0),w(K,null,ne(y.value,(i,t)=>(d(),w("div",{class:"item",key:t},[r(v,{name:"flow-know",class:"icon"}),b("span",ao,q(i.name),1),n.deletable?(d(),W(v,{key:0,class:"cl-flow__btn-icon del",name:"delete",onClick:()=>{E(a).splice(t,1)}},null,8,["onClick"])):O("",!0)]))),128))])}}}),kt=Y(so,[["__scopeId","data-v-1ff37890"]]),ro={key:0,class:"node-know"},io=I({name:"undefined"}),lo=I({...io,name:"node-know",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>{var a;return(a=n.node)!=null&&a.data&&!E(Q)(n.node.data.options.knowIds)&&!n.focus?(d(),w("div",ro,[r(kt,{modelValue:n.node.data.options.knowIds,"onUpdate:modelValue":e[0]||(e[0]=o=>n.node.data.options.knowIds=o)},null,8,["modelValue"])])):O("",!0)}}}),co=Y(lo,[["__scopeId","data-v-f9b5370c"]]),uo={class:"form-select"},yo={key:0,class:"empty border"},po={class:"list"},mo=["onClick"],fo={class:"name"},go={key:0,class:"desc"},ho={key:0,class:"empty"},vo={class:"op"},_o=I({name:"node-know-form-select"}),bo=I({..._o,props:{modelValue:{type:Array,default:()=>[]}},setup(n){const l=n,{service:e,router:a}=re(),o=ae(!1),y=fe(l,"modelValue"),u=ae([]);function A(){e.flow.config.config({node:"know"}).then(f=>{u.value=f.knows||[]})}const m=ae([]);function v(f){const h=m.value.findIndex(p=>p==f);h>=0?m.value.splice(h,1):m.value.push(f)}function i(){o.value=!0,m.value=[...y.value],A()}function t(){o.value=!1}function g(){if(Q(m.value))return ue.warning("至少选择一个知识库");y.value=[...m.value],t()}return(f,h)=>{const p=S("cl-svg"),s=S("el-button"),x=S("cl-dialog");return d(),w("div",uo,[r(p,{name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:h[0]||(h[0]=c=>i())}),r(kt,{modelValue:E(y),"onUpdate:modelValue":h[1]||(h[1]=c=>Oe(y)?y.value=c:null),deletable:""},null,8,["modelValue"]),E(Q)(E(y))?(d(),w("div",yo,[h[5]||(h[5]=b("span",null,"未选择知识库，",-1)),b("span",{onClick:h[2]||(h[2]=c=>i())},"点击选择")])):O("",!0),r(x,{modelValue:o.value,"onUpdate:modelValue":h[4]||(h[4]=c=>o.value=c),title:"选择知识库",width:"400px",controls:["close"]},{default:T(()=>[b("div",po,[(d(!0),w(K,null,ne(u.value,(c,_)=>(d(),w("div",{class:ce(["item",{active:m.value.includes(c.id)}]),key:_,onClick:C=>v(c.id)},[b("p",fo,q(c.name),1),c.description?(d(),w("p",go,q(c.description),1)):O("",!0)],10,mo))),128))]),E(Q)(u.value)?(d(),w("div",ho,[h[6]||(h[6]=b("span",null,"暂无知识库，",-1)),b("span",{onClick:h[3]||(h[3]=c=>E(a).push("/know/data/type"))},"点击添加")])):O("",!0),b("div",vo,[r(s,{onClick:t},{default:T(()=>h[7]||(h[7]=[se("取消")])),_:1,__:[7]}),r(s,{type:"primary",onClick:g},{default:T(()=>h[8]||(h[8]=[se("确定")])),_:1,__:[8]})])]),_:1},8,["modelValue"])])}}}),xo=Y(bo,[["__scopeId","data-v-5b5966dc"]]),wo=()=>({group:"信息",label:"知识库",description:"从知识库中检索出相关的内容",component:co,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{editField:!1,disabled:!0}}},{label:"选择知识库",prop:"options.knowIds",component:{vm:xo}},{label:"结果条数",prop:"options.size",component:{name:"el-input-number",props:{min:1,max:100}}},{label:"分值过滤",prop:"options.minScore",component:{name:"el-input-number",props:{min:.001,max:1,step:.001}}},{label:"输出变量",component:{vm:He,props:{text:["documents<object[]> 文档列表","text<string> 文档内容"]}}}]},data:{inputParams:[{field:"text"}],outputParams:[{field:"documents",type:"object[]"},{field:"text",type:"string"}],options:{knowIds:[],size:30,minScore:0}},validator(n){var a;const{knowIds:l}=n.options,e=(a=n.inputParams)==null?void 0:a.find(o=>!o.nodeId);if(e)return`请绑定变量：${e.field}`;if(Q(l))return"请选择知识库"}}),ko=Object.freeze(Object.defineProperty({__proto__:null,default:wo},Symbol.toStringTag,{value:"Module"})),Ao={key:0,class:"node-llm"},So={class:"model"},Ro=I({name:"undefined"}),To=I({...Ro,name:"node-llm",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>{var a,o;return n.focus?O("",!0):(d(),w("div",Ao,[b("div",So,[r(ht,{data:(o=(a=n.node.data)==null?void 0:a.options)==null?void 0:o.model},null,8,["data"])])]))}}}),Io=Y(To,[["__scopeId","data-v-81ecc24c"]]),Co={class:"form-content"},Do={class:"list"},Mo={class:"head"},jo={class:"op"},Eo={class:"content"},$o={class:"flex items-center"},Po={class:"text-[13px] ml-2 mr-auto"},Oo={class:"text-[12px] text-gray-400"},Vo=I({name:"undefined"}),No=I({...Vo,name:"node-llm-form-content",props:{modelValue:{type:Array,default:()=>[]}},setup(n){const l=n,{refs:e,setRefs:a}=re(),o=ae(!1),y=fe(l,"modelValue"),u=Z(()=>e.toolsVar.list.map(i=>({...i,children:i.params.map(t=>({...t,label:t.field,value:t.field}))})));function A(i){return[{label:"SYSTEM",value:"system"},{label:"USER",value:"user"},{label:"ASSISTANT",value:"assistant"}].filter(t=>i.role=="system"?!0:t.value!="system")}function m(){const i=Je(y.value);y.value.push({role:(i==null?void 0:i.role)=="user"?"assistant":"user",content:""})}function v(i){y.value.splice(i,1)}return ge(()=>{setTimeout(()=>{o.value=!0},100)}),(i,t)=>{const g=S("cl-svg"),f=S("el-option"),h=S("el-select"),p=S("ai-mention");return d(),w("div",Co,[r(g,{name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:t[0]||(t[0]=s=>m())}),b("div",Do,[(d(!0),w(K,null,ne(E(y),(s,x)=>(d(),w("div",{key:x,class:ce(["item cl-flow__textarea-item",{error:!s.content}])},[b("div",Mo,[r(h,{class:"role",modelValue:s.role,"onUpdate:modelValue":c=>s.role=c,size:"small","popper-class":"cl-flow__popper",disabled:s.role=="system"},{default:T(()=>[(d(!0),w(K,null,ne(A(s),c=>(d(),W(f,{label:c.label,value:c.value,key:c.value},null,8,["label","value"]))),128))]),_:2},1032,["modelValue","onUpdate:modelValue","disabled"]),b("div",jo,[x>1?(d(),W(g,{key:0,name:"delete",class:"cl-flow__btn-icon",onClick:c=>v(x)},null,8,["onClick"])):O("",!0)])]),b("div",Eo,[o.value?(d(),W(p,{key:0,modelValue:s.content,"onUpdate:modelValue":c=>s.content=c,prefix:"/","label-formatter":c=>c.label,options:u.value,"is-group":"",height:"auto"},{"popper-item":T(({item:c})=>[b("div",$o,[r(g,{name:"flow-var",size:18}),b("span",Po,q(c.label),1),b("span",Oo,q(c.type),1)])]),_:2},1032,["modelValue","onUpdate:modelValue","label-formatter","options"])):O("",!0)])],2))),128))]),r(at,{ref:E(a)("toolsVar"),"only-select":"",position:"absolute","show-picker":!1,autofocus:!1,"use-input-params":""},null,512)])}}}),Lo=Y(No,[["__scopeId","data-v-d512f272"]]),Fo={class:"form-input-number"},qo={key:0,class:"label prefix"},Bo={key:1,class:"label suffix"},Uo=I({name:"undefined"}),Ho=I({...Uo,name:"node-base-form-input-number",props:{modelValue:null,prefix:String,suffix:String,min:{type:Number,default:0},max:{type:Number,default:9999999999},precision:{type:Number,default:0}},setup(n){const e=fe(n,"modelValue");return(a,o)=>{const y=S("el-input-number");return d(),w("div",Fo,[n.prefix?(d(),w("span",qo,q(n.prefix),1)):O("",!0),b("div",null,[r(y,{modelValue:E(e),"onUpdate:modelValue":o[0]||(o[0]=u=>Oe(e)?e.value=u:null),min:n.min,max:n.max,precision:n.precision},null,8,["modelValue","min","max","precision"])]),n.suffix?(d(),w("span",Bo,q(n.suffix),1)):O("",!0)])}}}),zo=Y(Ho,[["__scopeId","data-v-d75e9486"]]),Wo={class:"form-model-tools"},Yo=I({name:"undefined"}),Go=I({...Yo,name:"node-llm-form-tools",props:{modelValue:{type:Array,default:()=>[]}},emits:["update:modelValue"],setup(n,{emit:l}){const e=n,a=l,{service:o}=re(),y=ae([]),u=Z(()=>e.modelValue.map(v=>v.id).filter(Boolean));function A(v){a("update:modelValue",v.map(i=>{const t=y.value.find(g=>g.id==i);return{id:i,key:t==null?void 0:t.type,options:(t==null?void 0:t.options)||{}}}))}async function m(){y.value=await o.flow.config.getByNode({node:"tool"})}return ge(()=>{m()}),(v,i)=>{const t=S("cl-select");return d(),w("div",Wo,[r(t,{"model-value":u.value,"popper-class":"cl-flow__popper",teleported:!1,"label-key":"name","value-key":"id",multiple:"",options:y.value,onChange:A},null,8,["model-value","options"])])}}}),Ko=Y(Go,[["__scopeId","data-v-b419d232"]]),Xo={class:"form-model-mcp"},Jo=I({name:"undefined"}),Qo=I({...Jo,name:"node-llm-form-mcp",props:{modelValue:{type:Array,default:()=>[]}},emits:["update:modelValue"],setup(n,{emit:l}){const e=n,a=l,{service:o}=re(),y=ae([]),u=Z(()=>e.modelValue.map(v=>v.id).filter(Boolean));function A(v){a("update:modelValue",v.map(i=>{const t=y.value.find(g=>g.id==i);return{id:i,key:t==null?void 0:t.type,options:(t==null?void 0:t.options)||{}}}))}async function m(){y.value=await o.flow.config.getByNode({node:"mcp"})}return ge(()=>{m()}),(v,i)=>{const t=S("cl-select");return d(),w("div",Xo,[r(t,{"model-value":u.value,"popper-class":"cl-flow__popper",teleported:!1,"label-key":"name","value-key":"id",multiple:"",options:y.value,onChange:A},null,8,["model-value","options"])])}}}),Zo=Y(Qo,[["__scopeId","data-v-c2d97211"]]),es=()=>({group:"AI",label:"LLM",description:"调用大语言模型回答问题",color:"#409eff",component:Io,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{field:"input"}}},{label:"模型",prop:"options.model",component:{vm:et}},{label:"工具",prop:"options.toolConfig",component:{vm:Ko}},{label:"MCP",prop:"options.mcpConfig",component:{vm:Zo}},{label:"消息",prop:"options.messages",component:{vm:Lo}},{label:"历史数据",prop:"options.history",span:12,component:{vm:zo,props:{prefix:"保存",suffix:"条"}}},{label:"是否输出",prop:"options.isOutput",flex:!1,component:{name:"el-switch"}},{label:"输出变量",component:{vm:He,props:{text:["text<string> 回复内容"]}}}]},data:{inputParams:[{field:"input"}],outputParams:[{type:"string",field:"text"},{type:"stream",field:"stream"}],options:{model:{options:[],params:{model:""}},messages:[{role:"system",content:""},{role:"user",content:""}],history:0,isOutput:!0,toolConfig:[],mcpConfig:[]}},validator(n){var y;const{model:l,messages:e}=n.options,a=(y=n.inputParams)==null?void 0:y.find(u=>!u.nodeId);if(a)return`请绑定变量：${a.field}`;if(!l.params.model)return"请选择模型";const o=e.find(u=>!u.content);if(o)return`请填写${o.role}消息`}}),ts=Object.freeze(Object.defineProperty({__proto__:null,default:es},Symbol.toStringTag,{value:"Module"})),ns={class:"node-parse"},as=I({name:"undefined"}),os=I({...as,name:"node-parse",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>(d(),w("div",ns))}}),ss=()=>({group:"扩展",label:"智能解析",description:"智能提取内容的关键信息",color:"#fd9d2f",component:os,form:{items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{editField:!1,disabled:!0}}},{label:"模型",prop:"options.model",component:{vm:et}},{label:"输出变量",prop:"outputParams",component:{vm:ze,props:{typeInput:!0,disabledFields:["result"]}}}]},data:{options:{model:{options:[],params:{model:""}}},inputParams:[{field:"text"}],outputParams:[{field:"result",type:"输入结果"}]},validator(n){var a;const{model:l}=n.options,e=(a=n.inputParams)==null?void 0:a.find(o=>!o.nodeId);if(e)return`请绑定变量：${e.field}`;if(!l.params.model)return"请选择模型"}}),rs=Object.freeze(Object.defineProperty({__proto__:null,default:ss},Symbol.toStringTag,{value:"Module"})),is={class:"tools-fields"},ls=["onClick"],cs={class:"name"},ds={key:0},us={key:0,class:"required"},ys={class:"op"},ps=I({name:"undefined"}),ms=I({...ps,name:"tools-fields",props:{modelValue:{type:Array,default:()=>[]},disabled:Boolean},emits:["update:modelValue","edit"],setup(n,{emit:l}){const e=n,a=l,o=fe(e,"modelValue");function y(A){a("edit",A)}function u(A){o.value.splice(A,1)}return(A,m)=>{const v=S("cl-svg");return d(),w("div",is,[(d(!0),w(K,null,ne(E(o),(i,t)=>(d(),w("div",{class:ce(["item",{disabled:n.disabled}]),key:t,onClick:g=>y(i)},[r(v,{name:"flow-"+i.type,class:"type"},null,8,["name"]),b("div",cs,[se(q(i.field)+" ",1),n.disabled?O("",!0):(d(),w("span",ds," · "+q(i.label),1))]),i.required?(d(),w("span",us,"必填")):O("",!0),b("div",ys,[r(v,{name:"delete",class:"cl-flow__btn-icon",onClick:we(g=>u(t),["stop"])},null,8,["onClick"])])],10,ls))),128))])}}}),At=Y(ms,[["__scopeId","data-v-f6015268"]]),fs={key:0,class:"node-start"},gs=I({name:"undefined"}),hs=I({...gs,name:"node-start",props:{node:{type:Object,default:()=>({})},focus:{type:Boolean,default:!1}},setup(n){return(l,e)=>{var a,o;return!E(Q)((o=(a=n.node)==null?void 0:a.data)==null?void 0:o.inputParams)&&!n.focus?(d(),w("div",fs,[r(At,{modelValue:n.node.data.inputParams,"onUpdate:modelValue":e[0]||(e[0]=y=>n.node.data.inputParams=y),disabled:""},null,8,["modelValue"])])):O("",!0)}}}),vs=Y(hs,[["__scopeId","data-v-7f755a3e"]]),_s={class:"form-fields"},bs={key:0,class:"empty"},xs=I({name:"undefined"}),ws=I({...xs,name:"node-start-form-fields",props:{...dn,modelValue:Array},setup(n){const l=n,{t:e}=un(),a=nt(),o=fe(l,"modelValue");function y(u){var A;(A=a.value)==null||A.open({title:e("添加变量"),width:"500px",dialog:{controls:["close"]},props:{labelPosition:"top"},form:{...u},items:[{label:e("字段类型"),prop:"type",value:"text",component:{name:"el-radio-group",options:[{label:e("文本"),value:"text"},{label:e("数字"),value:"number"},{label:e("图片"),value:"image"},{label:e("文件"),value:"file"}]},required:!0},{label:e("变量名称"),prop:"field",component:{name:"el-input",props:{clearable:!0,maxlength:20}},rules:[{required:!0,validator(m,v,i){Q(v)?i(new Error(e("请输入变量名称"))):/^[a-zA-Z][a-zA-Z0-9_]*$/.test(v)?i():i(new Error(e("只能由字母、数字、下划线组成，且以字母开头")))}}]},{label:e("显示名称"),prop:"label",component:{name:"el-input",props:{clearable:!0,maxlength:20}},required:!0},{label:e("必填"),prop:"required",value:1,component:{name:"cl-switch"},required:!0}],on:{submit(m,{close:v,done:i}){var t,g;if((t=o.value)!=null&&t.find(f=>f.field==m.field)&&(u==null?void 0:u.field)!=m.field)return i(),ue.warning(e("变量名称已存在"));u?Ve(u,m):(g=o.value)==null||g.push(m),v()}}},[ft.Form.setFocus("value")])}return(u,A)=>{const m=S("cl-svg"),v=S("el-text"),i=S("cl-form");return d(),w(K,null,[b("div",_s,[r(m,{name:"flow-add",class:"cl-flow__btn-icon is-rt",onClick:A[0]||(A[0]=t=>y())}),E(Q)(E(o))?(d(),w("div",bs,[r(v,{size:"small"},{default:T(()=>[se(q(u.$t("设置的输入可在工作流程中使用")),1)]),_:1}),r(v,{size:"small",type:"primary",onClick:A[1]||(A[1]=t=>y())},{default:T(()=>[se(q(u.$t("立即添加")),1)]),_:1})])):O("",!0),r(At,{modelValue:E(o),"onUpdate:modelValue":A[2]||(A[2]=t=>Oe(o)?o.value=t:null),onEdit:y},null,8,["modelValue"])]),r(i,{ref_key:"Form",ref:a},null,512)],64)}}}),ks=Y(ws,[["__scopeId","data-v-cc08010b"]]),As=()=>({label:"开始",description:"开始节点",color:"#409eff",form:{items:[{label:"输入字段",prop:"inputParams",component:{vm:ks}}]},data:{inputParams:[{label:"内容",field:"content",type:"text",required:!0}]},handle:{target:!1},component:vs,validator(n){if(Q(n.inputParams))return"至少要输入一个字段"}}),Ss=Object.freeze(Object.defineProperty({__proto__:null,default:As},Symbol.toStringTag,{value:"Module"})),Rs={class:"node-variable"},Ts=I({name:"undefined"}),Is=I({...Ts,name:"node-variable",props:{node:{type:Object,default:()=>({})}},setup(n){return(l,e)=>(d(),w("div",Rs))}}),Cs=()=>({group:"行为",label:"变量",description:"变量转换或赋值",color:"#67c23a",form:{width:"500px",items:[{label:"输入变量",prop:"inputParams",component:{vm:ke,props:{varInputable:!0}}},{label:"代码编辑",prop:"options.code",component:{vm:xt}},{label:"输出变量",prop:"outputParams",component:{vm:ze}}]},data:{options:{code:`async function main(params: Params): Promise<Params> {
	return params;
}`},inputParams:[{field:"arg1"}],outputParams:[{field:"arg1",type:"string"}]},component:Is,validator(n){var e;if(Q(n.inputParams))return"至少要输入一个字段";const l=(e=n.inputParams)==null?void 0:e.find(a=>!a.value&&!a.nodeId);if(l)return`请绑定变量或填写内容：${l.field}`}}),Ds=Object.freeze(Object.defineProperty({__proto__:null,default:Cs},Symbol.toStringTag,{value:"Module"})),yt=Object.assign({"./classify/index.ts":Qn,"./code/index.ts":va,"./end/index.ts":ka,"./flow/index.ts":Va,"./json/index.ts":Ba,"./judge/index.ts":to,"./know/index.ts":ko,"./llm/index.ts":ts,"./parse/index.ts":rs,"./start/index.ts":Ss,"./variable/index.ts":Ds}),Ee=Xt([]);var mt;for(const n in yt){const[,l]=n.split("/"),e=yt[n].default();if(e.enable!==!1){const a=((mt=e.form)==null?void 0:mt.width)||"400px",o=`${parseFloat(a)+30}px`;Ee.value.push({...e,type:l,name:`node-${l}`,icon:l,cardWidth:o})}}const Ms=new pn,Me={x:400,y_t:-10,y_b:50,g:150};let pt=1,Ke;const de=()=>{const n=gt(),{mitt:l}=re(),{copy:e}=yn();return Bt(`flow-${n.id}`,()=>{const o=Z(()=>n.nodes.value),y=Z(()=>n.edges.value),u=ae();function A(k){u.value=k}function m(k=!0){k&&u.value&&it("close",u.value,u.value.id),u.value=void 0}function v(k,R){const M=Ee.value.find(U=>U.type==k),j={type:k,data:{inputParams:[],outputParams:[],options:{}},position:{x:0,y:0},...M,...R,id:String(pt++),_index:1},V=Be(o.value,"_index","desc").find(U=>U.type==k);return V&&(j._index=(V._index||1)+1,j.label=`${j.label} ${j._index}`),n.addNodes(Ne(j)),f(j.id)}function i(k,R,M){if(R)return v(k,{position:ie(R),...M})}function t(k,R){const M=f(k);M&&(R.name&&R.name!=M.name&&(oe(k),["handle","data","form"].forEach(j=>{R[j]||(R[j]={})})),Ve(M,R),n.updateNode(k,R))}function g(k,R){const M=(_t(k)?k:[k]).filter(j=>R?!0:j.type!="start");n.removeNodes(M),M.forEach(j=>{var V;oe(j.id),j.id==((V=u.value)==null?void 0:V.id)&&m()})}function f(k){return o.value.find(R=>R.id===k)}function h(k){return o.value.find(R=>R.type===k)}function p(k){return _(k).filter(R=>Q(c(R.id)))}function s(k){return y.value.filter(R=>R.target==k).map(R=>f(R.source))}function x(k){const R=[],M=new Set;function j(V){const U=s(V);Q(U)||U.forEach(J=>{M.has(J.id)||(M.add(J.id),R.push(J),j(J.id))})}return j(k),Be(R,"id","asc")}function c(k,R){var U;const M=f(k),j=y.value.filter(J=>J.source==k);return(((U=M==null?void 0:M.handle)==null?void 0:U.next)||[{value:"source"}]).filter(J=>R?J.value==R:!0).map(J=>{const G=j.find(me=>me.sourceHandle==J.value);return G?f(G.target):null}).filter(J=>!!J)}function _(k,R){const M=[];function j(V,U=0){c(V,U==0?R:void 0).forEach(G=>{M.push(G),j(G.id,U+1)})}return j(k,0),M}function C(k){const R=x(k),M=_(k);return[...R,f(k),...M].filter(j=>!!j)}function $(k){return y.value.filter(R=>R.source==k.source&&k.sourceHandle==R.sourceHandle||R.target==k.target&&k.targetHandle==R.targetHandle)}function D(k){const R=$(k);Q(R),n.addEdges({...k,animated:!1,updatable:!0,style:{strokeWidth:1.5},type:"button"})}function z(k){return n.findEdge(k)}function X(k,R){const M=z(k);M&&Ve(M,R)}function ee(k){n.removeEdges(k)}function oe(k,R){const M=y.value.filter(j=>R?j[R]==k:j.source==k||j.target==k);return ee(M),M}function F(k,R){const M=getComputedStyle(document.documentElement).getPropertyValue("--el-color-primary");y.value.filter(j=>j.target==k||j.source==k).forEach(j=>{var U;const V=R?M:j._stroke||"";j._stroke=(U=j.style)==null?void 0:U.stroke,X(j.id,{style:{stroke:V}})})}function L(k){return k?!["start","end"].includes(k.type):!1}function N(){if(Q(o.value)){const k=v("start",{position:{x:100,y:100}});v("end",{position:{x:Me.x+Me.g,y:100}}),A(k)}}function B(){ee(y.value),g(o.value,!0),N(),ye({x:0,y:0})}function H(k){e(JSON.stringify({type:"copyNode",data:{type:k.type,label:k.label,description:k.description,data:k.data}}))}async function te(){const k=await navigator.clipboard.readText();try{const{type:R,data:M}=JSON.parse(k);if(R=="copyNode")return e(""),M}catch{}return null}const he=ae(100);function Ce(k){he.value=k}const Re=ae("hand");function le(k){Re.value=k,n.panOnDrag.value=k=="hand"}const ve=Z(()=>n.viewport.value||{zoom:1});function ye({x:k,y:R,zoom:M},j=300){n.setViewport({x:k,y:R,zoom:M||ve.value.zoom},{duration:j})}async function P(k){if(!k)return!1;await qe(10);const{zoom:R}=ve.value;if(k){const M=document.querySelector(".cl-flow"),j=document.querySelector(".cl-flow .tools-panel-right"),V=document.querySelector(`div[data-id="${k.id}"]`),{x:U=0,y:J=0}=k.position||{},G=(((M==null?void 0:M.clientHeight)||0)-((V==null?void 0:V.clientHeight)||0)*R)/2-J*R,me=(((M==null?void 0:M.clientWidth)||0)-(((j==null?void 0:j.clientWidth)||0)+10)-((V==null?void 0:V.clientWidth)||0)*R)/2-U*R;ye({x:me,y:G})}else ye({x:0,y:0})}function Te(k){P(f(k))}function ie(k,R){var G;const{x:M=0,y:j=0}=k.position||{},V={x:M+Me.x,y:0},U=c(k.id),J=U[0];if(Q(U))V.y=j-Me.y_t;else{const me=U.length,_e=U.filter((be,xe)=>xe<me).reduce((be,xe)=>{var je;return be+(((je=document.querySelector(`div[data-id="${xe.id}"]`))==null?void 0:je.clientHeight)||0)+Me.y_b},((G=J==null?void 0:J.position)==null?void 0:G.y)||0);V.y=_e}return V}const De=bt(()=>{const k={id:"root",layoutOptions:{"elk.algorithm":"layered","elk.spacing.nodeNode":"80","elk.layered.spacing.nodeNodeBetweenLayers":"180","elk.layered.spacing.edgeNodeBetweenLayers":"50","elk.layered.spacing.edgeEdgeBetweenLayers":"200","elk.layered.edgeRouting":"ORTHOGONAL","elk.layered.crossingMinimization.strategy":"LAYER_SWEEP","elk.layered.considerModelOrder.strategy":"NODES_AND_EDGES","elk.layered.nodePlacement.strategy":"NETWORK_SIMPLEX","elk.layered.avoidOverlap":"true","elk.layered.edgeLabels.sideSelection":"SMART"},children:o.value.map(R=>{const M=document.querySelector(`div[data-id="${R.id}"]`),j=(M==null?void 0:M.clientHeight)||0,V=(M==null?void 0:M.clientWidth)||0;return{id:R.id,width:V,height:j}}),edges:y.value.map(R=>({id:R.id,sources:[R.source],targets:[R.target]}))};Ms.layout(k).then(R=>{o.value.forEach(M=>{const j=R.children.find(V=>V.id===M.id);t(M.id,{position:{x:j.x,y:j.y}})})}),ye({x:0,y:0,zoom:1})},300);function ot(){n.deleteKeyCode.value="none",n.connectOnClick.value=!1}const Ae=ae();async function St(k){var R;return await Ke,lt.flow.info.info({id:k||((R=Ae.value)==null?void 0:R.id)}).then(M=>(M?(Ae.value=M,rt(M.draft),Q(o.value)&&N()):Ue.alert("流程不存在或异常，请重新选择。","提示",{callback(){jt.back()}}),M))}function st(k,R){const M=k.map(V=>{var U,J;return V.type=="start"?(J=(U=V.data)==null?void 0:U.inputParams)==null||J.forEach(G=>{G.name=G.field,G.nodeId=V.id,G.nodeType="start"}):["inputParams","outputParams"].forEach(G=>{var me,_e;(me=V.data)!=null&&me[G]&&((_e=V.data)==null||_e[G].forEach(be=>{const xe=f(be.nodeId);xe&&(be.nodeType=xe.type)}))}),{...V,component:void 0,form:void 0}}),j=R.map(V=>({...V,animated:!1,style:{}}));return{nodes:M,edges:j}}async function Rt(){var U,J,G;if(!((U=Ae.value)!=null&&U.id))return!1;const{nodes:k,edges:R,viewport:M}=n.toObject(),{nodes:j,edges:V}=st(k,R);Ke=lt.flow.info.update({id:(J=Ae.value)==null?void 0:J.id,draft:{nodes:j,edges:V,viewport:M,activeNodeId:(G=u.value)==null?void 0:G.id}}),await Ke}async function rt(k){k&&(await n.fromObject(k),he.value=ve.value.zoom*100,Q(o.value)||(pt=Math.max(...o.value.map(R=>Number(R.id)))+1,o.value.forEach(R=>{var j;const M=Ee.value.find(V=>V.type==R.type);if(M){const V=((j=M.form)==null?void 0:j.width)||"400px",U=`${parseFloat(V)+30}px`;R.component=M.component,R.form=M.form,R.color=M.color,R.group=M.group,R.validator=M.validator,R.cardWidth=U}})))}function Tt(k){const R=nn(Ee.value.filter(j=>j.type!="start"&&j.type!="end"),"group");let M=tt(R).map(j=>({label:j,children:R[j].filter(V=>{var U;return k?(U=V.label)==null?void 0:U.includes(k):!0})})).filter(j=>!Q(j.children));return M=Be(M,"label","asc"),M}function It(k,R){return[(k-ve.value.x)/ve.value.zoom,(R-ve.value.y)/ve.value.zoom]}function Ct(){n.nodesDraggable.value=!1,n.panOnDrag.value=!1}function Dt(){n.nodesDraggable.value=!0,n.panOnDrag.value=!0}async function it(k,R,M){if(!M)return!1;const V=document.getElementById("cl-flow").getElementsByClassName("vue-flow__node");if(k=="open")for(let G=0;G<V.length;G++)V[G].classList.add("vue-flow__node-animation");const U=_(M);let J=R.dimensions.width-300;if(await qe(130),k=="open"&&(J=R.dimensions.width-300),U.forEach(G=>{const{position:me}=G,_e=k=="open"?me.x+J:me.x-J;t(G.id,{position:{x:_e,y:me.y}})}),await qe(130),k=="close")for(let G=0;G<V.length;G++)V[G].classList.remove("vue-flow__node-animation")}async function Mt(){var xe,je;if(!((xe=Ae.value)!=null&&xe.id))return!1;const{nodes:k,edges:R,viewport:M}=n.toObject(),{nodes:j,edges:V}=st(k,R),U=Ne(Ae.value);delete U.id,delete U.createTime,delete U.updateTime,delete U.releaseTime,delete U.draft;const J={...U,draft:{nodes:j,edges:V,viewport:M}},G=JSON.stringify(J,null,2),me=new Blob([G],{type:"application/json"}),_e=URL.createObjectURL(me),be=document.createElement("a");be.setAttribute("href",_e),be.setAttribute("download",`${((je=Ae.value)==null?void 0:je.name)||"flow"}.json`),be.click(),URL.revokeObjectURL(_e),ue.success("导出成功")}const Ye={CustomNodes:Ee,nodes:o,node:u,addNode:v,removeNodes:g,copyNode:H,getClipboardNode:te,insertNode:i,setNode:A,findNode:f,findNodeByType:h,parentNodes:s,parentAllNodes:x,childrenNodes:c,childrenAllNodes:_,leafNodes:p,getConnectedNodes:C,clearNode:m,updateNode:t,edges:y,addEdge:D,findEdge:z,updateEdge:X,activeEdge:F,removeEdges:ee,removeEdgeByNodeId:oe,isRun:L,clear:B,zoom:he,setZoom:Ce,controlMode:Re,setControlMode:le,viewport:ve,setViewport:ye,setViewportByNode:P,setViewportByNodeId:Te,arrange:De,init:ot,info:Ae,get:St,save:Rt,restore:rt,getGroup:Tt,viewPx:It,offset:Me,disabledDrag:Ct,enableDrag:Dt,updateChildrenPosition:it,exportFlow:Mt};return["addNodes","updateNode","removeNodes","addEdge","updateEdge","removeEdges","clear","arrange"].forEach(k=>{const R=Ye[k];Ye[k]=(...M)=>{const j=R(...M);return l.emit(`flow.${k}`,j),j}}),Ye})()},js=I({name:"undefined"}),Es=I({...js,name:"tools-icon",props:{name:String,size:{type:Number,default:20},color:String},setup(n){return(l,e)=>{const a=S("cl-svg");return d(),w("div",{class:ce(["tools-icon",[`is-${n.name}`]]),style:Se({height:n.size+"px",width:n.size+"px",backgroundColor:n.color})},[r(a,{name:"flow-"+n.name},null,8,["name"])],6)}}}),We=Y(Es,[["__scopeId","data-v-090f81f7"]]);function $s(){const{user:n}=Et();let l=null;async function e(o,y,u){const A=!!(u!=null&&u.isStream);let m="";return l=new AbortController,new Promise((v,i)=>{const t=u!=null&&u.isDebug?"/admin/flow/run/debug":"/open/code/gen/data";fetch($t.baseUrl+t,{method:"POST",headers:{Authorization:n.token,"Content-Type":"application/json"},body:JSON.stringify({params:y,label:o,stream:A,nodeId:u==null?void 0:u.nodeId,requestId:u==null?void 0:u.requestId,sessionId:u==null?void 0:u.sessionId}),signal:l==null?void 0:l.signal}).then(g=>{if(g.body)if(A){const f=g.body.getReader(),h=new TextDecoder("utf-8"),p=new ReadableStream({start(s){function x(){f.read().then(({done:c,value:_})=>{if(c){s.close();return}let C=h.decode(_,{stream:!0});if(u!=null&&u.streamCb){m&&(C=m+C),C.indexOf("data:")==0&&(C=`

`+C);try{C.split(/\n\ndata:/g).filter(Boolean).map(D=>JSON.parse(D)).forEach(u==null?void 0:u.streamCb),m=""}catch{m=C}}s.enqueue(C),x()})}x()}});return new Response(p)}else return g.json()}).then(g=>{if(A)return g;g.code==1e3?v(g.data.result):i(g)}).catch(i)})}function a(){l&&(l.abort(),l=null)}return{invokeFlow:e,cancelFlow:a}}const Ps={key:0,class:"tools-panel"},Os={class:"tools-panel__head"},Vs={class:"label"},Ns={key:0},Ls={class:"btns"},Fs={class:"tools-panel__container"},qs={class:"tabs-op"},Bs={class:"tab-item is-chat"},Us={class:"chat-container"},Hs={class:"scrollbar"},zs={class:"list"},Ws={class:"inner"},Ys={key:0,class:"desc"},Gs={key:0,class:"tool"},Ks={key:1,class:"think"},Xs={key:1,class:"content"},Js={key:0},Qs={class:"item is-left"},Zs={class:"inner !w-auto h-[41px] flex items-center justify-center"},er={class:"p-form-head"},tr={class:"p-form-inner"},nr={key:0,class:"p-form-item"},ar={class:"chat-footer"},or={class:"inner"},sr={class:"tab-item is-detail"},rr={class:"top"},ir={class:"item"},lr={class:"status"},cr={class:"item"},dr={class:"item"},ur={class:"code"},yr={class:"code"},pr={key:0,class:"list"},mr=["onClick"],fr={class:"name"},gr={class:"duration"},hr={key:0,class:"error"},vr={class:"desc"},_r={key:0,class:"code"},br={key:1,class:"code"},xr=I({name:"undefined"}),wr=I({...xr,name:"tools-panel-run",setup(n,{expose:l}){const{mitt:e,refs:a,setRefs:o,service:y}=re(),u=de(),A=$s(),m=ae(!1);function v(c){m.value=!0,p.tab="chat",p.node=c||null,s.showParams=!0,s.isStream=!0,setTimeout(()=>{a["chat.input"].focus()},300)}function i(){m.value=!1,s.stop(),e.emit("flow.runClear")}const t=pe({}),g=Z(()=>{var _;const c=p.node||u.findNodeByType("start");return(((_=c==null?void 0:c.data)==null?void 0:_.inputParams)||[]).map(C=>(s.contentId||(C.type=="text"||C.type=="string")&&(s.contentId=C.field),{...C,label:C.label||C.field,type:C.type||"text"}))});function f(c){c.field==s.contentId&&(s.content=t[c.field])}const h=pe({list:[],input:{},output:{},get(c){y.flow.result.list({requestId:c}).then(_=>{var C,$;h.list=Be(_,"id","asc").map(D=>{var z,X,ee,oe;D._input=D.input;for(const F in(z=D.output)==null?void 0:z.result)["_events","_readableState"].some(L=>{var N;return tt((N=D.output)==null?void 0:N.result[F]).includes(L)})&&(D.output.result[F]="LLM/stream");return D._output=(X=D.output)==null?void 0:X.result,D._success=!!((ee=D.output)!=null&&ee.success),D._error=(oe=D.output)==null?void 0:oe.error,D}),h.input=(C=an(h.list))==null?void 0:C._input,h.output=($=Je(h.list))==null?void 0:$._output})},clear(){h.list=[],h.input={},h.output={}},expand(c){c._expand=!c._expand}}),p=pe({tab:"input",node:null,status:"none",count:{duration:0,tokenUsage:0},cacheText:"",emit(c,_){e.emit("flow.run",{action:c,data:_,node:p.node})},clear(){for(const c in t)g.value.find(C=>C.field==c)||delete t[c];p.status="none",p.count.tokenUsage=0,p.count.duration=0,h.clear()},checkNode(c){if(p.emit("check"),p.node)return!0;let _=!0;const C=u.findNodeByType("start"),$=[C,...u.childrenAllNodes(C.id)];return $.find(D=>{var X,ee,oe;if(((X=D.handle)==null?void 0:X.source)===!1&&!((ee=D.handle)!=null&&ee.next))return!1;(((oe=D.handle)==null?void 0:oe.next)||[{label:D.label,value:"source"}]).find(F=>{if(!u.edges.find(N=>N.source==D.id&&N.sourceHandle==F.value))return _=!1,p.emit("error",{nodeId:D.id,message:`检测失败：“${F.label}”需要添加一个结束节点`}),!0})}),_&&(_=!$.find(D=>{if(D.validator){const z=D.validator(D.data);if(on(z)){const X=`检测异常：${z}`;return p.emit("error",{nodeId:D.id,message:X}),!0}}})),c&&c(_),_},checkInput(c){const _=c=="chat"||p.tab=="chat",C=g.value.find($=>{if($.required){if(_&&s.contentId==$.field)return!1;let D=t[$.field];if($.type=="text"&&!D||$.type=="number"&&(D=Number(D),isNaN(D))||$.type=="image"&&!D)return!0}});return C?(ue.error(`请填写${C.label}`),s.showParams=!0,!1):!0},async run(c){var C;if(s.running)return ue.warning("运行中，请稍后再试");if(!p.checkInput()||!p.checkNode())return!1;c==null||c(),p.clear(),u.clearNode(),e.emit("flow.closeForm"),await u.save(),p.status="running";const _=Ge();A.invokeFlow(u.info.label,t,{isDebug:!0,nodeId:(C=p.node)==null?void 0:C.id,requestId:_,sessionId:s.sessionId,isStream:!0,streamCb:$=>{const{status:D,result:z,nodeId:X,reason:ee,duration:oe,count:F}=$.data;D=="running"&&p.emit("start",$),z!=null&&z.error?p.emit("error",{nodeId:X,message:z==null?void 0:z.error}):(D=="done"&&p.emit("done",$),s.onData($)),$.msgType=="flow"&&D=="end"&&(p.status=ee,p.count.duration=oe,p.count.tokenUsage=F.tokenUsage,p.emit("end"),s.done(),h.get(_))}})},cancel(){p.status="cancel",A.cancelFlow()},getDuration(c=0){return(c/1e3).toFixed(2)+"s"}}),s=pe({sessionId:Ge(),content:"",contentId:"",isStream:!1,loading:!1,running:!1,showParams:!1,list:[],open(){p.tab="chat",setTimeout(()=>{a["chat.input"].focus()},300)},new(){if(s.running)return ue.warning("运行中，请稍后再试");s.list=[],s.sessionId=Ge()},stop(){A.cancelFlow(),s.done(),p.cancel()},done(){s.list.forEach(c=>{c.isEnd=!0}),s.running=!1,s.loading=!1},clear(){s.content="",s.list=[],s.running=!1,s.loading=!1},send(){const c=s.content;if(!c)return a["chat.input"].focus(),ue.warning("请输入内容");p.run(()=>{s.showParams=!1,s.content&&(s.content=""),s.list.push({content:c,isMy:!0,isShow:!0}),s.loading=!0,s.running=!0,t[s.contentId]=c,x.clear(),x.toBottom()})},_isOutput:!1,onData({msgType:c,data:_}){const{isEnd:C,content:$,isThinking:D,name:z,type:X,nodeId:ee,nodeType:oe,status:F,result:L}=_,N=sn(L==null?void 0:L.result)?"```json\n"+JSON.stringify(L==null?void 0:L.result,null,4)+"\n```":String((L==null?void 0:L.result)||"null");c=="flow"&&F=="start"&&(s._isOutput=!1);let B=s.list.find(H=>{var te;return(H.nodeId==ee||H.nodeId==((te=p.node)==null?void 0:te.id))&&!H.isEnd&&!H.isMy});if(!B){const H=()=>{var te;B={content:"",isMy:!1,isEnd:!1,isShow:!1,nodeId:ee||((te=p.node)==null?void 0:te.id)},s.list.push(B)};p.node?c=="node"&&F=="running"&&H():((F=="running"&&oe=="llm"||X=="start"&&c=="tool")&&H(),c=="llmStream"&&H())}if(B){B.desc||(B.desc=[]),B._content||(B._content="");let H=Je(B.desc);c=="tool"?((!H||(H==null?void 0:H.type)!=="tool")&&B.desc.push(H={}),H.type="tool",H.content=z,H.loading=X=="start"):$!==void 0&&(D?((!H||(H==null?void 0:H.type)!="think")&&B.desc.push(H={content:""}),H.type="think",H.content+=$):B._content+=$),$&&(s._isOutput||x.clear(),s._isOutput=!0),(s.isStream||C)&&(B.content=B._content,B.content&&(B.isShow=!0)),($&&s.isStream||!Q(H))&&(B.isShow=!0,s.loading=!1),B.isEnd=C,p.node&&F=="end"&&(B.content||(B.content=N,B.isEnd=!0,B.isShow=!0))}!p.node&&c=="flow"&&F=="end"&&(s._isOutput||(s.list.push({content:N,isMy:!1,isEnd:!0,isShow:!0}),x.toBottom(!1))),x.isAuto&&x.toBottom(!1)},onKeyDown(c){if(c.ctrlKey&&c.key==="Enter"){s.content+=`
`;return}else c.key==="Enter"&&(c.preventDefault(),s.send())}}),x=pe({top:0,isAuto:!0,toBottom(c=!0){Ze(()=>{var _;(_=a["chat.scrollbar"])==null||_.scrollTo({top:99999,behavior:c?"smooth":"auto"})})},onScroll(c){c.scrollTop>=x.top?x.top=c.scrollTop:x.isAuto=!1},clear(){x.top=0,x.isAuto=!0}});return ge(()=>{e.on("flow.runOpen",v),e.on("flow.runClose",i),e.on("flow.runCheck",p.checkNode)}),Fe(()=>{e.off("flow.runOpen",v),e.off("flow.runClose",i),e.off("flow.runCheck",p.checkNode)}),l({open:v,close:i}),(c,_)=>{var ye;const C=S("cl-svg"),$=S("el-tooltip"),D=S("el-icon"),z=S("cl-preview-md"),X=S("el-scrollbar"),ee=S("cl-select"),oe=S("el-form-item"),F=S("el-col"),L=S("cl-switch"),N=S("el-row"),B=S("el-input"),H=S("el-input-number"),te=S("cl-upload"),he=S("el-form"),Ce=S("el-button"),Re=S("el-tab-pane"),le=S("cl-code-json"),ve=S("el-tabs");return m.value?(d(),w("div",Ps,[b("div",Os,[b("span",Vs,[_[9]||(_[9]=se(" 流程运行 ")),p.node?(d(),w("span",Ns,"（"+q((ye=p.node)==null?void 0:ye.label)+"）",1)):O("",!0)]),b("div",Ls,[r(C,{class:"cl-flow__btn-icon is-bg",name:"flow-close",onClick:i})])]),b("div",Fs,[b("div",qs,[p.tab=="chat"?(d(),w(K,{key:0},[r($,{content:"新对话"},{default:T(()=>[r(C,{name:"plus",class:"cl-flow__btn-icon is-bg",onClick:_[0]||(_[0]=P=>s.new())})]),_:1}),r($,{content:"设置"},{default:T(()=>[r(C,{name:"flow-more",class:ce(["cl-flow__btn-icon is-bg",{"is-active":s.showParams}]),onClick:_[1]||(_[1]=P=>s.showParams=!s.showParams)},null,8,["class"])]),_:1})],64)):O("",!0)]),r(ve,{modelValue:p.tab,"onUpdate:modelValue":_[8]||(_[8]=P=>p.tab=P)},{default:T(()=>[r(Re,{label:"对话",name:"chat"},{default:T(()=>[b("div",Bs,[b("div",Us,[b("div",Hs,[r(X,{ref:E(o)("chat.scrollbar"),onScroll:x.onScroll},{default:T(()=>[b("div",zs,[(d(!0),w(K,null,ne(s.list,(P,Te)=>(d(),w(K,{key:Te},[P.isShow?(d(),w("div",{key:0,class:ce(["item",[P.isMy?"is-right":"is-left"]])},[b("div",Ws,[E(Q)(P.desc)?O("",!0):(d(),w("div",Ys,[(d(!0),w(K,null,ne(P.desc,(ie,De)=>(d(),w(K,{key:De},[ie.type=="tool"?(d(),w("div",Gs,[se(q(ie.content)+" ",1),ie.loading?(d(),W(D,{key:0,class:"is-loading"},{default:T(()=>[r(E(Xe))]),_:1})):O("",!0)])):O("",!0),ie.type=="think"?(d(),w("span",Ks,q(ie.content),1)):O("",!0)],64))),128))])),P.content?(d(),w("div",Xs,[P.isMy?(d(),w("span",Js,q(P.content),1)):(d(),W(z,{key:1,content:P.content},null,8,["content"]))])):O("",!0)])],2)):O("",!0)],64))),128)),Pe(b("div",Qs,[b("div",Zs,[r(D,{class:"is-loading text-[14px]"},{default:T(()=>[r(E(Xe))]),_:1})])],512),[[$e,s.loading]])])]),_:1},8,["onScroll"])]),b("div",{class:ce(["p-form",{"is-open":s.showParams}])},[b("div",er,[_[10]||(_[10]=b("span",{class:"t"},"对话参数设置",-1)),r(C,{name:"close",class:"cl-flow__btn-icon is-bg",onClick:_[2]||(_[2]=P=>s.showParams=!1)})]),r(X,{"max-height":"calc(50vh - 54px)"},{default:T(()=>[b("div",tr,[r(he,{"label-position":"top","require-asterisk-position":"right",model:t},{default:T(()=>[r(N,{gutter:20},{default:T(()=>[r(F,{span:12},{default:T(()=>[r(oe,{label:"对话字段"},{default:T(()=>[r(ee,{modelValue:s.contentId,"onUpdate:modelValue":_[3]||(_[3]=P=>s.contentId=P),options:g.value.filter(P=>P.type=="text"||P.type=="string").map(P=>({label:P.label,value:P.field}))},null,8,["modelValue","options"])]),_:1})]),_:1}),r(F,{span:12},{default:T(()=>[r(oe,{label:"流式输出"},{default:T(()=>[r(L,{modelValue:s.isStream,"onUpdate:modelValue":_[4]||(_[4]=P=>s.isStream=P)},null,8,["modelValue"])]),_:1})]),_:1})]),_:1}),(d(!0),w(K,null,ne(g.value,(P,Te)=>(d(),w(K,{key:Te},[P.field!=s.contentId?(d(),w("div",nr,[r(oe,{label:`${P.label}（${P.field}）`,required:!!P.required,prop:P.field,rules:{required:P.required,message:`${P.label}不能为空`}},{default:T(()=>[P.type=="text"||P.type=="string"?(d(),W(B,{key:0,modelValue:t[P.field],"onUpdate:modelValue":ie=>t[P.field]=ie,clearable:"",placeholder:"请输入",onInput:ie=>f(P)},null,8,["modelValue","onUpdate:modelValue","onInput"])):P.type=="number"?(d(),W(H,{key:1,modelValue:t[P.field],"onUpdate:modelValue":ie=>t[P.field]=ie,placeholder:"请输入"},null,8,["modelValue","onUpdate:modelValue"])):P.type=="image"?(d(),W(te,{key:2,modelValue:t[P.field],"onUpdate:modelValue":ie=>t[P.field]=ie,clearable:"",size:70,small:"",multiple:""},null,8,["modelValue","onUpdate:modelValue"])):P.type=="file"?(d(),W(te,{key:3,modelValue:t[P.field],"onUpdate:modelValue":ie=>t[P.field]=ie,multiple:"",type:"file",accept:".txt, .pdf, .md, .csv,.docx, .pptx","limit-size":15},null,8,["modelValue","onUpdate:modelValue"])):O("",!0)]),_:2},1032,["label","required","prop","rules"])])):O("",!0)],64))),128))]),_:1},8,["model"])])]),_:1})],2)]),b("div",ar,[b("div",or,[r(B,{ref:E(o)("chat.input"),modelValue:s.content,"onUpdate:modelValue":_[5]||(_[5]=P=>s.content=P),type:"textarea",autosize:{minRows:1,maxRows:5},placeholder:"请输入您的问题",onKeydown:Ut(s.onKeyDown,["enter"])},null,8,["modelValue","onKeydown"]),s.running?(d(),W(Ce,{key:0,class:"send",onClick:_[6]||(_[6]=P=>s.stop())},{default:T(()=>_[11]||(_[11]=[se(" 停止 ")])),_:1,__:[11]})):(d(),W(Ce,{key:1,class:"send",type:"success",loading:s.running,onClick:_[7]||(_[7]=P=>s.send())},{default:T(()=>_[12]||(_[12]=[se(" 发送 ")])),_:1,__:[12]},8,["loading"]))])])])]),_:1}),r(Re,{label:"日志",name:"detail"},{default:T(()=>[r(X,null,{default:T(()=>[b("div",sr,[b("div",{class:ce(["info",[`is-${p.status}`]])},[b("div",rr,[b("div",ir,[_[13]||(_[13]=b("p",null,"状态",-1)),b("p",lr,q(p.status),1)]),b("div",cr,[_[14]||(_[14]=b("p",null,"运行时间",-1)),b("p",null,q(p.getDuration(p.count.duration)),1)]),b("div",dr,[_[15]||(_[15]=b("p",null,"消耗 token 数",-1)),b("p",null,q(p.count.tokenUsage||0)+" Tokens",1)])])],2),_[17]||(_[17]=b("p",{class:"label"},"参数",-1)),b("div",ur,[r(le,{content:h.input,title:"输入"},null,8,["content"])]),b("div",yr,[r(le,{content:h.output,title:"输出"},null,8,["content"])]),E(Q)(h.list)?O("",!0):(d(),w("div",pr,[_[16]||(_[16]=b("p",{class:"label"},"节点",-1)),(d(!0),w(K,null,ne(h.list,(P,Te)=>{var ie,De;return d(),w("div",{class:ce(["item",[P._success?"is-success":"is-error"]]),key:Te},[b("div",{class:"inner",onClick:ot=>h.expand(P)},[r(We,{name:(ie=P.node)==null?void 0:ie.type},null,8,["name"]),b("span",fr,q((De=P.node)==null?void 0:De.label),1),b("span",gr,"耗时："+q(p.getDuration(P.duration)),1)],8,mr),P._error?(d(),w("p",hr,q(P._error),1)):O("",!0),Pe(b("div",vr,[P.nodeType!="end"?(d(),w("div",_r,[r(le,{content:P._input,title:"输入"},null,8,["content"])])):O("",!0),P.nodeType!="start"?(d(),w("div",br,[r(le,{content:P._output,title:"输出"},null,8,["content"])])):O("",!0)],512),[[$e,P._expand]])],2)}),128))]))])]),_:1})]),_:1})]),_:1},8,["modelValue"])])])):O("",!0)}}}),kr=Y(wr,[["__scopeId","data-v-5075729b"]]),Ar={class:"tools-panel__head"},Sr={class:"btns"},Rr={class:"desc"},Tr={class:"tools-panel__container"},Ir=I({name:"undefined"}),Cr=I({...Ir,name:"tools-card-form",setup(n){const{mitt:l}=re(),e=nt(),a=de(),o=ae(),y=Z(()=>a.findNode(o.value)),u=ae(!1),A=Z(()=>{var g,f;return((f=(g=y.value)==null?void 0:g.form)==null?void 0:f.width)||"400px"});function m(g){o.value=g,u.value=!0,Ze(()=>{var p,s,x,c;const{focus:f,items:h=[]}=((p=y.value)==null?void 0:p.form)||{};(c=e.value)==null||c.open({props:{labelPosition:"top"},form:((s=y.value)==null?void 0:s.data)||{},items:h,op:{hidden:!0}},[ft.Form.setFocus(f||((x=h==null?void 0:h[0])==null?void 0:x.prop))])})}function v(){var g;u.value=!1,o.value==((g=a.node)==null?void 0:g.id)&&a.clearNode(),a.enableDrag()}function i(g){var f;Ve((f=e.value)==null?void 0:f.form,g)}function t(){l.emit("flow.runOpen",a.node)}return ge(()=>{Ie(()=>a.nodes.length,()=>{y.value&&(a.findNode(y.value.id)||v())}),Ie(()=>{var g;return(g=e.value)==null?void 0:g.form},g=>{var h,p;const f=Ne(g);(h=e.value)==null||h.invokeData(f),Ve((p=y.value)==null?void 0:p.data,f)},{deep:!0}),l.on("flow.updateForm",i),l.on("flow.openForm",m),l.on("flow.closeForm",v),l.on("flow.run",v)}),Fe(()=>{l.off("flow.updateForm",i),l.off("flow.openForm",m),l.off("flow.closeForm",v),l.off("flow.run",v)}),(g,f)=>{var c,_;const h=S("el-input"),p=S("cl-svg"),s=S("cl-form"),x=S("el-scrollbar");return u.value&&y.value?(d(),w("div",{key:0,class:"tools-panel",style:Se({width:A.value})},[b("div",Ar,[r(We,{name:(c=y.value)==null?void 0:c.icon,color:(_=y.value)==null?void 0:_.color},null,8,["name","color"]),r(h,{modelValue:y.value.label,"onUpdate:modelValue":f[0]||(f[0]=C=>y.value.label=C)},null,8,["modelValue"]),b("div",Sr,[E(a).isRun(y.value)?(d(),W(p,{key:0,name:"flow-node-run",class:"cl-flow__btn-icon is-bg",onClick:t})):O("",!0),r(p,{name:"flow-close",class:"cl-flow__btn-icon is-bg",onClick:v})])]),b("div",Rr,[r(h,{modelValue:y.value.description,"onUpdate:modelValue":f[1]||(f[1]=C=>y.value.description=C)},null,8,["modelValue"])]),b("div",Tr,[r(x,null,{default:T(()=>[r(s,{inner:"",ref_key:"Form",ref:e},null,512)]),_:1})])],4)):O("",!0)}}}),Dr=Y(Cr,[["__scopeId","data-v-7c1d82d3"]]),Mr=I({name:"undefined"}),jr=I({...Mr,name:"tools-panel",setup(n){return(l,e)=>(d(),W(E(Ot),{position:"top-right",class:"tools-panel-right"},{default:T(()=>[r(Dr),r(kr)]),_:1}))}}),Er={class:"tools-more"},$r={class:"list"},Pr=["onClick"],Or={class:"label"},Vr={key:0,class:"desc"},Nr=I({name:"undefined"}),Lr=I({...Nr,name:"tools-more",props:{node:{type:Object,default:()=>({})}},setup(n){const l=n,{refs:e,setRefs:a}=re(),o=de(),y=[{label:"克隆",value:"clone"},{label:"复制",value:"copy"},{label:"删除",value:"remove",desc:"Del",hidden:["start","end"].includes(l.node.type)}];function u(A){const m=Ne(l.node);switch(A){case"clone":const{x:v=0,y:i=0}=m.position||{};o.addNode(m.type,{...m,position:{x:v+340,y:i}});break;case"copy":o.copyNode(m);break;case"remove":o.removeNodes(m);break}e.popover.hide()}return(A,m)=>{const v=S("el-popover");return d(),W(v,{ref:E(a)("popover"),trigger:"click",width:"200px",placement:"bottom-start","popper-class":"cl-flow__popper",offset:5},{reference:T(()=>[Wt(A.$slots,"default",{},void 0,!0)]),default:T(()=>[b("div",Er,[b("div",$r,[(d(),w(K,null,ne(y,(i,t)=>(d(),w(K,{key:t},[i.hidden?O("",!0):(d(),w("div",{key:0,class:"item",onClick:g=>u(i.value)},[b("span",Or,q(i.label),1),i.desc?(d(),w("span",Vr,q(i.desc),1)):O("",!0)],8,Pr))],64))),64))])])]),_:3},512)}}}),Fr=Y(Lr,[["__scopeId","data-v-e1927f04"]]),qr={class:"head"},Br={class:"desc"},Ur={class:"container"},Hr={key:2,class:"tips"},zr=I({name:"undefined"}),Wr=I({...zr,name:"tools-card",props:{nodeId:String},setup(n){const l=n,{mitt:e}=re(),a=de(),o=Z(()=>a.findNode(l.nodeId)),y=Z(()=>{var h;return!["start","end"].includes((h=o.value)==null?void 0:h.type)}),u=Z(()=>{var h;return((h=o.value)==null?void 0:h.type)=="start"}),A=Z(()=>{var h;return l.nodeId==((h=a.node)==null?void 0:h.id)});function m(){var h;return(h=a.CustomNodes.find(p=>{var s;return p.type==((s=o.value)==null?void 0:s.type)}))==null?void 0:h.component}function v(){e.emit("flow.openForm",l.nodeId)}function i(){e.emit("flow.runOpen",o.value)}function t(){a.removeNodes(o.value)}function g(h){return getComputedStyle(document.documentElement).getPropertyValue(`--el-color-${h}`)}const f=pe({status:"none",message:"",clear(){f.status="none",f.message="",f.updateEdge({animated:!1,style:{}})},check(){f.clear()},start(h,p){var x;const s=(p==null?void 0:p.id)||((x=h.data)==null?void 0:x.nodeId);s==l.nodeId&&(a.setViewportByNodeId(s),f.status="running",f.message="运行中...")},error({nodeId:h,message:p}){l.nodeId==h&&(ue.error(p),f.status="error",f.message=p,a.setViewportByNodeId(h))},end(){["waiting","running"].includes(f.status)&&f.close()},done(h,p){var x,c,_,C;if(((p==null?void 0:p.id)||((x=h.data)==null?void 0:x.nodeId))==l.nodeId){if(!h.data)return;if((c=h.data)!=null&&c.result){const{success:$,error:D}=(_=h.data)==null?void 0:_.result;if($){const z=parseFloat(((h.data.duration||1)/1e3).toFixed(3));f.status="success",f.message=`运行成功，耗时：${z}s`}else f.status="error",f.message=D||"运行失败";p||f.updateEdge({animated:!0,style:{stroke:g($?"success":"danger")}},(C=h.data)==null?void 0:C.nextNodeIds)}}},close(){f.clear()},updateEdge(h,p=[]){a.edges.forEach(s=>{s.source==l.nodeId&&(Q(p)||p.includes(s.target))&&a.updateEdge(s.id,h)})},onRun({action:h,data:p,node:s}){f[h](p,s)}});return ge(()=>{e.on("flow.run",f.onRun),e.on("flow.runClear",f.close)}),Fe(()=>{e.off("flow.run",f.onRun),e.off("flow.runClear",f.close)}),(h,p)=>{var _,C,$,D,z,X,ee,oe,F;const s=S("cl-svg"),x=S("el-tooltip"),c=S("el-icon");return d(),w("div",{class:ce(["tools-card",[`is-${f.status}`,{"is-active":A.value}]]),onKeydown:p[1]||(p[1]=we(()=>{},["stop"])),onClick:v},[((C=(_=o.value)==null?void 0:_.handle)==null?void 0:C.source)??!0?(d(),W(Le,{key:0,type:"source",id:"source","node-id":n.nodeId,position:{right:"-9px",top:"14px"}},null,8,["node-id"])):O("",!0),((D=($=o.value)==null?void 0:$.handle)==null?void 0:D.target)??!0?(d(),W(Le,{key:1,type:"target",id:"target","node-id":n.nodeId,position:{left:"-9px",top:"14px"}},null,8,["node-id"])):O("",!0),b("div",qr,[r(We,{name:(z=o.value)==null?void 0:z.icon,color:(X=o.value)==null?void 0:X.color},null,8,["name","color"]),b("span",null,q((ee=o.value)==null?void 0:ee.label),1),b("div",{class:"btns",onClick:p[0]||(p[0]=we(()=>{},["stop"]))},[u.value?O("",!0):(d(),w(K,{key:0},[E(a).isRun(o.value)?(d(),W(x,{key:0,content:"调试",placement:"top"},{default:T(()=>[r(s,{class:"cl-flow__btn-icon",name:"flow-node-run",onClick:i})]),_:1})):O("",!0),y.value?(d(),W(x,{key:1,content:"删除",placement:"top"},{default:T(()=>[r(s,{name:"flow-node-delete",class:"cl-flow__btn-icon",onClick:t})]),_:1})):O("",!0)],64)),r(Fr,{node:o.value},{default:T(()=>[b("div",null,[r(s,{name:"flow-node-more",class:"cl-flow__btn-icon"})])]),_:1},8,["node"])])]),b("div",Br,q(((oe=o.value)==null?void 0:oe.desc)||((F=o.value)==null?void 0:F.description)),1),b("div",Ur,[(d(),W(Yt(m()),{node:o.value},null,8,["node"]))]),f.status!=="none"?(d(),w("div",Hr,[f.status=="running"?(d(),W(c,{key:0,class:"is-loading"},{default:T(()=>[r(E(Xe))]),_:1})):O("",!0),b("span",null,q(f.message),1)])):O("",!0)],34)}}}),Yr=Y(Wr,[["__scopeId","data-v-a170d48c"]]),Gr=I({name:"undefined"}),Kr=I({...Gr,name:"tools-edge-button",props:{id:{type:String,required:!0},sourceX:{type:Number,required:!0},sourceY:{type:Number,required:!0},targetX:{type:Number,required:!0},targetY:{type:Number,required:!0},sourcePosition:{type:String,required:!0},targetPosition:{type:String,required:!0},markerEnd:{type:String,required:!1},style:{type:Object,required:!1},data:Object},setup(n){const l=n,e=de(),a=Z(()=>Vt(l));function o(){const y=e.findEdge(l.id);y&&e.removeEdges(y)}return(y,u)=>{const A=S("el-icon");return d(),w(K,null,[r(E(Nt),{id:n.id,style:Se(n.style),path:a.value[0],"marker-end":n.markerEnd},null,8,["id","style","path","marker-end"]),r(E(Lt),null,{default:T(()=>{var m;return[b("div",{style:Se({height:"16px",width:"16px",pointerEvents:"all",position:"absolute",transform:`translate(-50%, -50%) translate(${a.value[1]}px,${a.value[2]}px)`}),class:"nodrag nopan"},[r(A,{class:ce(["icon",{show:(m=n.data)==null?void 0:m.show}]),onClick:o},{default:T(()=>[r(E(Qt))]),_:1},8,["class"])],4)]}),_:1})],64)}}}),Xr=Y(Kr,[["__scopeId","data-v-99109b8f"]]),Jr={class:"tools-history"},Qr=I({name:"undefined"}),Zr=I({...Qr,name:"tools-history",setup(n){const{mitt:l}=re(),e=de(),a=ae([]),o=ae(0),y=Z(()=>o.value>0),u=Z(()=>o.value<a.value.length-1);function A(){y.value&&(o.value-=1,i())}function m(){u.value&&(o.value+=1,i())}let v=!1;async function i(){if(v)return!1;const f=a.value[o.value];f&&(v=!0,await e.restore(f),await qe(300),v=!1)}const t=bt(()=>{if(v)return!1;a.value.splice(o.value+1,a.value.length,Ne({nodes:e.nodes,edges:e.edges,viewport:e.viewport})),o.value=a.value.length-1},300),g=["addNodes","updateNode","removeNodes","addEdge","removeEdges","clear","arrange"];return ge(()=>{t(),g.forEach(f=>{l.on(`flow.${f}`,t)})}),Fe(()=>{g.forEach(f=>{l.off(`flow.${f}`,t)})}),(f,h)=>{const p=S("cl-svg"),s=S("el-tooltip");return d(),w("div",Jr,[r(s,{content:"上一步"},{default:T(()=>[r(p,{name:"flow-prev",class:ce({disabled:!y.value}),onClick:A},null,8,["class"])]),_:1}),r(s,{content:"下一步"},{default:T(()=>[r(p,{name:"flow-next",class:ce({disabled:!u.value}),onClick:m},null,8,["class"])]),_:1})])}}}),ei=Y(Zr,[["__scopeId","data-v-f213899b"]]),ti={class:"search"},ni={key:0,class:"label"},ai={class:"list"},oi=["id","data-type","onMousedown"],si={class:"det"},ri=I({name:"undefined"}),ii=I({...ri,name:"tools-node-add",props:{node:{type:Object,default:()=>({})}},emits:["select","hide"],setup(n,{emit:l}){const e=de(),a=ae(""),o=ae(!1),y=Z(()=>e.getGroup(a.value)),u=pe({startX:0,startY:0,el:null});function A(i,t){var f;const g=document.getElementById(`cl-flow__tools-node-add--${t.type}`);if(g){const h=g.getBoundingClientRect();((f=document.querySelector(".cl-flow .tools-node-add"))==null?void 0:f.getBoundingClientRect())&&h&&(u.startX=i.pageX-h.left,u.startY=i.pageY-h.top),u.el=g.cloneNode(!0),u.el.style.width="280px"}document.addEventListener("mousemove",m),document.addEventListener("mouseup",v)}function m(i){if(u.el){const t=document.querySelector(".cl-flow .vue-flow"),g=t.getBoundingClientRect();u.el.className.includes("is-drag")||(u.el.className+=" is-drag",t.appendChild(u.el)),u.el.style.left=`${i.pageX-g.left-u.startX}px`,u.el.style.top=`${i.pageY-g.top-u.startY}px`}}function v(i){if(u.el&&u.el.className.includes("is-drag")){const[t,g]=e.viewPx(parseInt(u.el.style.left),parseInt(u.el.style.top));e.addNode(u.el.dataset.type,{position:{x:t,y:g}}),u.el.remove(),o.value=!1}document.removeEventListener("mousemove",m),document.removeEventListener("mouseup",v)}return(i,t)=>{const g=S("el-button"),f=S("el-input"),h=S("el-empty"),p=S("el-scrollbar");return d(),w(K,null,[r(g,{class:"tools-node-add__btn",size:"small",type:"success",onClick:t[0]||(t[0]=s=>o.value=!o.value)},{default:T(()=>[se(q(o.value?"收起":"添加节点"),1)]),_:1}),b("div",{class:ce(["tools-node-add",{show:o.value}])},[b("div",ti,[r(f,{modelValue:a.value,"onUpdate:modelValue":t[1]||(t[1]=s=>a.value=s),placeholder:"搜索节点",clearable:"","prefix-icon":E(vt)},null,8,["modelValue","prefix-icon"])]),r(p,{height:"400px"},{default:T(()=>[(d(!0),w(K,null,ne(y.value,s=>(d(),w("div",{class:"group",key:s.label},[s.label?(d(),w("p",ni,q(s.label),1)):O("",!0),b("div",ai,[(d(!0),w(K,null,ne(s.children,x=>(d(),w("div",{class:"cl-flow__tools-node-add-item",id:`cl-flow__tools-node-add--${x.type}`,key:x.label,"data-type":x.type,onMousedown:c=>A(c,x)},[r(We,{name:x.icon,color:x.color,size:30},null,8,["name","color"]),b("div",si,[b("p",null,q(x.label),1),b("p",null,q(x.description),1)])],40,oi))),128))])]))),128)),E(Q)(y.value)?(d(),W(h,{key:0,description:"未找到匹配项","image-size":50})):O("",!0)]),_:1})],2)],64)}}}),li=Y(ii,[["__scopeId","data-v-5185e7a4"]]),ci={class:"tools-controls"},di={class:"zoom"},ui={class:"list"},yi=["onClick"],pi=I({name:"undefined"}),mi=I({...pi,name:"tools-controls",setup(n){const l=gt(),e=de(),{mitt:a}=re(),o=ae(!1),y=Z(()=>Math.ceil(e.viewport.zoom*100||100)),u=[{label:"默认",value:1},{label:"大",value:1.5},{label:"小",value:.5}];function A(){l.fitView()}function m(){e.arrange(),a.emit("flow.closeForm")}const v=Z(()=>e.controlMode);function i(t){e.setControlMode(t)}return(t,g)=>{const f=S("el-popover"),h=S("cl-svg"),p=S("el-tooltip");return d(),w("div",ci,[r(f,{trigger:"click",width:"100px",placement:"top-start","popper-class":"cl-flow__popper","popper-style":{minWidth:"100px",marginLeft:"-5px"},teleported:!1},{reference:T(()=>[b("span",di,q(y.value)+"%",1)]),default:T(()=>[b("div",ui,[(d(),w(K,null,ne(u,s=>b("div",{class:"item",key:s.value,onClick:x=>E(l).zoomTo(s.value)},q(s.label),9,yi)),64)),b("div",{class:"item",onClick:A},"自适应")])]),_:1}),g[3]||(g[3]=b("div",{class:"hr"},null,-1)),r(p,{content:"切换交互模式"},{default:T(()=>[v.value=="pointer"?(d(),W(h,{key:0,name:"flow-pointer",onClick:g[0]||(g[0]=we(s=>i("hand"),["stop"]))})):(d(),W(h,{key:1,name:"flow-hand",onClick:g[1]||(g[1]=we(s=>i("pointer"),["stop"]))}))]),_:1}),r(p,{content:"缩略图"},{default:T(()=>[r(h,{name:"flow-mini-map",onClick:g[2]||(g[2]=s=>o.value=!o.value)})]),_:1}),r(p,{content:"整理节点"},{default:T(()=>[r(h,{name:"flow-arrange",onClick:m})]),_:1}),r(ei),g[4]||(g[4]=b("div",{class:"mr-2"},null,-1)),r(li),Pe(r(E(mn),{position:"bottom-left",height:100,width:150},null,512),[[$e,o.value]])])}}}),fi=Y(mi,[["__scopeId","data-v-926c3f51"]]);function gi(n){if(!n)return"";const l=Qe(),e=Qe(n);let a=l.diff(e,"second");if(a<60)return a<0&&(a=0),`${a||1}秒前`;const o=l.diff(e,"minute");if(o<60)return`${o}分钟前`;const y=l.diff(e,"hour");return y<24?`${y}小时前`:l.isSame(e,"day")?`昨天 ${e.format("HH:mm")}`:e.format("YYYY-MM-DD HH:mm")}const hi={class:"tools-head"},vi={class:"info"},_i={class:"title"},bi={class:"desc"},xi={class:"op"},wi={class:"item"},ki={class:"publish"},Ai={class:"btn"},Si=["onClick"],Ri=I({name:"undefined"}),Ti=I({...Ri,name:"tools-head",setup(n){const{mitt:l,refs:e,setRefs:a,service:o}=re(),y=de();function u(){l.emit("flow.runOpen")}async function A(){await y.save(),ue.success("数据保存成功")}const m=pe({loading:!1,tips:"-",onShow(){const{releaseTime:i}=(y==null?void 0:y.info)||{};i?m.tips=`上次发布于${gi(i)}`:m.tips="当前未发布",l.emit("flow.runClose")},next(){var i;(i=e.publishPopover)==null||i.hide(),l.emit("flow.runCheck",async t=>{var g;t&&(ue.success("检测通过，发布中"),m.loading=!0,await y.save(),await o.flow.info.release({flowId:(g=y.info)==null?void 0:g.id}).then(()=>{ue.success("发布成功"),y.get()}).catch(f=>{ue.error(f.message)}),m.loading=!1)})}});function v(){Ue.confirm("是否要导出当前流程？","提示",{type:"success",confirmButtonText:"确认",cancelButtonText:"取消"}).then(()=>{y.exportFlow()}).catch(()=>null)}return(i,t)=>{var x,c,_,C;const g=S("cl-svg"),f=S("el-tooltip"),h=S("el-text"),p=S("el-button"),s=S("el-popover");return d(),w("div",hi,[b("div",vi,[b("div",_i,q((x=E(y).info)==null?void 0:x.name)+"（"+q((c=E(y).info)==null?void 0:c.label)+"）",1),b("div",bi,q((_=E(y).info)!=null&&_.updateTime?`已保存 ${E(Qe)((C=E(y).info)==null?void 0:C.updateTime).format("MM-DD HH:mm:ss")}`:"未保存"),1)]),b("div",xi,[b("div",{class:"item",onClick:t[0]||(t[0]=$=>A())},[r(f,{content:"保存",placement:"top"},{default:T(()=>[r(g,{name:"flow-save"})]),_:1})]),b("div",{class:"item",onClick:t[1]||(t[1]=$=>u())},[r(f,{content:"运行",placement:"top"},{default:T(()=>[r(g,{name:"flow-run"})]),_:1})]),r(s,{ref:E(a)("publishPopover"),trigger:"click",teleported:!1,offset:5,width:"220px","popper-class":"cl-flow__popper",placement:"bottom",onShow:m.onShow},{reference:T(()=>[b("div",wi,[r(f,{content:"发布",placement:"top"},{default:T(()=>[r(g,{name:"flow-publish"})]),_:1})])]),default:T(()=>[b("div",ki,[r(h,{size:"small",tag:"p"},{default:T(()=>[se(q(m.tips),1)]),_:1}),b("div",Ai,[r(p,{class:"a",type:"primary",onClick:m.next},{default:T(()=>t[3]||(t[3]=[se("发布")])),_:1,__:[3]},8,["onClick"])])])]),_:1},8,["onShow"]),r(fn,null,{default:T(({open:$})=>[b("div",{class:"item",onClick:D=>$()},[r(f,{content:"配置",placement:"top"},{default:T(()=>[r(g,{name:"flow-set2"})]),_:1})],8,Si)]),_:1}),b("div",{class:"item",onClick:t[2]||(t[2]=$=>v())},[r(f,{content:"导出",placement:"top"},{default:T(()=>[r(g,{name:"flow-export2"})]),_:1})])])])}}}),Ii=Y(Ti,[["__scopeId","data-v-88b91926"]]),Ci=I({name:"undefined"}),Di=I({...Ci,name:"tools-context-menu",setup(n,{expose:l}){const{mitt:e}=re(),a=de();let o;function y(){o==null||o()}async function u(m){var t;const v=await a.getClipboardNode(),{close:i}=(t=dt)==null?void 0:t.open(m,{list:[{label:"粘贴到这里",hidden:!v,callback(g){if(v){const{zoom:f,x:h,y:p}=a.viewport,s=a.addNode(v.type,{...v,position:{x:(m.layerX-h)/f,y:(m.layerY-p)/f}});a.setNode(s),a.setViewportByNode(s),g()}}},{label:"流程运行",callback(g){e.emit("flow.runOpen"),g()}},{label:"整理节点",callback(g){a.arrange(),g()}},{label:"清空节点",callback(g){Ue.confirm("请确认是否清空所有节点？","提示",{type:"warning"}).then(()=>{a.clear()}).catch(()=>null),g()}}]});o=i,m.stopPropagation(),m.preventDefault()}function A({event:m,node:v}){const i=m,t=[{label:"复制",suffixIcon:Zt,callback(f){a.copyNode(v),f(),ue.success("复制成功")}},{label:"删除",suffixIcon:en,callback(f){a.removeNodes(v),f()}}];if(["start","end"].includes(v.type)||Q(t.filter(f=>!f.hidden)))return;const{close:g}=dt.open(i,{class:"cl-flow__context-menu",list:t});o=g,i.stopPropagation(),i.preventDefault()}return l({onPane:u,onNode:A,close:y}),(m,v)=>(d(),w("div"))}}),Mi=I({name:"undefined"}),ji=I({...Mi,name:"tools-selection",setup(n){const l=de(),e=pe({show:!1,startX:0,startY:0,endX:0,endY:0,x:0,y:0,left:0,top:0,width:0,height:0}),a=pe({show:!1,left:0,top:0,width:0,height:0}),o=Z(()=>{const{x:t,y:g}=l.viewport;return{height:y(a.height)+"px",width:y(a.width)+"px",left:y(a.left)+t+"px",top:y(a.top)+g+"px"}});function y(t){const{zoom:g}=l.viewport;return t*g}function u(){e.show=!1,e.height=0,e.width=0,e.endX=0,e.endY=0,a.show=!1,a.height=0,a.width=0,i.clear()}function A(t){var f;u();const g=t.target;if(g.nodeName!="DIV"||!((f=g.className)!=null&&f.includes("vue-flow__container")))return!1;l.controlMode=="pointer"&&(e.show=!0,e.x=t.offsetX,e.y=t.offsetY,e.left=e.x,e.top=e.y,e.startX=t.pageX,e.startY=t.pageY,document.addEventListener("mousemove",m),document.addEventListener("mouseup",v))}function m(t){e.show&&(e.width=Math.abs(t.pageX-e.startX),e.height=Math.abs(t.pageY-e.startY),t.pageY<e.startY?e.top=e.y-e.height:e.top=e.y,t.pageX<e.startX?e.left=e.x-e.width:e.left=e.x,e.endY=e.top,e.endX=e.left)}function v(){const{x:t,y:g}=l.viewport;let f=0,h=0,p=0,s=0,x=!1;l.nodes.forEach(c=>{const{x:_=0,y:C=0}=c.position||{},$=document.querySelector(`div[data-id="${c.id}"]`),D=($==null?void 0:$.clientHeight)||0,z=($==null?void 0:$.clientWidth)||0;$&&e.endX<y(_+z)+t&&e.endX+e.width>y(_)+t&&e.endY<y(C+D)+g&&e.endY+e.height>y(C)+g&&(x=!0,i.list.push(c),(!f||f>_)&&(f=_),(!p||p>C)&&(p=C),(!h||h<_+z)&&(h=_+z),(!s||s<C+D)&&(s=C+D))}),x&&(a.show=!0,a.left=f,a.top=p,a.width=h-f,a.height=s-p),e.show=!1,document.removeEventListener("mousemove",m),document.removeEventListener("mouseup",v)}const i=pe({list:[],startX:0,startY:0,x:0,y:0,lock:!1,clear(){i.list=[]},onmousedown(t){t.stopPropagation(),i.lock=!0,i.startX=t.pageX,i.startY=t.pageY,document.addEventListener("mouseup",i.onmouseup),document.addEventListener("mousemove",i.onmousemove)},onmousemove(t){if(i.lock){const{zoom:g}=l.viewport,f=(t.pageX-i.startX)/g,h=(t.pageY-i.startY)/g;a.left+=f,a.top+=h,i.list.forEach(p=>{var s,x;l.updateNode(p.id,{position:{x:(((s=p.position)==null?void 0:s.x)||0)+f,y:(((x=p.position)==null?void 0:x.y)||0)+h}})}),i.startX=t.pageX,i.startY=t.pageY}},onmouseup(){i.lock=!1,document.removeEventListener("mouseup",i.onmouseup),document.removeEventListener("mousemove",i.onmousemove)},onkeydown(t){t.key=="Delete"&&(Q(i.list)?l.node&&l.removeNodes(l.node):l.removeNodes(i.list),u())}});return ge(()=>{var t;(t=document.getElementById("cl-flow"))==null||t.addEventListener("mousedown",A),document.addEventListener("keydown",i.onkeydown)}),Fe(()=>{var t;(t=document.getElementById("cl-flow"))==null||t.removeEventListener("mousedown",A),document.removeEventListener("keydown",i.onkeydown)}),(t,g)=>(d(),w(K,null,[Pe(b("div",{class:"mouse-selection",style:Se({height:e.height+"px",width:e.width+"px",left:e.left+"px",top:e.top+"px"})},null,4),[[$e,e.show]]),Pe(b("div",{class:"node-selection",style:Se([o.value]),onMousedown:g[0]||(g[0]=(...f)=>i.onmousedown&&i.onmousedown(...f))},null,36),[[$e,a.show]])],64))}}),Ei=Y(ji,[["__scopeId","data-v-a0aa9231"]]),$i={class:"cl-flow",id:"cl-flow"},Pi=I({name:"undefined"}),Oi=I({...Pi,name:"cl-flow",props:{flowId:Number},setup(n){const l=n,{refs:e,setRefs:a}=re(),o=de();function y(){o.init(),o.get(l.flowId)}function u(x){if(!x)return;const c=document.querySelectorAll(".vue-flow__node"),{zoom:_}=o.viewport;c.forEach(C=>{const $=C.querySelector(".node-content");if($){const D=Math.min(Math.max(_,.5),1.5);$.style.fontSize=`${14*D}px`}})}function A(x){o.addEdge(x)}async function m(x){var _,C;if(((_=o.node)==null?void 0:_.id)==x.node.id)return!1;const c=o.findNode(x.node.id);o.setNode(c),(C=e.contextMenu)==null||C.close()}function v(x){o.activeEdge(x.node.id,!0)}function i(x){o.activeEdge(x.node.id,!1)}function t(x){o.updateNode(x.node.id,{position:x.node.position})}function g(x){x.edge.data.show=!0}function f(x){x.edge.data.show=!1}function h(){var x;(x=e.contextMenu)==null||x.close(),o.enableDrag()}async function p(){await o.save(),ue.success("数据保存成功")}let s=!1;return gn((x,c,_)=>{if(s)return _();s=!0,Ue.confirm("退出前是否保存当前数据？","提示",{type:"warning",confirmButtonText:"保存",cancelButtonText:"不保存",distinguishCancelAndClose:!0,beforeClose(C,$,D){D(),C=="confirm"?(p(),_()):C=="cancel"?_():(s=!1,_(!1))}}).catch(()=>null)}),(x,c)=>{var _,C;return d(),w("div",$i,[r(E(Ft),{"default-viewport":{zoom:1},"min-zoom":.5,"max-zoom":1.5,onConnect:A,onNodeMouseEnter:v,onNodeMouseLeave:i,onNodeClick:m,onNodeDragStop:t,onNodeContextMenu:(_=E(e).contextMenu)==null?void 0:_.onNode,onEdgeMouseEnter:g,onEdgeMouseLeave:f,onPaneContextMenu:(C=E(e).contextMenu)==null?void 0:C.onPane,onPaneClick:h,onPaneScroll:u,onPaneReady:y},Gt({"edge-button":T(({id:$,sourceX:D,sourceY:z,targetX:X,targetY:ee,sourcePosition:oe,targetPosition:F,markerEnd:L,style:N,data:B})=>[r(Xr,{id:$,"source-x":D,"source-y":z,"target-x":X,"target-y":ee,"source-position":oe,"target-position":F,"marker-end":L,style:Se(N),data:B},null,8,["id","source-x","source-y","target-x","target-y","source-position","target-position","marker-end","style","data"])]),default:T(()=>[r(Ii),r(Ei),r(jr),r(Di,{ref:E(a)("contextMenu")},null,512),r(fi),r(E(qt),{"pattern-color":"#aaa",gap:16})]),_:2},[ne(E(o).CustomNodes,$=>({name:$.name,fn:T(({id:D})=>[r(Yr,{"node-id":D},null,8,["node-id"])])}))]),1032,["onNodeContextMenu","onPaneContextMenu"])])}}}),Vi=I({name:"undefined"}),Ul=I({...Vi,name:"flow-info",setup(n){const{route:l}=re(),e=Number(l.query.id||"0");return(a,o)=>(d(),W(Oi,{"flow-id":E(e)},null,8,["flow-id"]))}});export{Ul as default};
